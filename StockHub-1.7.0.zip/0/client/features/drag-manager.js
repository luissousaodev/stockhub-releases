// =============================================================================
// drag-manager.js — Modulo de drag & drop do StockHub
//
// Responsabilidades:
//   - Drag de arquivos para timeline do Premiere (CEP dnd)
//   - Drop em categorias para reclassificar
//   - Drop em favoritos
//   - Double-click para inserir na timeline
//   - Import para projeto
//   - Gerenciamento de estado de drag (pausar thumbs, matar processos)
//
// Dependencias externas (recebidas via init):
//   - state, saveState, showToast, toRelPath, toFileURL
//   - stageFileIfNeeded, getStagedPathIfExists
//   - cs (CSInterface), trackEvent, pumpThumbPool
//   - renderAll
//   - FFmpegManager, PreviewManager
// =============================================================================

// IIFE — encapsula estado privado (so roda no browser)
if (typeof window !== "undefined") (function() {

  // Dependencias injetadas via init()
  var _state              = null;
  var _saveState          = null;
  var _showToast          = null;
  var _toRelPath          = null;
  var _toFileURL          = null;
  var _stageFileIfNeeded  = null;
  var _stageFileAsync     = null;
  var _stageFilesAsync    = null;
  var _getStagedPathIfExists = null;
  var _cs                 = null;
  var _trackEvent         = null;
  var _pumpThumbPool      = null;
  var _renderAll          = null;

  // Estado de drag (compartilhado com app.js via window)
  // isDragging e thumbQueuePaused permanecem como globais no app.js

  // -------------------------------------------------------------------------
  // Import
  // -------------------------------------------------------------------------

  function importToProject(fileIndex) {
    var file = _state.files[fileIndex];
    if (!file) return;
    _stageFileAsync(file, function(_err, importPath) {
      var escapedPath = importPath.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
      _cs.evalScript("importFileToProject('" + escapedPath + "')", function(result) {
        try {
          var res = JSON.parse(result);
          if (res.success && !res.alreadyExists) _trackEvent(file, "import");
          _showToast(res.success ? (res.alreadyExists ? "Ja no projeto: " + file.name : "Importado: " + file.name) : (res.error || "Erro ao importar"));
        } catch (e) {
          _showToast("Erro ao importar");
        }
      });
    });
  }

  // -------------------------------------------------------------------------
  // Drag handlers
  // -------------------------------------------------------------------------

  // Helper: get ordered list of selected file indices (by selection order or index order)
  function _getSelectedIndices(includeIndex) {
    var indices = Object.keys(_state.selectedFiles).map(Number);
    if (includeIndex !== undefined && indices.indexOf(includeIndex) === -1) {
      indices.push(includeIndex);
    }
    indices.sort(function(a, b) { return a - b; });
    return indices;
  }

  function onFileDragStart(e, fileIndex) {
    var file = _state.files[fileIndex];
    window.isDragging = true;
    window.thumbQueuePaused = true;
    FFmpegManager.killActiveThumbChildren();
    PreviewManager.cleanupPreview();

    // Determine files to drag: selected files if multi-select, otherwise just this one
    var selCount = Object.keys(_state.selectedFiles).length;
    var dragIndices = (selCount > 1 && _state.selectedFiles[fileIndex]) ? _getSelectedIndices() : [fileIndex];

    e.dataTransfer.setData("text/plain", JSON.stringify(dragIndices));
    e.dataTransfer.effectAllowed = "copyMove";

    // Set CEP dnd data for all files
    for (var d = 0; d < dragIndices.length; d++) {
      var dFile = _state.files[dragIndices[d]];
      if (dFile && dFile.path) {
        var dragPath = _getStagedPathIfExists(dFile) || dFile.path;
        try { e.dataTransfer.setData("com.adobe.cep.dnd.file." + d, dragPath); } catch (err) { Logger.warn("drag", "setData cep.dnd." + d + " failed", err.message); }
      }
    }

    // URI list for first file (fallback)
    if (file && file.path) {
      try {
        var uri = _toFileURL(_getStagedPathIfExists(file) || file.path).replace(/ /g, "%20");
        e.dataTransfer.setData("text/uri-list", uri);
      } catch (err2) { Logger.warn("drag", "setData uri-list failed", err2.message); }
    }

    var item = e.target.closest && e.target.closest(".grid-item");
    if (item) item.classList.add("dragging");

    try {
      if (e.dataTransfer.setDragImage) {
        if (!window.__emptyDragImage) {
          var img = new Image();
          img.src =
            "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
          window.__emptyDragImage = img;
        }
        e.dataTransfer.setDragImage(window.__emptyDragImage, 0, 0);
      }
    } catch (errImg) { Logger.warn("drag", "setDragImage failed", errImg.message); }
  }

  function onFileDragEnd(e, fileIndex) {
    var el = e.target.closest(".grid-item");
    if (el) el.classList.remove("dragging");
    var cats = document.querySelectorAll(".cat-item");
    for (var i = 0; i < cats.length; i++) cats[i].classList.remove("drag-over");

    // Move all dragged files to StockHub bin
    var selCount = Object.keys(_state.selectedFiles).length;
    var dragIndices = (selCount > 1 && _state.selectedFiles[fileIndex]) ? _getSelectedIndices() : [fileIndex];

    dragIndices.forEach(function(idx) {
      var f = _state.files[idx];
      if (f && f.path) {
        var dragPath = _getStagedPathIfExists(f) || f.path;
        var escaped = dragPath.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
        setTimeout(function() {
          _cs.evalScript("moveFileToStockHubBin('" + escaped + "')");
        }, 500);
      }
    });

    window.isDragging = false;
    setTimeout(function() {
      window.thumbQueuePaused = false;
      _pumpThumbPool();
    }, 800);
  }

  function onCatDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    e.currentTarget.classList.add("drag-over");
  }

  function onCatDragLeave(e) {
    e.currentTarget.classList.remove("drag-over");
  }

  function _parseDragIndices(dataStr) {
    try {
      var parsed = JSON.parse(dataStr);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) {}
    var num = parseInt(dataStr);
    return isNaN(num) ? [] : [num];
  }

  function onCatDrop(e, catId) {
    e.preventDefault();
    e.currentTarget.classList.remove("drag-over");
    var indices = _parseDragIndices(e.dataTransfer.getData("text/plain"));
    if (!_state.fileCategories) _state.fileCategories = {};
    var count = 0;
    for (var i = 0; i < indices.length; i++) {
      var file = _state.files[indices[i]];
      if (!file) continue;
      file.category = catId;
      _state.fileCategories[_toRelPath(file.path)] = catId;
      count++;
    }
    if (count === 0) return;
    _saveState();
    _renderAll();
    var catName = "";
    for (var j = 0; j < _state.categories.length; j++) {
      if (_state.categories[j].id === catId) { catName = _state.categories[j].name; break; }
    }
    _showToast(count > 1 ? count + " arquivos movidos para: " + catName : "Movido para: " + catName);
  }

  function onFavoritesDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove("drag-over");
    var indices = _parseDragIndices(e.dataTransfer.getData("text/plain"));
    if (!_state.favoriteFiles) _state.favoriteFiles = {};
    var count = 0;
    for (var i = 0; i < indices.length; i++) {
      var file = _state.files[indices[i]];
      if (!file) continue;
      _state.favoriteFiles[_toRelPath(file.path)] = true;
      count++;
    }
    if (count === 0) return;
    _saveState();
    _renderAll();
    _showToast(count > 1 ? count + " arquivos adicionados aos favoritos" : "Adicionado aos favoritos: " + _state.files[indices[0]].name);
  }

  function onDoubleClick(fileIndex) {
    var selCount = Object.keys(_state.selectedFiles).length;

    // Multi-selection: insert all selected files to timeline in order
    if (selCount > 1 && _state.selectedFiles[fileIndex]) {
      var indices = _getSelectedIndices();
      var filesToStage = [];
      for (var i = 0; i < indices.length; i++) {
        var f = _state.files[indices[i]];
        if (f) filesToStage.push(f);
      }
      if (filesToStage.length === 0) return;
      _stageFilesAsync(filesToStage, function(paths) {
        var pathsJSON = JSON.stringify(paths).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
        _cs.evalScript("importFilesToTimeline('" + pathsJSON + "')", function(result) {
          try {
            var res = JSON.parse(result);
            if (res.success) {
              for (var j = 0; j < indices.length; j++) {
                var tf = _state.files[indices[j]];
                if (tf) _trackEvent(tf, "timeline");
              }
            }
            _showToast(res.success
              ? res.inserted + "/" + res.total + " inseridos na timeline"
              : (res.error || "Erro ao inserir"));
          } catch (e) {
            _showToast("Erro ao inserir na timeline");
          }
        });
      });
      return;
    }

    // Single file
    var file = _state.files[fileIndex];
    if (!file) return;
    _stageFileAsync(file, function(_err, importPath) {
      var escapedPath = importPath.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
      _cs.evalScript("importFileToTimeline('" + escapedPath + "')", function(result) {
        try {
          var res = JSON.parse(result);
          if (res.success) _trackEvent(file, "timeline");
          _showToast(res.success ? "Inserido na timeline: " + file.name : (res.error || "Erro ao inserir"));
        } catch (e) {
          _showToast("Erro ao inserir na timeline");
        }
      });
    });
  }

  // -------------------------------------------------------------------------
  // Batch insert to timeline (from selection bar)
  // -------------------------------------------------------------------------

  function batchInsertToTimeline() {
    var indices = Object.keys(_state.selectedFiles).map(Number);
    if (indices.length === 0) return;
    indices.sort(function(a, b) { return a - b; });

    var filesToStage = [];
    for (var i = 0; i < indices.length; i++) {
      var f = _state.files[indices[i]];
      if (f) filesToStage.push(f);
    }
    if (filesToStage.length === 0) return;

    document.getElementById("statusText").textContent = "Inserindo na timeline...";
    _stageFilesAsync(filesToStage, function(paths) {
      var pathsJSON = JSON.stringify(paths).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
      _cs.evalScript("importFilesToTimeline('" + pathsJSON + "')", function(result) {
        try {
          var res = JSON.parse(result);
          if (res.success) {
            for (var j = 0; j < indices.length; j++) {
              var tf = _state.files[indices[j]];
              if (tf) _trackEvent(tf, "timeline");
            }
          }
          var msg = res.success
            ? res.inserted + "/" + res.total + " inseridos na timeline"
            : (res.error || "Erro ao inserir");
          if (res.errors > 0) msg += " (" + res.errors + " erro" + (res.errors > 1 ? "s" : "") + ")";
          _showToast(msg);
          document.getElementById("statusText").textContent = "";
        } catch (e) {
          _showToast("Erro ao inserir na timeline");
          document.getElementById("statusText").textContent = "";
        }
        _state.selectedFiles = {};
        renderGrid();
      });
    });
  }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.DragManager = {
    init: function(stateRef, deps) {
      _state              = stateRef;
      _saveState          = deps.saveState;
      _showToast          = deps.showToast;
      _toRelPath          = deps.toRelPath;
      _toFileURL          = deps.toFileURL;
      _stageFileIfNeeded  = deps.stageFileIfNeeded;
      _stageFileAsync     = deps.stageFileAsync;
      _stageFilesAsync    = deps.stageFilesAsync;
      _getStagedPathIfExists = deps.getStagedPathIfExists;
      _cs                 = deps.cs;
      _trackEvent         = deps.trackEvent;
      _pumpThumbPool      = deps.pumpThumbPool;
      _renderAll          = deps.renderAll;
    },
    importToProject:        importToProject,
    onFileDragStart:        onFileDragStart,
    onFileDragEnd:          onFileDragEnd,
    onCatDragOver:          onCatDragOver,
    onCatDragLeave:         onCatDragLeave,
    onCatDrop:              onCatDrop,
    onFavoritesDrop:        onFavoritesDrop,
    onDoubleClick:          onDoubleClick,
    batchInsertToTimeline:  batchInsertToTimeline
  };

  // Aliases globais para inline event attrs
  window.importToProject        = importToProject;
  window.onFileDragStart        = onFileDragStart;
  window.onFileDragEnd          = onFileDragEnd;
  window.onCatDragOver          = onCatDragOver;
  window.onCatDragLeave         = onCatDragLeave;
  window.onCatDrop              = onCatDrop;
  window.onFavoritesDrop        = onFavoritesDrop;
  window.onDoubleClick          = onDoubleClick;
  window.batchInsertToTimeline  = batchInsertToTimeline;

})();
