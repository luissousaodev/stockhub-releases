// =============================================================================
// features/file-scanner.js — Scan de pasta e watcher por polling
// =============================================================================

// --- Folder index sidecar (boot otimista) -----------------------------------
// Cache do resultado do scanFolder em <stockFolder>/.cache/index.json. Boot 2+
// le esse arquivo pra renderizar o grid imediatamente, enquanto re-scaneia
// em background. Schema versionado (v:1); shape invalido cai pro scan normal.

// _validateIndexShape — puro, testavel. Retorna objeto sanitizado (root com
// so v/savedAt/files) ou null. Per-file: liberal (mantem campos extras), exige
// so 'path' nao-vazio. Files invalidos sao descartados, nao invalidam o todo.
function _validateIndexShape(obj) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return null;
  if (obj.v !== 1) return null;
  if (typeof obj.savedAt !== "number" || isNaN(obj.savedAt) || obj.savedAt <= 0) return null;
  if (!Array.isArray(obj.files)) return null;

  var sanitFiles = [];
  for (var i = 0; i < obj.files.length; i++) {
    var f = obj.files[i];
    if (!f || typeof f !== "object" || Array.isArray(f)) continue;
    if (typeof f.path !== "string" || !f.path) continue;
    sanitFiles.push(f);
  }
  return { v: 1, savedAt: obj.savedAt, files: sanitFiles };
}

// saveFolderIndex — fire-and-forget. Write atomico via .tmp + rename pra
// evitar leitura de JSON parcial se panel crashar mid-write. mkdirSync
// defensivo cobre pasta apagada externamente, clearCache concorrente, etc.
function saveFolderIndex(folderPath, files) {
  if (typeof fs === "undefined" || typeof path === "undefined") return;
  try {
    var dir = path.join(folderPath, ".cache");
    fs.mkdirSync(dir, { recursive: true });
    var indexFile = path.join(dir, "index.json");
    var tmpFile = indexFile + ".tmp";
    var payload = JSON.stringify({ v: 1, savedAt: Date.now(), files: files });
    fs.writeFile(tmpFile, payload, function(err) {
      if (err) { Logger.warn("scanner", "saveFolderIndex write falhou", err.message); return; }
      fs.rename(tmpFile, indexFile, function(err2) {
        if (err2) Logger.warn("scanner", "saveFolderIndex rename falhou", err2.message);
      });
    });
  } catch (e) {
    Logger.warn("scanner", "saveFolderIndex throw", e.message);
  }
}

// loadFolderIndex — sync (boot path). Retorna {v, savedAt, files} ou null.
// Arquivo ausente eh silencioso (boot 1 esperado); parse/shape invalidos
// logam warn e retornam null pra cair no scan normal.
function loadFolderIndex(folderPath) {
  if (typeof fs === "undefined" || typeof path === "undefined") return null;
  try {
    var indexFile = path.join(folderPath, ".cache", "index.json");
    if (!fs.existsSync(indexFile)) return null;
    try {
      var raw = fs.readFileSync(indexFile, "utf-8");
      var validated = _validateIndexShape(JSON.parse(raw));
      if (!validated) {
        Logger.warn("scanner", "folder index invalido — vai regerar", folderPath);
        return null;
      }
      return validated;
    } catch (e) {
      Logger.warn("scanner", "folder index parse falhou — vai regerar", e.message);
      return null;
    }
  } catch (eOuter) {
    Logger.warn("scanner", "loadFolderIndex guard", eOuter.message);
    return null;
  }
}

// deleteFolderIndex — best-effort. Chamado quando troca-se de stock folder
// (pasta antiga ainda tem seu .cache intocado; aqui apaga so o sidecar atual
// se necessario — uso em commit 3).
function deleteFolderIndex(folderPath) {
  if (typeof fs === "undefined" || typeof path === "undefined") return;
  try {
    var indexFile = path.join(folderPath, ".cache", "index.json");
    if (fs.existsSync(indexFile)) fs.unlinkSync(indexFile);
  } catch (e) {
    Logger.warn("scanner", "deleteFolderIndex falhou", e.message);
  }
}

// --- File Scanning ---
function scanFolder(folderPath) {
  var files = [];

  try {
    if (!folderPath || !fs.existsSync(folderPath)) {
      Logger.error("scanner", "Pasta nao encontrada:", folderPath);
      return files;
    }

    // Detecta uma vez por scan: se a pasta-raiz aponta para nuvem, todos os
    // arquivos viram candidatos a staging defensivo (stat.blocks nao e
    // confiavel no Windows com Drive Stream / OneDrive Files-On-Demand).
    var rootCloud = (typeof detectCloudPath === "function") ? detectCloudPath(folderPath) : null;

    // Lookup O(1) de categorias existentes (evita for loop em state.categories
    // por diretorio — em pasta com 100 categorias x 50 dirs eram 5000 ops)
    var existingCatIds = {};
    for (var k = 0; k < state.categories.length; k++) {
      existingCatIds[state.categories[k].id] = true;
    }
    var deletedSet = {};
    for (var dl = 0; dl < state.deletedCategoryIds.length; dl++) {
      deletedSet[state.deletedCategoryIds[dl]] = true;
    }

    // Snapshot leve coletado durante o walk — alimenta _watchSnapshot direto,
    // eliminando segunda passagem por buildSnapshot apos o scan
    var lightPaths = [];

    function walk(dir, category, depth, parentCatId) {
      var items;
      try {
        items = fs.readdirSync(dir);
      } catch (e) {
        return;
      }

      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var fullPath = path.join(dir, item);
        var stat;
        try {
          stat = fs.statSync(fullPath);
        } catch (e) {
          continue;
        }

        if (stat.isDirectory()) {
          // pula dot-dirs (.git, .cache, .DS_Store), pasta de dados e node_modules
          if (item.charAt(0) === "." || item === "stockhub-data" || item === "node_modules") continue;
          var catId = toCategoryId(item);
          if (depth === 1 && parentCatId) catId = parentCatId + "/" + catId;
          if (depth <= 1 && state.autoCategories && !existingCatIds[catId] && !deletedSet[catId]) {
            var catObj = { id: catId, name: item, color: getRandomColor() };
            if (depth === 1) catObj.parent = parentCatId;
            state.categories.push(catObj);
            existingCatIds[catId] = true;
          }
          var nextParent = (depth === 0) ? catId : parentCatId;
          walk(fullPath, catId, depth + 1, nextParent);
        } else {
          var ext = path.extname(item).toLowerCase();
          if (ALL_EXTENSIONS.indexOf(ext) >= 0) {
            var blocks = (typeof stat.blocks === "number") ? stat.blocks : -1;
            // Detecao por stat (preciso no macOS) + heuristica por path (rede de
            // seguranca para Windows + Drive Stream, onde stat.blocks e undefined).
            var cloudOnly = (blocks === 0) || (stat.size === 0) || !!rootCloud;
            files.push({
              name: item,
              path: fullPath,
              ext: ext.replace(".", ""),
              type: getFileType(ext),
              category: (state.fileCategories && state.fileCategories[toRelPath(fullPath)]) || category || "all",
              size: stat.size,
              modified: stat.mtime,
              cloudOnly: cloudOnly,
            });
            lightPaths.push(fullPath);
          }
        }
      }
    }

    walk(folderPath, null, 0, null);

    // Popula _watchSnapshot direto — evita walk duplicado quando o watcher
    // detecta mudanca e re-scaneia (antes era: buildSnapshot + scanFolder)
    lightPaths.sort();
    _watchSnapshot = lightPaths.join("\n");

    // Persiste index pra boot otimista. Async fire-and-forget — nao bloqueia
    // o retorno do scan. So salva quando walk completou (catch abaixo nao
    // poisona cache com estado parcial).
    saveFolderIndex(folderPath, files);
  } catch (e) {
    Logger.error("scanner", "Scan error", e.message);
  }
  return files;
}

// --- Filesystem watcher (polling) ---
// fs.watch recursivo nao funciona no macOS, e Drive Desktop tampouco emite
// eventos confiaveis. Substituido por polling: a cada 15-30s reconstroi um
// snapshot leve (so lista de paths, sem statSync) e dispara re-scan se diff.
var _watchSnapshot = null;
var _watchTimer = null;
var _watchInterval = null;
var _watchedFolder = null;

// Polling adaptativo: pasta cloud (Drive/OneDrive/Dropbox) usa intervalo maior
// porque readdirSync em Drive pode ter latencia, e mudancas remotas demoram
// para sincronizar (nao adianta poll mais agressivo).
function getPollInterval(folder) {
  var info = (typeof detectCloudPath === "function") ? detectCloudPath(folder) : null;
  return info ? 30000 : 15000;
}

// Snapshot leve: SO lista de paths (sem statSync). Detecta arquivos
// adicionados/removidos/renomeados, que sao 95% das mudancas em pasta de
// stocks. Em pasta Drive com 5000 arquivos: ~20-200 readdirSync (rapido)
// vs 5000 statSync (lento). Trade-off: nao detecta arquivo modificado in-place
// com mesmo nome — para isso, o scanFolder completo no refresh manual cobre.
function buildLightSnapshot(rootDir) {
  var snap = [];
  function walk(dir) {
    var items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (var i = 0; i < items.length; i++) {
      var d = items[i];
      var name = d.name;
      if (name.charAt(0) === "." || name === "stockhub-data" || name === "node_modules") continue;
      var full = path.join(dir, name);
      if (d.isDirectory()) {
        walk(full);
      } else {
        var ext = path.extname(name).toLowerCase();
        if (ALL_EXTENSIONS.indexOf(ext) >= 0) snap.push(full);
      }
    }
  }
  walk(rootDir);
  snap.sort();
  return snap.join("\n");
}

// Snapshot completo (com mtime+size) — ainda usado no test runner e para
// detectar mudancas de conteudo in-place (arquivo modificado sem renomear).
// Mantido para compatibilidade com host/file-scanner.test.js.
function buildSnapshot(rootDir) {
  var snap = {};
  function walk(dir) {
    var items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (var i = 0; i < items.length; i++) {
      var d = items[i];
      var name = d.name;
      if (name.charAt(0) === "." || name === "stockhub-data" || name === "node_modules") continue;
      var full = path.join(dir, name);
      if (d.isDirectory()) {
        walk(full);
      } else {
        var ext = path.extname(name).toLowerCase();
        if (ALL_EXTENSIONS.indexOf(ext) < 0) continue;
        try {
          var st = fs.statSync(full);
          var rel = path.relative(rootDir, full).split(path.sep).join("/");
          snap[rel] = { m: st.mtimeMs, s: st.size };
        } catch (e) { Logger.warn("scanner", "Falha ao stat arquivo no snapshot", e.message); }
      }
    }
  }
  walk(rootDir);
  return snap;
}

function snapshotsDiffer(a, b) {
  if (!a || !b) return true;
  var ak = Object.keys(a), bk = Object.keys(b);
  if (ak.length !== bk.length) return true;
  for (var i = 0; i < ak.length; i++) {
    var k = ak[i];
    if (!b[k]) return true;
    if (a[k].m !== b[k].m || a[k].s !== b[k].s) return true;
  }
  return false;
}

function stopFolderWatcher() {
  if (_watchInterval) {
    clearInterval(_watchInterval);
    _watchInterval = null;
  }
  if (_watchTimer) {
    clearTimeout(_watchTimer);
    _watchTimer = null;
  }
  _watchSnapshot = null;
  _watchedFolder = null;
}

function startFolderWatcher(folder) {
  if (_watchedFolder === folder && _watchInterval) return;
  stopFolderWatcher();
  if (!folder || !fs.existsSync(folder)) return;
  _watchedFolder = folder;

  // Se _watchSnapshot ja foi populado pelo scanFolder anterior, reutiliza.
  // Caso contrario (primeira chamada), constroi snapshot leve agora.
  if (!_watchSnapshot) _watchSnapshot = buildLightSnapshot(folder);

  function pollOnce() {
    if (_watchedFolder !== folder) return;
    // Skip quando a janela esta oculta — pasta vai ser re-scaneada quando o
    // user voltar (vide visibilitychange handler abaixo).
    if (typeof document !== "undefined" && document.hidden) return;
    var next;
    try { next = buildLightSnapshot(folder); } catch (e) { return; }
    if (next !== _watchSnapshot) {
      _watchSnapshot = next;
      if (_watchTimer) clearTimeout(_watchTimer);
      _watchTimer = setTimeout(function() {
        _watchTimer = null;
        try {
          state.files = scanFolder(folder);
          renderAll();
          var statusEl = document.getElementById("statusText");
          if (statusEl) statusEl.textContent = "Atualizado automaticamente";
        } catch (e) {
          Logger.error("scanner", "Auto-refresh error", e.message);
        }
      }, 400);
    }
  }

  _watchInterval = setInterval(pollOnce, getPollInterval(folder));
}

// Para o watcher quando a janela e fechada/recarregada; e dispara um scan
// imediato quando a janela volta a ficar visivel apos estar oculta (assim o
// user nao espera ate 30s para ver mudancas de outros membros do time).
if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", function() { stopFolderWatcher(); });
  document.addEventListener("visibilitychange", function() {
    if (!document.hidden && _watchedFolder && _watchInterval) {
      try {
        // Compara snapshot leve atual com o salvo — se diferente, faz scan
        // completo (que repopula _watchSnapshot via side effect).
        var next = buildLightSnapshot(_watchedFolder);
        if (next !== _watchSnapshot) {
          state.files = scanFolder(_watchedFolder);
          renderAll();
        }
      } catch (e) { Logger.warn("scanner", "Visibility refresh failed", e.message); }
    }
  });
}

// Exports para testes
if (typeof module !== "undefined") {
  module.exports = {
    buildSnapshot: buildSnapshot,
    snapshotsDiffer: snapshotsDiffer,
    _validateIndexShape: _validateIndexShape
  };
}
