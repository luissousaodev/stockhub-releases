// =============================================================================
// features/folder-manager.js — Gestao da pasta de stocks
// =============================================================================

function getDefaultStockFolder() {
  var home = process.env.HOME || process.env.USERPROFILE || "";
  return path.join(home, "StockHub");
}

function getStockFolder() {
  return state.customFolder || getDefaultStockFolder();
}

function ensureStockFolder() {
  try {
    var folder = getStockFolder();
    if (!fs.existsSync(folder)) {
      fs.mkdirSync(folder, { recursive: true });
      ["Videos", "Imagens", "Audio", "Transicoes", "MOGRT"].forEach(function(sub) {
        fs.mkdirSync(path.join(folder, sub), { recursive: true });
      });
    }
    return folder;
  } catch (e) {
    alert("Erro ao criar pasta StockHub: " + e.toString());
    return null;
  }
}

function openStockFolder() {
  try {
    var folder = getStockFolder();
    if (isWindows) {
      // explorer.exe abre e foca a janela em cima
      child.exec('explorer.exe "' + folder + '"');
    } else {
      // 'open' no macOS ativa o Finder e traz pra frente
      child.exec('open "' + folder.replace(/"/g, '\\"') + '"');
    }
  } catch (e) { Logger.warn("folder", "Falha ao abrir pasta", e.message); }
}

function changeStockFolder() {
  // CEP fornece um folder picker nativo modal à janela do Premiere — abre em
  // primeiro plano automaticamente, sem PowerShell/AppleScript.
  // Assinatura: showOpenDialogEx(allowMultiple, chooseDirectory, title, initialPath, fileTypes)
  if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialogEx) {
    Logger.warn("folder", "cep.fs.showOpenDialogEx indisponivel");
    return;
  }
  var initial = getStockFolder();
  var result;
  try {
    result = window.cep.fs.showOpenDialogEx(false, true, "Selecionar pasta de assets", initial);
  } catch (e) {
    Logger.warn("folder", "Falha no folder picker", e.message);
    return;
  }
  if (result && result.data && result.data.length > 0) {
    applyFolderChange(result.data[0], true);
  }
}

function applyFolderChange(folderPath, autoCategories) {
  closeModal();
  if (state.showSettings) toggleSettings();
  if (metricsState.visible) toggleMetrics();
  state.customFolder = folderPath;
  state.autoCategories = autoCategories;
  state.categories = state.categories.filter(function(c) { return c.system; });
  state.fileCategories = {};
  state.deletedCategoryIds = [];
  state.activeCategory = "all";
  saveState();
  ensureStockFolder();
  thumbLookupCache.clear();
  FFmpegManager.clearCaches();
  refreshFiles();
  showToast("Pasta alterada: " + folderPath);
}

function _doResetStockFolder() {
  if (state.showSettings) toggleSettings();
  if (metricsState.visible) toggleMetrics();
  state.customFolder = null;
  state.categories = state.categories.filter(function(c) { return c.system; });
  state.fileCategories = {};
  state.deletedCategoryIds = [];
  state.activeCategory = "all";
  saveState();
  ensureStockFolder();
  thumbLookupCache.clear();
  FFmpegManager.clearCaches();
  refreshFiles();
  showToast("Pasta restaurada para padrao: " + getDefaultStockFolder());
}

function resetStockFolder() {
  if (!state.customFolder) {
    showToast("Ja esta usando a pasta padrao");
    return;
  }
  showConfirmModal({
    title: "Restaurar pasta padrao?",
    message: "Voltamos para <b>" + getDefaultStockFolder() + "</b> e suas categorias customizadas serao removidas. " +
             "Os arquivos da sua pasta atual nao sao apagados.",
    confirmLabel: "Restaurar",
    cancelLabel: "Cancelar",
    danger: true,
    onConfirm: _doResetStockFolder
  });
}
