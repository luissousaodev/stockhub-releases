// =============================================================================
// features/staging.js — Staging local de assets cloud
// =============================================================================

function getDefaultStagingFolder() {
  var home = process.env.HOME || process.env.USERPROFILE || "";
  return path.join(home, "StockHub_staging");
}

function getStagingFolder() {
  return state.stagingFolder || getDefaultStagingFolder();
}

var _LARGE_COPY_THRESHOLD = 50 * 1024 * 1024; // 50 MB — toast so para copias grandes

// Versao SINCRONA — usada em paths que precisam retornar imediato (drag).
// Rapido se o arquivo ja esta cached; bloqueante na primeira copia.
// Para clicks/imports use stageFileAsync abaixo (nao trava UI).
function stageFileIfNeeded(file) {
  if (!file || !file.cloudOnly) return file.path;
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size === file.size && st.size > 0) return stagedPath;
    }
  } catch (e) { Logger.warn("staging", "Falha ao verificar staged file", e.message); }
  try {
    fs.mkdirSync(path.dirname(stagedPath), { recursive: true });
    if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(true);
    var isLarge = file.size && file.size > _LARGE_COPY_THRESHOLD;
    if (isLarge) showToast("Copiando para staging local...");
    fs.copyFileSync(file.path, stagedPath);
    if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(false);
    return stagedPath;
  } catch (e) {
    if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(false);
    Logger.error("staging", "Staging copy failed", e.message);
    showToast("Falha ao copiar para staging — Premiere usara o caminho original");
    return file.path;
  }
}

// Versao ASSINCRONA via stream — nao trava a UI durante a copia. Use em
// imports por click/duplo-click (batch ou single). callback(err, path).
function stageFileAsync(file, callback) {
  if (!file || !file.cloudOnly) { callback(null, file ? file.path : null); return; }
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  // Cache hit — retorna imediato (mesma logica do sync)
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size === file.size && st.size > 0) { callback(null, stagedPath); return; }
    }
  } catch (e) { Logger.warn("staging", "stageFileAsync stat", e.message); }
  // Cria diretorio destino
  try {
    fs.mkdirSync(path.dirname(stagedPath), { recursive: true });
  } catch (e) {
    Logger.error("staging", "stageFileAsync mkdir", e.message);
    callback(e, file.path);
    return;
  }
  // Copia via stream — nao bloqueia event loop como copyFileSync
  if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(true);
  var isLarge = file.size && file.size > _LARGE_COPY_THRESHOLD;
  if (isLarge) showToast("Copiando para staging local...");
  var rs = fs.createReadStream(file.path);
  var ws = fs.createWriteStream(stagedPath);
  var settled = false;
  function done(err, p) {
    if (settled) return;
    settled = true;
    if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(false);
    callback(err, p);
  }
  rs.on("error", function(err) {
    Logger.error("staging", "stream read error", err.message);
    try { ws.destroy(); } catch (_) { /* ignora */ }
    done(err, file.path);
  });
  ws.on("error", function(err) {
    Logger.error("staging", "stream write error", err.message);
    try { rs.destroy(); } catch (_) { /* ignora */ }
    done(err, file.path);
  });
  ws.on("finish", function() { done(null, stagedPath); });
  rs.pipe(ws);
}

// Stage de varios arquivos em PARALELO com pool de concurrency.
// Assinatura: stageFilesAsync(files, [onProgress], onComplete).
// Antes era sequencial — em batch de 20 videos cloud (Drive 30 Mbps,
// 50 MB cada), levava ~5 min. Com STAGE_POOL=4 cai pra ~1.5 min.
// Drive aguenta paralelismo de streams (mesmo limite que thumb pool).
//
// onProgress(staged, total, file) opcional — chamado a cada conclusao
// (NAO em ordem do array; observe via staged++ acumulado).
// onComplete(paths) recebe array indexed match do input.
function stageFilesAsync(files, onProgressOrComplete, onCompleteMaybe) {
  var onProgress, onComplete;
  if (typeof onCompleteMaybe === "function") {
    onProgress = onProgressOrComplete;
    onComplete = onCompleteMaybe;
  } else {
    onProgress = null;
    onComplete = onProgressOrComplete;
  }

  var paths = new Array(files.length);
  if (files.length === 0) { onComplete(paths); return; }

  var STAGE_POOL = 4;
  var done = 0, active = 0, next = 0;

  function pump() {
    while (active < STAGE_POOL && next < files.length) {
      var idx = next++;
      var f = files[idx];
      if (!f) { paths[idx] = null; done++; if (done === files.length) onComplete(paths); continue; }
      active++;
      (function(i, file) {
        stageFileAsync(file, function(_err, p) {
          paths[i] = p;
          active--;
          done++;
          if (onProgress) { try { onProgress(done, files.length, file); } catch (_) { /* ignora */ } }
          if (done === files.length) onComplete(paths);
          else pump();
        });
      })(idx, f);
    }
  }
  pump();
}

function getStagedPathIfExists(file) {
  if (!file || !file.cloudOnly) return null;
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size > 0) return stagedPath;
    }
  } catch (e) { Logger.warn("staging", "Falha ao verificar staged path", e.message); }
  return null;
}

function changeStagingFolder() {
  var result = window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx
    ? window.cep.fs.showOpenDialogEx(false, true, "Escolha a pasta de staging", "")
    : null;
  if (result && result.data && result.data.length > 0) {
    state.stagingFolder = result.data[0];
    saveState();
    var el = document.getElementById("stagingFolderPath");
    if (el) el.textContent = state.stagingFolder;
    showToast("Pasta de staging alterada");
  }
}

// getStagingSize — async via fs.promises. Antes era walk sincrono recursivo
// com readdirSync + statSync por arquivo (em staging de 5K assets podia
// bloquear UI 100-500 ms ao abrir Settings — pior em NAS). Agora paralelo
// por diretorio com Promise.all. Callback recebe (err, "X.X KB|MB|GB").
function _formatSize(total) {
  if (total < 1024 * 1024) return (total / 1024).toFixed(1) + " KB";
  if (total < 1024 * 1024 * 1024) return (total / (1024 * 1024)).toFixed(1) + " MB";
  return (total / (1024 * 1024 * 1024)).toFixed(1) + " GB";
}

function getStagingSize(callback) {
  var folder = getStagingFolder();

  function sumDir(dir) {
    return fs.promises.readdir(dir, { withFileTypes: true })
      .then(function(items) {
        return Promise.all(items.map(function(d) {
          var full = path.join(dir, d.name);
          if (d.isDirectory()) return sumDir(full);
          return fs.promises.stat(full)
            .then(function(st) { return st.size; })
            .catch(function() { return 0; });
        }));
      })
      .then(function(sizes) { return sizes.reduce(function(a, b) { return a + b; }, 0); })
      .catch(function() { return 0; });
  }

  fs.promises.access(folder)
    .then(function() { return sumDir(folder); })
    .catch(function() { return 0; })
    .then(function(total) { callback(null, _formatSize(total)); });
}

function _doClearStagingFolder() {
  var folder = getStagingFolder();
  try {
    fs.rmSync(folder, { recursive: true, force: true });
    fs.mkdirSync(folder, { recursive: true });
    var el = document.getElementById("stagingSize");
    if (el) el.textContent = "0 KB";
    showToast("Staging limpo com sucesso");
  } catch (e) {
    showToast("Erro ao limpar staging: " + e.message);
  }
}

function clearStagingFolder() {
  getStagingSize(function(_e, size) {
    if (size === "0.0 KB" || size === "0 KB") {
      showToast("Staging ja esta vazio");
      return;
    }
    showConfirmModal({
      title: "Limpar staging?",
      message: "Vamos liberar <b>" + size + "</b> em cache de assets da nuvem. " +
               "Se voce ainda nao fez Collect/Export do projeto, mantenha — sem isso o Premiere fica com midia offline.",
      confirmLabel: "Limpar",
      cancelLabel: "Cancelar",
      danger: true,
      onConfirm: _doClearStagingFolder
    });
  });
}
