// =============================================================================
// app.js — Init + wiring do StockHub (CEP Extension for Premiere Pro)
// =============================================================================
// Modulos carregados via script tags (ver index.html):
//   core/     — constants, platform, logger, storage, state
//   features/ — file-scanner, thumbnails, folder-manager, staging
//   ui/       — render, settings, toast, sidebar-resize
//   Managers  — ffmpeg, modal, preview, drag, category, metrics, update

var APP_VERSION = (function () {
  try {
    var vf = require("path").join(__dirname, "..", "version.json");
    return JSON.parse(require("fs").readFileSync(vf, "utf-8")).version || "0.0.0";
  } catch (e) { return "0.0.0"; }
})();
var cs = new CSInterface();

// Estado global de drag — usado para pausar trabalho pesado de ffmpeg
var isDragging = false;
// Sinalizador para pausar a fila de geracao de thumbs em background
var thumbQueuePaused = false;

// --- Bind static events (substitui onclick inline do HTML) ---
function bindStaticEvents() {
  // Header buttons
  document.getElementById("refreshBtn").addEventListener("click", refreshFiles);
  document.getElementById("metricsBtn").addEventListener("click", toggleMetrics);
  document.getElementById("settingsBtn").addEventListener("click", toggleSettings);

  // Format tabs (event delegation)
  document.getElementById("formatTabs").addEventListener("click", function(e) {
    var btn = e.target.closest(".tab");
    if (!btn) return;
    var format = btn.getAttribute("data-format");
    if (format) setFormat(format, btn);
  });

  // Search input
  document.getElementById("searchInput").addEventListener("input", filterFiles);

  // Sidebar — add category
  document.getElementById("addCategoryBtn").addEventListener("click", showAddCategoryModal);

  // Metrics panel — back button
  document.getElementById("metricsBackBtn").addEventListener("click", toggleMetrics);

  // Settings panel — folder actions
  document.getElementById("changeStockFolderBtn").addEventListener("click", changeStockFolder);
  document.getElementById("openStockFolderBtn").addEventListener("click", openStockFolder);
  document.getElementById("resetStockFolderBtn").addEventListener("click", resetStockFolder);

  // Sidebar — context menu on empty area
  document.getElementById("categoryList").addEventListener("contextmenu", showSidebarContextMenu);

  // Settings panel — staging
  document.getElementById("changeStagingBtn").addEventListener("click", changeStagingFolder);
  document.getElementById("clearStagingBtn").addEventListener("click", clearStagingFolder);

  // Settings panel — bottom actions
  document.getElementById("changelogBtn").addEventListener("click", showChangelogModal);
  document.getElementById("aboutBtn").addEventListener("click", showAboutModal);
  document.getElementById("saveSettingsBtn").addEventListener("click", saveSettings);

  // Grid size slider
  document.getElementById("gridSize").addEventListener("input", updateGridSize);

  // Grid click — multi-select with Ctrl/Shift
  document.getElementById("fileGrid").addEventListener("click", function(e) {
    if (e.target.closest(".import-btn")) return;
    var item = e.target.closest(".grid-item");
    if (!item) return;
    var fp = item.getAttribute("data-filepath");
    if (!fp) return;
    for (var i = 0; i < state.files.length; i++) {
      if (state.files[i].path === fp) {
        if (e.ctrlKey || e.shiftKey) {
          e.preventDefault();
          toggleFileSelection(i, e);
        } else if (Object.keys(state.selectedFiles).length > 0) {
          clearSelection();
        }
        break;
      }
    }
  });

  // Version label — click to show about
  document.getElementById("versionLabel").addEventListener("click", showAboutModal);
}

// --- Init ---
function init() {
  try {
    bindStaticEvents();
    loadState();
    document.getElementById("gridSize").value = state.gridSize;
    ensureStockFolder();

    // Version label no footer
    var vl = document.getElementById("versionLabel");
    if (vl) vl.textContent = "v" + APP_VERSION;

    // FFmpeg — inicializa modulo (antes de findFFmpeg)
    FFmpegManager.init({
      getStockFolder: getStockFolder,
      toRelPath: toRelPath,
      toFileURL: toFileURL
    });

    var ff = findFFmpeg();
    if (ff) {
      Logger.info("init", "FFmpeg found at " + ff);
    } else {
      Logger.warn("init", "FFmpeg not found. MOV previews disabled.");
    }

    // Modais — inicializa modulo
    ModalManager.init(state, {
      saveState: saveState,
      showToast: showToast
    });
    ModalManager.loadChangelog();

    // Restore sidebar width
    if (state.sidebarWidth) {
      var sb = document.getElementById("sidebar");
      if (sb) sb.style.width = state.sidebarWidth + "px";
    }
    initSidebarResize();

    refreshFiles();

    // Show userId modal if not set
    if (!state.userId) {
      showUserIdModal();
    }

    // Welcome modal (primeira execucao)
    if (!state.welcomed) {
      showWelcomeModal(0);
    }

    // What's new modal (apos update)
    if (state.lastSeenVersion && _compareSemver(APP_VERSION, state.lastSeenVersion) > 0) {
      showToast("Atualizado para v" + APP_VERSION + " com sucesso!");
      showWhatsNewModal();
    } else if (!state.lastSeenVersion) {
      state.lastSeenVersion = APP_VERSION;
      saveState();
    }

    // Categorias — inicializa modulo
    CategoryManager.init(state, {
      saveState: saveState,
      showToast: showToast,
      toRelPath: toRelPath,
      renderCategories: renderCategories,
      renderGrid: renderGrid,
      renderAll: renderAll
    });

    // Drag — inicializa modulo
    DragManager.init(state, {
      saveState: saveState,
      showToast: showToast,
      toRelPath: toRelPath,
      toFileURL: toFileURL,
      stageFileIfNeeded: stageFileIfNeeded,
      getStagedPathIfExists: getStagedPathIfExists,
      cs: cs,
      trackEvent: trackEvent,
      pumpThumbPool: pumpThumbPool,
      renderAll: renderAll
    });

    // Preview — inicializa modulo
    PreviewManager.init(state, {
      toFileURL: toFileURL,
      stageFileIfNeeded: stageFileIfNeeded
    });

    // Metricas — inicializa modulo
    MetricsManager.init(state, {
      getStockFolder: getStockFolder,
      showToast: showToast,
      toggleSettings: toggleSettings,
      cs: cs
    });

    // Auto-update — verificacao imediata + intervalo de 2h
    UpdateManager.init(state, saveState);
    UpdateManager.check();
    UpdateManager.schedulePeriodicCheck();

    // Dev hot reload: Ctrl+Shift+R recarrega o painel
    document.addEventListener("keydown", function(e) {
      if (e.ctrlKey && e.shiftKey && e.key === "R") {
        e.preventDefault();
        location.reload();
      }
    });
  } catch (e) {
    alert("StockHub init error: " + e.toString());
  }
}

init();
