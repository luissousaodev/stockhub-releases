// =============================================================================
// ui/render.js — Rendering do grid, categorias e filtering
// =============================================================================

if (!state.expandedCategories) state.expandedCategories = {};

// --- Filtering ---
function getFilteredFiles() {
  return state.files.filter(function(f) {
    if (state.activeFormat !== "all" && f.type !== state.activeFormat) return false;
    if (state.activeCategory === "__favorites") {
      if (!state.favoriteFiles || !state.favoriteFiles[toRelPath(f.path)]) return false;
    } else if (state.activeCategory !== "all") {
      if (f.category !== state.activeCategory) {
        if (f.category && f.category.indexOf(state.activeCategory + "/") === 0) {
          // match — subcategoria do pai ativo
        } else {
          return false;
        }
      }
    }
    if (state.searchQuery) {
      var q = state.searchQuery.toLowerCase();
      if (f.name.toLowerCase().indexOf(q) >= 0) return true;
      var tags = state.fileTags && state.fileTags[toRelPath(f.path)];
      if (tags) {
        for (var t = 0; t < tags.length; t++) {
          if (tags[t].indexOf(q) >= 0) return true;
        }
      }
      return false;
    }
    return true;
  });
}

// --- Categories ---
function getCatFileCount(catId, isSystem) {
  if (isSystem) return state.files.length;
  return state.files.filter(function(f) {
    return f.category === catId || (f.category && f.category.indexOf(catId + "/") === 0);
  }).length;
}

function toggleCategoryExpand(catId, e) {
  e.stopPropagation();
  state.expandedCategories[catId] = !state.expandedCategories[catId];
  renderCategories();
}

function renderCatItem(cat, isSub, childrenMap) {
  var children = childrenMap[cat.id] || [];
  var hasChildren = children.length > 0;
  var isExpanded = state.expandedCategories[cat.id];
  var count = isSub
    ? state.files.filter(function(f) { return f.category === cat.id; }).length
    : getCatFileCount(cat.id, cat.system);

  var arrow = '';
  if (hasChildren && !cat.system) {
    arrow = '<span class="cat-arrow ' + (isExpanded ? "expanded" : "") + '" ' +
      'onclick="toggleCategoryExpand(\'' + cat.id + '\', event)">' +
      '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
        '<polyline points="9 18 15 12 9 6"/>' +
      '</svg></span>';
  }

  var ctxMenu = cat.system ? '' : 'oncontextmenu="showCatContextMenu(event, \'' + cat.id + '\')"';

  var isActive = state.activeCategory === cat.id;
  var isParentActive = !isActive && typeof state.activeCategory === "string" &&
    state.activeCategory.indexOf(cat.id + "/") === 0;
  var stateClass = isActive ? "active" : (isParentActive ? "parent-active" : "");
  var html = '<div class="cat-item ' + (isSub ? "cat-sub " : "") + stateClass + '" ' +
    'onclick="setCategory(\'' + cat.id + '\')" ' +
    ctxMenu + ' ' +
    'ondragover="onCatDragOver(event)" ' +
    'ondragleave="onCatDragLeave(event)" ' +
    'ondrop="onCatDrop(event, \'' + cat.id + '\')">' +
    '<span style="display:flex;align-items:center;gap:6px;overflow:hidden;">' +
      arrow +
      '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + cat.name + '</span>' +
    '</span>' +
    '<span class="cat-count">' + count + '</span>' +
  '</div>';

  if (hasChildren && isExpanded) {
    html += '<div class="cat-sub-group">';
    for (var c = 0; c < children.length; c++) {
      html += renderCatItem(children[c], true, childrenMap);
    }
    html += '</div>';
  }

  return html;
}

function getFavoriteCount() {
  if (!state.favoriteFiles) return 0;
  var count = 0;
  for (var i = 0; i < state.files.length; i++) {
    if (state.favoriteFiles[toRelPath(state.files[i].path)]) count++;
  }
  return count;
}

function renderCategories() {
  var list = document.getElementById("categoryList");
  var html = "";

  // Favorites section — always on top
  var favCount = getFavoriteCount();
  html += '<div class="cat-item ' + (state.activeCategory === "__favorites" ? "active" : "") + '" ' +
    'onclick="setCategory(\'__favorites\')" ' +
    'ondragover="onCatDragOver(event)" ' +
    'ondragleave="onCatDragLeave(event)" ' +
    'ondrop="onFavoritesDrop(event)">' +
    '<span style="display:flex;align-items:center;gap:6px;overflow:hidden;">' +
      '<svg width="11" height="11" viewBox="0 0 24 24" fill="' + (state.activeCategory === "__favorites" ? "#e8a634" : "none") + '" stroke="#e8a634" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
        '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>' +
      '</svg>' +
      '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Favoritos</span>' +
    '</span>' +
    '<span class="cat-count">' + favCount + '</span>' +
  '</div>';

  html += '<div class="cat-divider"></div>';

  var systemCats = [];
  var normalCats = [];
  var childrenMap = {};

  for (var i = 0; i < state.categories.length; i++) {
    var cat = state.categories[i];
    if (cat.parent) {
      if (!childrenMap[cat.parent]) childrenMap[cat.parent] = [];
      childrenMap[cat.parent].push(cat);
    } else if (cat.system) {
      systemCats.push(cat);
    } else {
      normalCats.push(cat);
    }
  }

  for (var s = 0; s < systemCats.length; s++) {
    html += renderCatItem(systemCats[s], false, childrenMap);
  }

  if (normalCats.length > 0) {
    html += '<div class="cat-divider"></div>';
    for (var n = 0; n < normalCats.length; n++) {
      html += renderCatItem(normalCats[n], false, childrenMap);
    }
  }

  list.innerHTML = html;
}

function renderGrid() {
  var grid = document.getElementById("fileGrid");
  var files = getFilteredFiles();

  cleanupPreview();

  document.getElementById("fileCount").textContent = files.length + " arquivos";

  if (files.length === 0) {
    grid.innerHTML = "";
    var container = document.getElementById("gridContainer");
    var emptyEl = container.querySelector(".empty-state");
    if (!emptyEl) {
      emptyEl = document.createElement("div");
      emptyEl.className = "empty-state";
      container.appendChild(emptyEl);
    }

    if (state.files.length === 0) {
      var folder = getStockFolder();
      emptyEl.innerHTML =
        '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round">' +
          '<path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>' +
        '</svg>' +
        '<h3>Nenhum arquivo encontrado</h3>' +
        '<p>Coloque seus stocks na pasta:</p>' +
        '<p style="color:var(--green);font-size:10px;word-break:break-all;">' + folder + '</p>' +
        '<button class="btn btn-primary" onclick="openStockFolder()">Abrir pasta</button>';
    } else {
      emptyEl.innerHTML =
        '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
          '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>' +
        '</svg>' +
        '<h3>Nenhum arquivo encontrado</h3>' +
        '<p>Tente ajustar os filtros ou busca.</p>';
    }
    emptyEl.style.display = "flex";
    return;
  }

  var emptyEl2 = document.getElementById("gridContainer").querySelector(".empty-state");
  if (emptyEl2) emptyEl2.style.display = "none";

  // Selection bar
  var selCount = Object.keys(state.selectedFiles).length;
  var selBar = document.getElementById("selectionBar");
  if (selCount > 0) {
    if (!selBar) {
      selBar = document.createElement("div");
      selBar.id = "selectionBar";
      selBar.className = "selection-bar";
      grid.parentNode.insertBefore(selBar, grid);
    }
    selBar.innerHTML =
      '<span>' + selCount + ' arquivo' + (selCount > 1 ? 's' : '') + ' selecionado' + (selCount > 1 ? 's' : '') + '</span>' +
      '<div class="selection-actions">' +
        '<button id="batchTimelineBtn">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
            '<polygon points="5 3 19 12 5 21 5 3"/>' +
          '</svg>' +
          'Timeline' +
        '</button>' +
        '<button id="batchImportBtn">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
            '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>' +
          '</svg>' +
          'Importar' +
        '</button>' +
        '<button id="clearSelectionBtn">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
            '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>' +
          '</svg>' +
          'Limpar' +
        '</button>' +
      '</div>';
    selBar.querySelector("#batchTimelineBtn").addEventListener("click", batchInsertToTimeline);
    selBar.querySelector("#batchImportBtn").addEventListener("click", batchImportSelected);
    selBar.querySelector("#clearSelectionBtn").addEventListener("click", clearSelection);
  } else if (selBar) {
    selBar.remove();
  }

  grid.style.gridTemplateColumns = "repeat(auto-fill, minmax(" + state.gridSize + "px, 1fr))";

  var fileIndexMap = {};
  for (var m = 0; m < state.files.length; m++) {
    fileIndexMap[state.files[m].path] = m;
  }

  grid.innerHTML = files.map(function(f) {
    var thumb = getThumbnail(f);
    var idx = fileIndexMap[f.path];
    var badgeClass = "badge-" + (f.type || "video");
    var res = resolutionCache[f.path] || "";

    var thumbContent;
    if (thumb) {
      thumbContent = '<img class="thumbnail" src="' + thumb + '" loading="lazy" />';
    } else if (f.type === "video" && thumbCache[f.path]) {
      thumbContent = '<img class="thumbnail" src="' + thumbCache[f.path] + '" loading="lazy" />';
    } else if (f.type === "image") {
      thumbContent = '<img class="thumbnail" src="' + toFileURL(f.path) + '" loading="lazy" />';
    } else {
      var iconSvg;
      if (f.type === "audio") {
        iconSvg = '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>';
      } else {
        iconSvg = '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>';
      }
      thumbContent = '<div class="placeholder">' +
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
              iconSvg +
            '</svg>' +
            '<span style="font-size:9px;">' + f.ext.toUpperCase() + '</span>' +
          '</div>';
    }

    var cloudBadge = f.cloudOnly
      ? '<span class="cloud-badge" title="Arquivo na nuvem (nao baixado)">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M18 10h-1.26A8 8 0 109 20h9a5 5 0 000-10z"/>' +
          '</svg>' +
        '</span>'
      : '';

    var isSelected = state.selectedFiles[idx];

    return '<div class="grid-item' + (f.cloudOnly ? ' cloud-only' : '') + (isSelected ? ' selected' : '') + '" ' +
      'data-filepath="' + f.path.replace(/"/g, '&quot;') + '" ' +
      'data-rel="' + toRelPath(f.path).replace(/"/g, '&quot;') + '" ' +
      'draggable="true" ' +
      'ondragstart="onFileDragStart(event, ' + idx + ')" ' +
      'ondragend="onFileDragEnd(event, ' + idx + ')" ' +
      'ondblclick="onDoubleClick(' + idx + ')" ' +
      'oncontextmenu="showContextMenu(event, ' + idx + ')" ' +
      'onmouseenter="onMouseEnter(this, ' + idx + ')" ' +
      'onmouseleave="onMouseLeave(this)" ' +
      'title="' + f.name + (f.cloudOnly ? " (na nuvem)" : "") + '">' +
      thumbContent +
      cloudBadge +
      '<span class="file-badge ' + badgeClass + '">' + f.ext + '</span>' +
      '<span class="res-badge">' + res + '</span>' +
      '<button class="import-btn" onclick="event.stopPropagation(); importToProject(' + idx + ')" title="Importar no projeto">' +
        '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
          '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>' +
        '</svg>' +
      '</button>' +
      '<span class="file-name">' + f.name.replace(/\.[^.]+$/, "") + '</span>' +
      (function() {
        var tags = state.fileTags && state.fileTags[toRelPath(f.path)];
        if (!tags || tags.length === 0) return '';
        return '<span class="tag-badge" title="' + tags.join(', ') + '">' +
          '<svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor" stroke="none">' +
            '<path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/>' +
          '</svg>' +
          tags.length +
        '</span>';
      })() +
    '</div>';
  }).join("");

  if (typeof setupViewportObserver === "function") setupViewportObserver();
}

// --- Multi-select ---
function toggleFileSelection(fileIndex, e) {
  if (e && e.ctrlKey) {
    if (state.selectedFiles[fileIndex]) {
      delete state.selectedFiles[fileIndex];
    } else {
      state.selectedFiles[fileIndex] = true;
    }
  } else if (e && e.shiftKey && state._lastSelectedIndex !== undefined) {
    var from = Math.min(state._lastSelectedIndex, fileIndex);
    var to = Math.max(state._lastSelectedIndex, fileIndex);
    var filtered = getFilteredFiles();
    var fileIndexMap = {};
    for (var m = 0; m < state.files.length; m++) fileIndexMap[state.files[m].path] = m;
    for (var i = 0; i < filtered.length; i++) {
      var idx = fileIndexMap[filtered[i].path];
      if (idx >= from && idx <= to) state.selectedFiles[idx] = true;
    }
  } else {
    state.selectedFiles = {};
    state.selectedFiles[fileIndex] = true;
  }
  state._lastSelectedIndex = fileIndex;
  renderGrid();
}

function clearSelection() {
  state.selectedFiles = {};
  renderGrid();
}

function batchImportSelected() {
  var indices = Object.keys(state.selectedFiles).map(Number);
  if (indices.length === 0) return;

  var total = indices.length;
  var done = 0;
  var errors = 0;

  function importNext() {
    if (done >= total) {
      var msg = "Batch import: " + (total - errors) + "/" + total + " importados";
      if (errors > 0) msg += " (" + errors + " erro" + (errors > 1 ? "s" : "") + ")";
      showToast(msg);
      state.selectedFiles = {};
      renderGrid();
      return;
    }
    var idx = indices[done];
    var file = state.files[idx];
    if (!file) { done++; errors++; importNext(); return; }
    var importPath = stageFileIfNeeded(file);
    var escapedPath = importPath.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
    cs.evalScript("importFileToProject('" + escapedPath + "')", function(result) {
      done++;
      try {
        var res = JSON.parse(result);
        if (res.success && !res.alreadyExists) trackEvent(file, "import");
        if (!res.success) errors++;
      } catch (e) { errors++; }
      document.getElementById("statusText").textContent = "Importando... " + done + "/" + total;
      importNext();
    });
  }

  document.getElementById("statusText").textContent = "Importando... 0/" + total;
  importNext();
}

function renderAll() {
  renderCategories();
  renderGrid();
}
