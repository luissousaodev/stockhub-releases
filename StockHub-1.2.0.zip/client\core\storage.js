// =============================================================================
// core/storage.js — Utilitarios de path e storage
// =============================================================================

// Garante acesso a 'path' tanto no browser (global via platform.js) como no Node (testes)
if (typeof path === "undefined" && typeof require === "function") {
  var path = require("path");
}

// Funcoes puras testaveis
function _toFileURL(p) {
  if (!p) return p;
  var normalized = String(p).replace(/\\/g, "/");
  if (normalized.charAt(0) === "/") {
    return "file://" + normalized;
  }
  return "file:///" + normalized;
}

function _migrateAbsoluteKeysToRelative(dict, stockFolder) {
  if (!dict) return dict;
  var out = {};
  var keys = Object.keys(dict);
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    var isAbs = (k.length > 2 && k.charAt(1) === ":") || k.charAt(0) === "/" || k.charAt(0) === "\\";
    if (!isAbs) {
      out[k] = dict[k];
      continue;
    }
    try {
      var rel = path.relative(stockFolder, k);
      if (!rel || rel.indexOf("..") === 0) continue;
      out[rel.split(path.sep).join("/")] = dict[k];
    } catch (e) { /* path fora da pasta — descarta */ }
  }
  return out;
}

// Node.js exports para testes
if (typeof module !== "undefined") {
  module.exports = {
    _toFileURL: _toFileURL,
    _migrateAbsoluteKeysToRelative: _migrateAbsoluteKeysToRelative
  };
}

// Browser globals
if (typeof window !== "undefined") {
  // toFileURL — alias global (usado por todos os modulos)
  window.toFileURL = _toFileURL;

  // migrateAbsoluteKeysToRelative — usado apenas por state.js
  window.migrateAbsoluteKeysToRelative = _migrateAbsoluteKeysToRelative;

  // getStoragePath — retorna caminho do stockhub-data.json
  window.getStoragePath = function() {
    var dataDir = cs.getSystemPath(SystemPath.USER_DATA);
    return path.join(dataDir, "stockhub-data.json");
  };

  // toRelPath — converte path absoluto para relativo a pasta de stock
  window.toRelPath = function(absPath) {
    if (!absPath) return absPath;
    try {
      var rel = path.relative(getStockFolder(), absPath);
      if (!rel || rel.indexOf("..") === 0) return absPath;
      return rel.split(path.sep).join("/");
    } catch (e) {
      return absPath;
    }
  };
}
