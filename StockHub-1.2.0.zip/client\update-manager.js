// =============================================================================
// update-manager.js — Módulo de auto-update do StockHub
// Responsabilidades:
//   - Verificar periodicamente se há nova versão no repositório de releases
//   - Exibir modal informativo com notas de versão
//   - Persistir estado de "adiado" para re-avisar após 2 horas
//   - Baixar, extrair e aplicar o update automaticamente (Windows e macOS)
// =============================================================================

// --- Funções puras testáveis (fora da IIFE para serem exportáveis via Node) ---

/**
 * Compara duas strings de versão semântica (ex: "1.2.0" vs "1.1.0").
 * Retorna: 1 se a > b, -1 se a < b, 0 se iguais ou inválidas.
 */
function _compareSemver(a, b) {
  if (!a || !b) return 0;
  var pa = a.split(".").map(Number);
  var pb = b.split(".").map(Number);
  for (var i = 0; i < 3; i++) {
    var na = pa[i] || 0;
    var nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

/**
 * Decide se o modal de update deve ser exibido agora.
 * Lógica:
 *   - Não exibe se outro modal já está aberto (modalIsOpen)
 *   - Exibe imediatamente se a versão remota é diferente da que foi adiada
 *   - Exibe se a mesma versão foi adiada e já passaram >= 2 horas
 *
 * @param {string|null} dismissedVersion - versão que o usuário adiou
 * @param {number|null} dismissedAt      - timestamp (ms) do adiamento
 * @param {string}      remoteVersion    - versão disponível remotamente
 * @param {boolean}     modalIsOpen      - true se #modalContainer tem conteúdo
 * @returns {boolean}
 */
function _shouldShowUpdate(dismissedVersion, dismissedAt, remoteVersion, modalIsOpen) {
  if (modalIsOpen) return false;
  if (dismissedVersion !== remoteVersion) return true;
  if (!dismissedAt) return true;
  return (Date.now() - dismissedAt) >= 2 * 60 * 60 * 1000;
}

// Exporta para testes Node (no browser, `module` é undefined — branch ignorado)
if (typeof module !== "undefined") {
  module.exports = { _compareSemver: _compareSemver, _shouldShowUpdate: _shouldShowUpdate };
}

// =============================================================================
// IIFE principal — expõe window.UpdateManager
// =============================================================================
var UpdateManager = (function () {

  // ---------------------------------------------------------------------------
  // Node built-ins (disponíveis via CEP com Node.js habilitado)
  // ---------------------------------------------------------------------------
  var _fs    = (typeof require !== "undefined") ? require("fs")             : null;
  var _path  = (typeof require !== "undefined") ? require("path")           : null;
  var _https = (typeof require !== "undefined") ? require("https")          : null;
  var _child = (typeof require !== "undefined") ? require("child_process")  : null;
  var _os    = (typeof require !== "undefined") ? require("os")             : null;

  // ---------------------------------------------------------------------------
  // Estado privado
  // ---------------------------------------------------------------------------
  var _pendingUrl     = null;   // downloadUrl da versão remota
  var _pendingVersion = null;   // string da versão remota
  var _pendingNotes   = null;   // notas de versão (features) — vazio = bugfix
  var _intervalId     = null;   // handle do setInterval de verificação periódica
  var _stateRef       = null;   // referência viva ao objeto `state` do app.js
  var _saveStateFn    = null;   // referência à função saveState() do app.js

  // URL do version.json no repositório de releases
  var UPDATE_CHECK_URL =
    "https://raw.githubusercontent.com/luissousaodev/stockhub-releases/refs/heads/main/version.json";

  // ---------------------------------------------------------------------------
  // Helpers de rede
  // ---------------------------------------------------------------------------

  /**
   * GET HTTPS com suporte a redirect. Chama cb(err, body).
   */
  function _httpsGet(url, cb) {
    _https.get(url, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return _httpsGet(res.headers.location, cb);
      }
      if (res.statusCode !== 200) {
        return cb(new Error("HTTP " + res.statusCode));
      }
      var data = "";
      res.on("data", function (c) { data += c; });
      res.on("end",  function ()  { cb(null, data); });
    }).on("error", function (e) { cb(e); });
  }

  /**
   * Download de arquivo para disco com callback de progresso.
   * progressCb(received, total) — total pode ser 0 se Content-Length ausente.
   */
  function _downloadFile(url, dest, progressCb, cb) {
    var file = _fs.createWriteStream(dest);
    _https.get(url, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        file.close();
        try { _fs.unlinkSync(dest); } catch (e) { Logger.warn("update", "cleanup redirect temp failed", e.message); }
        return _downloadFile(res.headers.location, dest, progressCb, cb);
      }
      if (res.statusCode !== 200) {
        file.close();
        return cb(new Error("HTTP " + res.statusCode));
      }
      var total    = parseInt(res.headers["content-length"] || "0", 10);
      var received = 0;
      res.on("data", function (chunk) {
        received += chunk.length;
        if (progressCb) progressCb(received, total);
      });
      res.pipe(file);
      file.on("finish", function () { file.close(function () { cb(null); }); });
    }).on("error", function (e) { file.close(); cb(e); });
  }

  // ---------------------------------------------------------------------------
  // Helpers de sistema de arquivos
  // ---------------------------------------------------------------------------

  /**
   * Cópia recursiva de diretório.
   * skipHidden=true: ignora entradas cujo nome começa com "." (ex: .git, .debug)
   * — necessário ao fazer backup da pasta de extensão em ambiente de dev,
   *   onde a pasta contém .git/ com arquivos read-only que quebram no Windows.
   */
  function _copyDirSync(src, dest, skipHidden) {
    if (!_fs.existsSync(src)) return;
    _fs.mkdirSync(dest, { recursive: true });
    var names = _fs.readdirSync(src);
    for (var i = 0; i < names.length; i++) {
      if (skipHidden && names[i].charAt(0) === ".") continue;
      var s = _path.join(src, names[i]);
      var d = _path.join(dest, names[i]);
      if (_fs.statSync(s).isDirectory()) { _copyDirSync(s, d, skipHidden); }
      else                               { _fs.copyFileSync(s, d); }
    }
  }

  /** Remoção recursiva de diretório. */
  function _rmDirSync(dir) {
    if (!_fs.existsSync(dir)) return;
    var names = _fs.readdirSync(dir);
    for (var i = 0; i < names.length; i++) {
      var p = _path.join(dir, names[i]);
      if (_fs.statSync(p).isDirectory()) { _rmDirSync(p); }
      else                               { _fs.unlinkSync(p); }
    }
    _fs.rmdirSync(dir);
  }

  /**
   * Encontra a raiz da extensão dentro do ZIP extraído.
   * Lida com ZIPs que têm uma pasta wrapper (ex: stockhub-1.2.0/).
   */
  function _findExtractedRoot(dir) {
    var items = _fs.readdirSync(dir);
    if (items.indexOf("CSXS") !== -1 || items.indexOf("client") !== -1) return dir;
    if (items.length === 1) {
      var sub = _path.join(dir, items[0]);
      if (_fs.statSync(sub).isDirectory()) return _findExtractedRoot(sub);
    }
    return dir;
  }

  // ---------------------------------------------------------------------------
  // Modal helpers — fases do processo de atualização
  // ---------------------------------------------------------------------------

  /**
   * Fase 1: substitui o modal pelo estado de DOWNLOAD com barra de progresso.
   */
  function _showPhaseDownload() {
    var mc = document.getElementById("modalContainer");
    if (!mc) return;
    mc.innerHTML =
      '<div class="modal-overlay">' +
        '<div class="modal update-modal" onclick="event.stopPropagation()">' +
          '<div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">' +
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" ' +
                'stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>' +
              '<polyline points="7 10 12 15 17 10"/>' +
              '<line x1="12" y1="15" x2="12" y2="3"/>' +
            '</svg>' +
            '<h3 style="margin:0;">Baixando atualização…</h3>' +
          '</div>' +
          '<p style="font-size:11px;color:var(--text-secondary);margin:0 0 14px;">' +
            'Baixando StockHub v' + (_pendingVersion || "") + '.' +
          '</p>' +
          '<div style="height:4px;background:var(--bg-primary);border-radius:2px;overflow:hidden;' +
               'position:relative;margin-bottom:6px;">' +
            '<div id="updateProgressBar" style="height:100%;width:0%;background:var(--accent);' +
                 'transition:width 0.3s;border-radius:2px;"></div>' +
          '</div>' +
          '<div id="updateProgressLabel" style="font-size:10px;color:var(--text-muted);text-align:right;">0%</div>' +
        '</div>' +
      '</div>';
  }

  /**
   * Fase 2: substitui o modal pelo estado de INSTALAÇÃO com spinner.
   */
  function _showPhaseInstalling() {
    var mc = document.getElementById("modalContainer");
    if (!mc) return;
    mc.innerHTML =
      '<div class="modal-overlay">' +
        '<div class="modal update-modal" onclick="event.stopPropagation()">' +
          '<div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">' +
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" ' +
                'stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ' +
                'style="animation:spinIcon 1s linear infinite;flex-shrink:0;">' +
              '<path d="M21 12a9 9 0 11-6.22-8.56"/>' +
            '</svg>' +
            '<h3 style="margin:0;">Instalando…</h3>' +
          '</div>' +
          '<p style="font-size:11px;color:var(--text-secondary);margin:0 0 14px;line-height:1.6;">' +
            'Extraindo e copiando os arquivos da v' + (_pendingVersion || "") + '.' +
            '<br>Não feche o Premiere durante este processo.' +
          '</p>' +
          '<div style="height:4px;background:var(--bg-primary);border-radius:2px;overflow:hidden;position:relative;">' +
            '<div style="height:100%;width:100%;background:var(--accent);border-radius:2px;' +
                 'animation:progressIndeterminate 1.4s infinite linear;position:absolute;"></div>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  /**
   * Fase 3: substitui o modal pela tela de CONCLUSÃO.
   * Instrui o usuário a recarregar com Ctrl+Shift+R ou reiniciar o Premiere.
   */
  function _showPhaseDone() {
    var mc = document.getElementById("modalContainer");
    if (!mc) return;
    var oldVer = window.APP_VERSION || "?";
    var newVer = _pendingVersion || "?";
    mc.innerHTML =
      '<div class="modal-overlay">' +
        '<div class="modal update-modal" onclick="event.stopPropagation()">' +

          '<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">' +
            '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" ' +
                'stroke="var(--accent)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>' +
              '<polyline points="22 4 12 14.01 9 11.01"/>' +
            '</svg>' +
            '<h3 style="margin:0;color:var(--accent);">Atualização concluída!</h3>' +
          '</div>' +

          '<div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;">' +
            '<span style="font-size:11px;color:var(--text-secondary);">Versão:</span>' +
            '<span style="font-size:11px;font-weight:600;color:var(--text-muted);">v' + oldVer + '</span>' +
            '<span style="color:var(--accent);font-size:14px;">→</span>' +
            '<span style="font-size:13px;font-weight:600;color:var(--accent);">v' + newVer + '</span>' +
          '</div>' +

          '<p style="font-size:11px;color:var(--text-secondary);line-height:1.7;margin:0 0 14px;">' +
            'Os arquivos foram atualizados com sucesso.<br>' +
            'Recarregando o painel em <strong id="updateCountdown">3</strong> segundos…' +
          '</p>' +

          '<div class="modal-actions">' +
            '<button class="btn btn-primary" onclick="location.reload()">Recarregar agora</button>' +
          '</div>' +

        '</div>' +
      '</div>';

    // Auto-reload com countdown
    var count = 3;
    var countdownEl = document.getElementById("updateCountdown");
    var timer = setInterval(function () {
      count--;
      if (countdownEl) countdownEl.textContent = String(count);
      if (count <= 0) {
        clearInterval(timer);
        location.reload();
      }
    }, 1000);
  }

  /** Atualiza a barra de progresso durante a fase de download. */
  function _showProgress(received, total) {
    var bar   = document.getElementById("updateProgressBar");
    var label = document.getElementById("updateProgressLabel");
    if (!bar || !label) return;
    if (total > 0) {
      var pct = Math.round((received / total) * 100);
      bar.style.width = pct + "%";
      label.textContent = pct + "%";
    } else {
      bar.style.width = "100%";
      label.textContent = "Baixando…";
    }
  }

  // ---------------------------------------------------------------------------
  // API pública
  // ---------------------------------------------------------------------------

  /**
   * Inicializa o módulo guardando referências ao estado do app.
   * Deve ser chamado UMA vez, dentro de init() no app.js.
   *
   * @param {object}   stateObj    - o objeto `state` vivo do app.js
   * @param {function} saveStateFn - a função saveState() do app.js
   */
  function init(stateObj, saveStateFn) {
    _stateRef    = stateObj;
    _saveStateFn = saveStateFn;

    // Limpa timestamps de dismiss ao iniciar/reiniciar o painel,
    // garantindo que o check() sempre mostre o modal se houver update.
    if (_stateRef) {
      _stateRef.updateDismissedVersion = null;
      _stateRef.lastUpdateDismissedAt  = null;
    }
    if (_saveStateFn) _saveStateFn();
  }

  /**
   * Verifica o repositório de releases em busca de nova versão.
   * Se encontrar, decide se exibe o modal baseado no estado de "adiado".
   */
  function check() {
    if (!_https) return; // ambiente sem Node (ex: testes DOM-only)
    _httpsGet(UPDATE_CHECK_URL, function (err, body) {
      if (err) return; // falha silenciosa — sem internet ou repositório offline
      try {
        var remote = JSON.parse(body);
        if (!remote.version) return;
        // Só age se a versão remota for maior que a instalada
        if (_compareSemver(remote.version, window.APP_VERSION) <= 0) return;

        _pendingUrl     = remote.downloadUrl || null;
        _pendingVersion = remote.version;
        _pendingNotes   = remote.notes || "";

        // Verifica se o modal de outro contexto já está aberto
        var mc        = document.getElementById("modalContainer");
        var isOpen    = mc ? mc.innerHTML.trim() !== "" : false;
        var dismissed = _stateRef ? _stateRef.updateDismissedVersion : null;
        var dismissAt = _stateRef ? _stateRef.lastUpdateDismissedAt  : null;

        if (_shouldShowUpdate(dismissed, dismissAt, remote.version, isOpen)) {
          showModal(remote.version, remote.notes || "");
        }
      } catch (e) { /* JSON inválido — ignora */ }
    });
  }

  /**
   * Exibe o modal de atualização disponível.
   *
   * @param {string} version - versão disponível (ex: "1.2.0")
   * @param {string} notes   - notas de versão (pode ser string vazia)
   */
  function showModal(version, notes) {
    var mc = document.getElementById("modalContainer");
    if (!mc) return;

    var currentVersion = window.APP_VERSION || "?";

    var notesBlock = notes
      ? '<div class="update-notes">' + notes + '</div>'
      : "";

    mc.innerHTML =
      '<div class="modal-overlay" onclick="UpdateManager.dismiss()">' +
        '<div class="modal update-modal" onclick="event.stopPropagation()">' +

          // Título com ícone de download
          '<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">' +
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" ' +
                'stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>' +
              '<polyline points="7 10 12 15 17 10"/>' +
              '<line x1="12" y1="15" x2="12" y2="3"/>' +
            '</svg>' +
            '<h3 style="margin:0;">Atualização disponível</h3>' +
          '</div>' +

          // Linha de versão: atual → nova
          '<div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">' +
            '<span style="font-size:11px;color:var(--text-secondary);">Versão atual:</span>' +
            '<span style="font-size:11px;font-weight:600;color:var(--text-muted);">v' + currentVersion + '</span>' +
            '<span style="color:var(--accent);font-size:14px;">→</span>' +
            '<span style="font-size:13px;font-weight:600;color:var(--accent);">v' + version + '</span>' +
          '</div>' +

          // Notas de versão (opcional)
          notesBlock +

          // Barra de progresso (oculta até o download iniciar)
          '<div id="updateProgressWrap" style="display:none;margin-bottom:12px;">' +
            '<div style="height:4px;background:var(--bg-primary);border-radius:2px;overflow:hidden;position:relative;">' +
              '<div id="updateProgressBar" ' +
                   'style="height:100%;width:0%;background:var(--accent);transition:width 0.2s;border-radius:2px;">' +
              '</div>' +
            '</div>' +
            '<div id="updateProgressLabel" ' +
                 'style="font-size:10px;color:var(--text-muted);margin-top:4px;text-align:right;">0%</div>' +
          '</div>' +

          // Botões de ação
          '<div class="modal-actions">' +
            '<button class="btn" id="updateDismissBtn" onclick="UpdateManager.dismiss()">' +
              'Lembrar mais tarde' +
            '</button>' +
            '<button class="btn btn-primary" id="updateNowBtn" onclick="UpdateManager.performUpdate()">' +
              'Atualizar agora' +
            '</button>' +
          '</div>' +

        '</div>' +
      '</div>';
  }

  /**
   * Adia o aviso de update.
   * Grava a versão e o timestamp atual no state para religar o aviso após 2h.
   */
  function dismiss() {
    if (_stateRef) {
      _stateRef.lastUpdateDismissedAt  = Date.now();
      _stateRef.updateDismissedVersion = _pendingVersion;
    }
    if (_saveStateFn) _saveStateFn();

    // Limpa o modalContainer (fecha o modal)
    var mc = document.getElementById("modalContainer");
    if (mc) mc.innerHTML = "";
  }

  /**
   * Executa o processo de atualização automática:
   *   1. Verifica permissão de escrita
   *   2. Baixa o ZIP com barra de progresso
   *   3. Cria backup
   *   4. Extrai (PowerShell no Windows, unzip no macOS)
   *   5. Copia arquivos novos preservando dados do usuário
   *   6. Limpa temporários e recarrega o painel
   */
  function performUpdate() {
    if (!_pendingUrl) {
      if (typeof showToast === "function") showToast("URL de download não disponível");
      return;
    }

    var extensionDir = _path.join(__dirname, "..");
    var tempDir      = _path.join(_os.tmpdir(), "stockhub-update");
    var zipPath      = _path.join(_os.tmpdir(), "stockhub-update.zip");
    var backupDir    = _path.join(_os.tmpdir(), "stockhub-backup-" + (window.APP_VERSION || "old"));
    var isWin        = process.platform === "win32";

    // 1. Verificar permissão de escrita na pasta da extensão
    try {
      _fs.accessSync(extensionDir, _fs.constants.W_OK);
    } catch (e) {
      var mc = document.getElementById("modalContainer");
      if (mc) {
        mc.innerHTML =
          '<div class="modal-overlay" onclick="closeModal(event)">' +
            '<div class="modal" onclick="event.stopPropagation()" style="max-width:420px;">' +
              '<h3 style="margin:0 0 8px;">Atualização manual necessária</h3>' +
              '<p style="font-size:11px;color:var(--text-secondary);line-height:1.5;">' +
                'Sem permissão de escrita na pasta da extensão. ' +
                'Instale o StockHub em user-scope para habilitar o auto-update.' +
              '</p>' +
              '<p style="font-size:10px;color:var(--text-muted);margin:8px 0;word-break:break-all;">' +
                extensionDir +
              '</p>' +
              '<div class="modal-actions">' +
                '<button class="btn btn-primary" onclick="closeModal()">Entendi</button>' +
              '</div>' +
            '</div>' +
          '</div>';
      }
      return;
    }

    // 2. Fase DOWNLOAD — troca o modal pela tela de download com barra de progresso
    _showPhaseDownload();

    _downloadFile(_pendingUrl, zipPath, _showProgress, function (err) {
      if (err) {
        // Volta ao modal original com botão "Tentar novamente"
        showModal(_pendingVersion, "");
        var nowBtn = document.getElementById("updateNowBtn");
        if (nowBtn) { nowBtn.textContent = "Tentar novamente"; }
        if (typeof showToast === "function") showToast("Erro no download: " + err.message);
        return;
      }

      // 3. Fase INSTALANDO — troca o modal pelo spinner enquanto extrai/copia
      _showPhaseInstalling();

      try {
        // 3a. Backup de segurança (skipHidden=true: ignora .git, .debug, etc.)
        if (_fs.existsSync(backupDir)) _rmDirSync(backupDir);
        _copyDirSync(extensionDir, backupDir, true);

        // 4. Extrair ZIP
        if (_fs.existsSync(tempDir)) _rmDirSync(tempDir);
        _fs.mkdirSync(tempDir, { recursive: true });

        var extractCmd = isWin
          ? 'powershell -Command "Expand-Archive -Path \'' + zipPath.replace(/'/g, "''") + '\' -DestinationPath \'' + tempDir.replace(/'/g, "''") + '\' -Force"'
          : 'unzip -o "' + zipPath + '" -d "' + tempDir + '"';

        _child.execSync(extractCmd, { timeout: 30000 });

        // 5. Copiar arquivos novos, preservando dados do usuário
        var sourceRoot = _findExtractedRoot(tempDir);
        var names      = _fs.readdirSync(sourceRoot);
        var skip       = [".cache", "stockhub-data.json", ".debug", "stockhub-updates"];

        for (var i = 0; i < names.length; i++) {
          if (skip.indexOf(names[i]) !== -1) continue;
          var s = _path.join(sourceRoot, names[i]);
          var d = _path.join(extensionDir, names[i]);
          if (_fs.statSync(s).isDirectory()) { _copyDirSync(s, d); }
          else                               { _fs.copyFileSync(s, d); }
        }

        // 6. Forçar gravação do version.json com a versão nova
        //    Garante que após reload o APP_VERSION reflita a atualização.
        //    O campo "notes" é usado pelo modal pós-update para decidir
        //    se mostra features ou apenas "correção de bugs".
        try {
          var versionFile = _path.join(extensionDir, "version.json");
          var versionData = {
            version: _pendingVersion,
            date: new Date().toISOString().slice(0, 10),
            notes: _pendingNotes || ""
          };
          _fs.writeFileSync(versionFile, JSON.stringify(versionData, null, 2), "utf-8");
        } catch (e3) { /* melhor esforço */ }

        // 7. Limpar temporários
        try { _fs.unlinkSync(zipPath); } catch (e) { Logger.warn("update", "cleanup zip failed", e.message); }
        try { _rmDirSync(tempDir); }     catch (e) { Logger.warn("update", "cleanup tempDir failed", e.message); }

        // 8. Fase CONCLUÍDA — instrui o usuário a recarregar
        _showPhaseDone();

      } catch (e) {
        // Fase ERRO — restaura backup e volta ao modal com opção de tentar novamente
        try {
          if (_fs.existsSync(backupDir)) _copyDirSync(backupDir, extensionDir, true);
        } catch (restoreErr) { /* melhor esforço */ }

        showModal(_pendingVersion, "");
        var nowBtn2 = document.getElementById("updateNowBtn");
        if (nowBtn2) { nowBtn2.textContent = "Tentar novamente"; }
        if (typeof showToast === "function") {
          showToast("Erro na instalação — backup restaurado: " + e.message);
        }
      }
    });
  }

  /**
   * Agenda verificações periódicas de update.
   * Limpa qualquer intervalo anterior para evitar vazamento de memória.
   *
   * @param {number} [intervalMs=7200000] - intervalo em ms (padrão: 2 horas)
   */
  function schedulePeriodicCheck(intervalMs) {
    intervalMs = intervalMs || (2 * 60 * 60 * 1000);
    if (_intervalId !== null) {
      clearInterval(_intervalId);
      _intervalId = null;
    }
    _intervalId = setInterval(function () { check(); }, intervalMs);
  }

  /**
   * Cancela o intervalo periódico.
   * Chamar ao desmontar o painel (boa prática, mesmo que CEP não garanta o evento).
   */
  function destroy() {
    if (_intervalId !== null) {
      clearInterval(_intervalId);
      _intervalId = null;
    }
  }

  // ---------------------------------------------------------------------------
  // Exposição da API pública
  // ---------------------------------------------------------------------------
  return {
    init:                 init,
    check:                check,
    showModal:            showModal,
    dismiss:              dismiss,
    performUpdate:        performUpdate,
    schedulePeriodicCheck: schedulePeriodicCheck,
    destroy:              destroy
  };

})();
