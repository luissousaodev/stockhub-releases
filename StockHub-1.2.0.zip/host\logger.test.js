// logger.test.js — Testes para core/logger.js
// Roda em Node.js puro, sem dependencias de browser

var assert = require("assert");
var Logger = require("../client/core/logger.js").Logger;

var passed = 0;
var failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log("  PASS: " + name);
  } catch (e) {
    failed++;
    console.error("  FAIL: " + name + " — " + e.message);
  }
}

console.log("\n=== logger tests ===\n");

// Limpa antes de cada bloco de testes
Logger.clear();

// --- info ---

test("info: adiciona entrada com level info", function() {
  Logger.clear();
  Logger.info("test-mod", "hello");
  var logs = Logger.dump();
  assert.strictEqual(logs.length, 1);
  assert.strictEqual(logs[0].l, "info");
  assert.strictEqual(logs[0].m, "test-mod");
  assert.strictEqual(logs[0].msg, "hello");
});

test("info: com data opcional", function() {
  Logger.clear();
  Logger.info("mod", "msg", { key: "val" });
  var logs = Logger.dump();
  assert.strictEqual(logs[0].d.key, "val");
});

// --- warn ---

test("warn: adiciona entrada com level warn", function() {
  Logger.clear();
  Logger.warn("w-mod", "cuidado");
  var logs = Logger.dump();
  assert.strictEqual(logs.length, 1);
  assert.strictEqual(logs[0].l, "warn");
  assert.strictEqual(logs[0].msg, "cuidado");
});

// --- error ---

test("error: adiciona entrada com level error", function() {
  Logger.clear();
  Logger.error("e-mod", "falha", "detalhe");
  var logs = Logger.dump();
  assert.strictEqual(logs.length, 1);
  assert.strictEqual(logs[0].l, "error");
  assert.strictEqual(logs[0].msg, "falha");
  assert.strictEqual(logs[0].d, "detalhe");
});

// --- dump ---

test("dump: retorna copia do array (nao referencia)", function() {
  Logger.clear();
  Logger.info("a", "1");
  var d1 = Logger.dump();
  var d2 = Logger.dump();
  assert.notStrictEqual(d1, d2);
  assert.deepStrictEqual(d1, d2);
});

// --- clear ---

test("clear: limpa todos os logs", function() {
  Logger.info("a", "1");
  Logger.info("b", "2");
  assert.ok(Logger.dump().length > 0);
  Logger.clear();
  assert.strictEqual(Logger.dump().length, 0);
});

// --- timestamp ---

test("entrada tem timestamp ISO", function() {
  Logger.clear();
  Logger.info("t", "ts");
  var entry = Logger.dump()[0];
  assert.ok(entry.t);
  assert.ok(!isNaN(Date.parse(entry.t)));
});

// --- MAX_MEMORY: limite de 500 entradas ---

test("respeita limite MAX_MEMORY de 500 entradas", function() {
  Logger.clear();
  for (var i = 0; i < 510; i++) {
    Logger.info("bulk", "entry " + i);
  }
  var logs = Logger.dump();
  assert.strictEqual(logs.length, 500);
  // Primeiras 10 devem ter sido descartadas
  assert.strictEqual(logs[0].msg, "entry 10");
});

// --- sem data: campo d nao existe ---

test("sem data: campo d nao existe na entrada", function() {
  Logger.clear();
  Logger.info("mod", "msg");
  var entry = Logger.dump()[0];
  assert.strictEqual(entry.d, undefined);
});

// --- Resumo ---

console.log("\nTotal: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
if (failed > 0) process.exit(1);
