// =============================================================================
// features/staging.js — Staging local de assets cloud
// =============================================================================

function getDefaultStagingFolder() {
  var home = process.env.HOME || process.env.USERPROFILE || "";
  return path.join(home, "StockHub_staging");
}

function getStagingFolder() {
  return state.stagingFolder || getDefaultStagingFolder();
}

function stageFileIfNeeded(file) {
  if (!file || !file.cloudOnly) return file.path;
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size === file.size && st.size > 0) return stagedPath;
    }
  } catch (e) { Logger.warn("staging", "Falha ao verificar staged file", e.message); }
  try {
    fs.mkdirSync(path.dirname(stagedPath), { recursive: true });
    fs.copyFileSync(file.path, stagedPath);
    showToast("Asset copiado para staging local");
    return stagedPath;
  } catch (e) {
    Logger.error("staging", "Staging copy failed", e.message);
    return file.path;
  }
}

function getStagedPathIfExists(file) {
  if (!file || !file.cloudOnly) return null;
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size > 0) return stagedPath;
    }
  } catch (e) { Logger.warn("staging", "Falha ao verificar staged path", e.message); }
  return null;
}

function changeStagingFolder() {
  var result = window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx
    ? window.cep.fs.showOpenDialogEx(false, true, "Escolha a pasta de staging", "")
    : null;
  if (result && result.data && result.data.length > 0) {
    state.stagingFolder = result.data[0];
    saveState();
    var el = document.getElementById("stagingFolderPath");
    if (el) el.textContent = state.stagingFolder;
    showToast("Pasta de staging alterada");
  }
}

function getStagingSize() {
  var folder = getStagingFolder();
  var total = 0;
  function walk(dir) {
    try {
      var items = fs.readdirSync(dir);
      for (var i = 0; i < items.length; i++) {
        var full = path.join(dir, items[i]);
        var st = fs.statSync(full);
        if (st.isDirectory()) walk(full);
        else total += st.size;
      }
    } catch (e) { /* pasta nao acessivel */ }
  }
  try { if (fs.existsSync(folder)) walk(folder); } catch (e) { /* sem folder */ }
  if (total < 1024 * 1024) return (total / 1024).toFixed(1) + " KB";
  if (total < 1024 * 1024 * 1024) return (total / (1024 * 1024)).toFixed(1) + " MB";
  return (total / (1024 * 1024 * 1024)).toFixed(1) + " GB";
}

function clearStagingFolder() {
  var folder = getStagingFolder();
  try {
    fs.rmSync(folder, { recursive: true, force: true });
    fs.mkdirSync(folder, { recursive: true });
    var el = document.getElementById("stagingSize");
    if (el) el.textContent = "0 KB";
    showToast("Staging limpo com sucesso");
  } catch (e) {
    showToast("Erro ao limpar staging: " + e.message);
  }
}
