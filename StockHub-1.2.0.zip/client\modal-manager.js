// =============================================================================
// modal-manager.js — Modulo de modais do StockHub
//
// Responsabilidades:
//   - Carregar e exibir changelog
//   - Modal "Sobre" com versao
//   - Modal "O que ha de novo" (pos-update)
//   - Modal de boas-vindas (primeira execucao)
//   - Modal de identificacao de usuario
//   - Fechar modal generico
//
// Dependencias externas (recebidas via init):
//   - state, saveState, showToast, APP_VERSION
// =============================================================================

// Funcao pura testavel (fora da IIFE)
function _renderChangelogHTML(versions) {
  var html = '';
  for (var i = 0; i < versions.length; i++) {
    var v = versions[i];
    html += '<div class="changelog-version">' +
      '<h4 style="margin:0 0 6px;color:var(--accent);">v' + v.version + ' <span style="font-weight:400;color:var(--text-muted);font-size:10px;">— ' + v.date + '</span></h4>';
    if (v.changes.added && v.changes.added.length) {
      html += '<div class="changelog-section"><span class="changelog-tag changelog-added">Adicionado</span><ul>';
      for (var a = 0; a < v.changes.added.length; a++) html += '<li>' + v.changes.added[a] + '</li>';
      html += '</ul></div>';
    }
    if (v.changes.fixed && v.changes.fixed.length) {
      html += '<div class="changelog-section"><span class="changelog-tag changelog-fixed">Corrigido</span><ul>';
      for (var f = 0; f < v.changes.fixed.length; f++) html += '<li>' + v.changes.fixed[f] + '</li>';
      html += '</ul></div>';
    }
    if (v.changes.changed && v.changes.changed.length) {
      html += '<div class="changelog-section"><span class="changelog-tag changelog-changed">Alterado</span><ul>';
      for (var c = 0; c < v.changes.changed.length; c++) html += '<li>' + v.changes.changed[c] + '</li>';
      html += '</ul></div>';
    }
    html += '</div>';
  }
  return html;
}

// IIFE — encapsula estado privado (so roda no browser)
if (typeof window !== "undefined") (function() {
  var _fs   = require("fs");
  var _path = require("path");

  // Dependencias injetadas via init()
  var _state     = null;
  var _saveState = null;
  var _showToast = null;

  // Estado interno
  var changelogData = null;

  var welcomeSlides = [
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
      title: 'Bem-vindo ao StockHub!',
      text: 'Centralize seus assets de stock — videos, imagens, audios e MOGRTs — em um unico painel dentro do Premiere Pro.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>',
      title: 'Configure sua pasta',
      text: 'Abra as configuracoes (icone de engrenagem) e escolha a pasta onde ficam seus stocks. Subpastas viram categorias automaticamente — sem precisar organizar nada manualmente.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>',
      title: 'Arraste para a timeline',
      text: 'Arraste qualquer asset direto para a timeline do Premiere. Duplo clique insere na posicao do playhead. Use o botao de import para adicionar ao projeto sem inserir na timeline.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#e8a634" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
      title: 'Favoritos e Tags',
      text: 'Clique com o botao direito em qualquer asset para adicionar aos favoritos ou criar tags. As tags aparecem na busca — digite o nome da tag para encontrar assets relacionados.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c586c0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>',
      title: 'Selecao multipla',
      text: 'Segure Ctrl e clique para selecionar varios assets. Use Shift+clique para selecionar um intervalo. Importe todos de uma vez com o botao "Importar" na barra de selecao.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#4ec9b0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
      title: 'Tudo pronto!',
      text: 'Voce esta pronto para usar o StockHub. Acesse as configuracoes a qualquer momento pelo icone de engrenagem. Use Ctrl+Shift+R para recarregar o painel.'
    }
  ];

  // -------------------------------------------------------------------------
  // Changelog
  // -------------------------------------------------------------------------

  function loadChangelog() {
    try {
      var file = _path.join(__dirname, "..", "CHANGELOG.json");
      if (_fs.existsSync(file)) {
        changelogData = JSON.parse(_fs.readFileSync(file, "utf-8"));
      }
    } catch (e) {
      console.error("Failed to load CHANGELOG.json:", e);
    }
  }

  function getChangelogData() {
    if (!changelogData) loadChangelog();
    return changelogData;
  }

  // -------------------------------------------------------------------------
  // Modais
  // -------------------------------------------------------------------------

  function closeModal(e) {
    if (e && e.target !== e.currentTarget) return;
    document.getElementById("modalContainer").innerHTML = "";
  }

  function showAboutModal() {
    var container = document.getElementById("modalContainer");
    container.innerHTML =
      '<div class="modal-overlay" onclick="closeModal(event)">' +
        '<div class="modal about-modal" onclick="event.stopPropagation()">' +
          '<div style="margin-bottom:16px;opacity:0.8;">' +
            '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
              '<rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>' +
            '</svg>' +
          '</div>' +
          '<h3 style="margin:0 0 6px;font-size:18px;">StockHub</h3>' +
          '<p style="color:var(--accent);font-size:12px;font-weight:600;margin:0 0 12px;">v' + window.APP_VERSION + '</p>' +
          '<p style="font-size:11px;margin:0 0 16px;color:var(--text-secondary);line-height:1.6;">Painel de assets para Adobe Premiere Pro.<br>Centraliza stocks em um unico lugar com preview, categorias e importacao direta.</p>' +
          '<p style="font-size:10px;color:var(--text-muted);margin:0 0 20px;">Desenvolvido por Luis Sousa</p>' +
          '<div style="display:flex;gap:8px;justify-content:center;">' +
            '<button class="btn" onclick="showChangelogModal()" style="flex:1;">Ver changelog</button>' +
            '<button class="btn btn-primary" onclick="closeModal()" style="flex:1;">Fechar</button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  function showChangelogModal() {
    var data = getChangelogData();
    var versions = data ? data.versions : [];
    var container = document.getElementById("modalContainer");
    container.innerHTML =
      '<div class="modal-overlay" onclick="closeModal(event)">' +
        '<div class="modal changelog-modal" onclick="event.stopPropagation()">' +
          '<div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;">' +
            '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/>' +
            '</svg>' +
            '<h3 style="margin:0;font-size:14px;">Changelog</h3>' +
          '</div>' +
          '<div class="changelog-list">' +
            _renderChangelogHTML(versions) +
          '</div>' +
          '<div class="modal-actions" style="margin-top:14px;">' +
            '<button class="btn btn-primary" onclick="closeModal()" style="width:100%;">Fechar</button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  function showWhatsNewModal() {
    // Lê notes do version.json local (gravado pelo update-manager após update)
    var notes = "";
    try {
      var vf = _path.join(__dirname, "..", "version.json");
      var vd = JSON.parse(_fs.readFileSync(vf, "utf-8"));
      notes = vd.notes || "";
    } catch (e) { /* sem version.json — segue sem notes */ }

    // Se tem notes → é feature, mostra o conteúdo. Se não → bugfix genérico.
    var contentHTML = notes
      ? '<p style="font-size:12px;color:var(--text-primary);line-height:1.7;margin:0 0 14px;white-space:pre-line;">' + notes + '</p>'
      : '<p style="font-size:12px;color:var(--text-secondary);line-height:1.7;margin:0 0 14px;">' +
          'Correção de bugs e melhorias de desempenho.' +
        '</p>';

    var container = document.getElementById("modalContainer");
    container.innerHTML =
      '<div class="modal-overlay" onclick="closeWhatsNewModal(event)">' +
        '<div class="modal update-modal" onclick="event.stopPropagation()">' +
          '<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">' +
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>' +
            '</svg>' +
            '<h3 style="margin:0;font-size:14px;">StockHub atualizado</h3>' +
          '</div>' +
          '<p style="color:var(--accent);font-size:12px;font-weight:600;margin:0 0 12px;">v' + window.APP_VERSION + '</p>' +
          contentHTML +
          '<div class="modal-actions">' +
            '<button class="btn btn-primary" onclick="closeWhatsNewModal()" style="width:100%;">Entendi</button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  function closeWhatsNewModal(e) {
    if (e && e.target !== e.currentTarget) return;
    _state.lastSeenVersion = window.APP_VERSION;
    _saveState();
    document.getElementById("modalContainer").innerHTML = "";
  }

  function showWelcomeModal(step) {
    if (step < 0) step = 0;
    if (step >= welcomeSlides.length) { closeWelcomeModal(); return; }
    var s = welcomeSlides[step];
    var dots = '';
    for (var d = 0; d < welcomeSlides.length; d++) {
      dots += '<span class="welcome-dot' + (d === step ? ' active' : '') + '"></span>';
    }
    var prevBtn = step > 0
      ? '<button class="btn" onclick="showWelcomeModal(' + (step - 1) + ')">Anterior</button>'
      : '';
    var nextBtn = step < welcomeSlides.length - 1
      ? '<button class="btn btn-primary" onclick="showWelcomeModal(' + (step + 1) + ')">Proximo</button>'
      : '<button class="btn btn-primary" onclick="closeWelcomeModal()">Comecar</button>';
    var container = document.getElementById("modalContainer");
    container.innerHTML =
      '<div class="modal-overlay">' +
        '<div class="modal welcome-modal" onclick="event.stopPropagation()" style="max-width:360px;text-align:center;">' +
          '<div class="welcome-slide">' +
            '<div style="margin-bottom:16px;">' + s.icon + '</div>' +
            '<h3 style="margin:0 0 8px;">' + s.title + '</h3>' +
            '<p style="font-size:11px;color:var(--text-secondary);margin:0 0 20px;line-height:1.5;">' + s.text + '</p>' +
          '</div>' +
          '<div class="welcome-dots">' + dots + '</div>' +
          '<div class="modal-actions" style="justify-content:center;gap:8px;margin-top:16px;">' +
            prevBtn + nextBtn +
          '</div>' +
        '</div>' +
      '</div>';
  }

  function closeWelcomeModal() {
    _state.welcomed = true;
    _saveState();
    document.getElementById("modalContainer").innerHTML = "";
  }

  function showUserIdModal() {
    var container = document.getElementById("modalContainer");
    var defaultName = (process.env.USERNAME || process.env.USER || "").replace(/[^a-zA-Z0-9_-]/g, "");
    container.innerHTML =
      '<div class="modal-overlay">' +
        '<div class="modal" onclick="event.stopPropagation()">' +
          '<h3>Bem-vindo ao StockHub</h3>' +
          '<p style="font-size:11px;color:var(--text-secondary);margin:0 0 12px;">Informe seu nome para rastrear o uso de assets pela equipe.</p>' +
          '<input type="text" id="userIdInput" placeholder="Seu nome (ex: joao, maria)" value="' + defaultName + '" onkeydown="if(event.key===\'Enter\')confirmUserId()">' +
          '<div class="modal-actions">' +
            '<button class="btn btn-primary" onclick="confirmUserId()">Confirmar</button>' +
          '</div>' +
        '</div>' +
      '</div>';
    setTimeout(function() {
      var inp = document.getElementById("userIdInput");
      if (inp) { inp.focus(); inp.select(); }
    }, 100);
  }

  function confirmUserId() {
    var input = document.getElementById("userIdInput");
    var name = input ? input.value.trim() : "";
    if (!name) { _showToast("Informe seu nome"); return; }
    _state.userId = name.toLowerCase().replace(/[^a-z0-9_-]/g, "-");
    _saveState();
    closeModal();
    _showToast("Usuario definido: " + _state.userId);
  }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.ModalManager = {
    init: function(stateRef, deps) {
      _state     = stateRef;
      _saveState = deps.saveState;
      _showToast = deps.showToast;
    },
    loadChangelog:      loadChangelog,
    getChangelogData:   getChangelogData,
    closeModal:         closeModal,
    showAboutModal:     showAboutModal,
    showChangelogModal: showChangelogModal,
    showWhatsNewModal:  showWhatsNewModal,
    closeWhatsNewModal: closeWhatsNewModal,
    showWelcomeModal:   showWelcomeModal,
    closeWelcomeModal:  closeWelcomeModal,
    showUserIdModal:    showUserIdModal,
    confirmUserId:      confirmUserId,
    renderChangelogHTML: _renderChangelogHTML
  };

  // Aliases globais para onclick no HTML
  window.closeModal         = closeModal;
  window.showAboutModal     = showAboutModal;
  window.showChangelogModal = showChangelogModal;
  window.showWhatsNewModal  = showWhatsNewModal;
  window.closeWhatsNewModal = closeWhatsNewModal;
  window.showWelcomeModal   = showWelcomeModal;
  window.closeWelcomeModal  = closeWelcomeModal;
  window.showUserIdModal    = showUserIdModal;
  window.confirmUserId      = confirmUserId;

})();

// Node.js exports para testes
if (typeof module !== "undefined") {
  module.exports = { _renderChangelogHTML: _renderChangelogHTML };
}
