// =============================================================================
// category-manager.js — Modulo de categorias do StockHub
//
// Responsabilidades:
//   - CRUD de categorias (criar, remover, renomear, trocar cor)
//   - Toggle de favoritos
//   - Context menus (arquivo e categoria)
//   - Lista de edicao de categorias no painel de settings
//   - Selecao em lote para remocao
//
// Dependencias externas (recebidas via init):
//   - state, saveState, showToast, toRelPath
//   - renderCategories, renderGrid, renderAll
//   - closeModal (do ModalManager)
// =============================================================================

// Funcao pura testavel (fora da IIFE)
function _generateCatId(name) {
  if (!name) return "";
  return name.toLowerCase().replace(/[^a-z0-9]/g, "-");
}

// IIFE — encapsula estado privado (so roda no browser)
if (typeof window !== "undefined") (function() {

  // Dependencias injetadas via init()
  var _state            = null;
  var _saveState        = null;
  var _showToast        = null;
  var _toRelPath        = null;
  var _renderCategories = null;
  var _renderGrid       = null;
  var _renderAll        = null;

  // Estado interno
  var selectedCategories = {};

  var CAT_COLORS = ["#f44747","#4ec9b0","#ce9178","#dcdcaa","#c586c0","#569cd6","#d7ba7d","#9cdcfe"];
  var CYCLE_COLORS = ["#f44747","#4ec9b0","#ce9178","#dcdcaa","#c586c0","#569cd6","#d7ba7d","#9cdcfe","#0078d4","#b5cea8"];

  // -------------------------------------------------------------------------
  // CRUD
  // -------------------------------------------------------------------------

  function getRandomColor() {
    return CAT_COLORS[Math.floor(Math.random() * CAT_COLORS.length)];
  }

  function showAddCategoryModal() {
    var container = document.getElementById("modalContainer");
    container.innerHTML =
      '<div class="modal-overlay" onclick="closeModal(event)">' +
        '<div class="modal" onclick="event.stopPropagation()">' +
          '<h3>Nova Categoria</h3>' +
          '<input type="text" id="newCatName" placeholder="Nome da categoria" autofocus onkeydown="if(event.key===\'Enter\')addCategory()">' +
          '<div class="modal-actions">' +
            '<button class="btn" onclick="closeModal()">Cancelar</button>' +
            '<button class="btn btn-primary" onclick="addCategory()">Criar</button>' +
          '</div>' +
        '</div>' +
      '</div>';
    setTimeout(function() { document.getElementById("newCatName").focus(); }, 100);
  }

  function addCategory() {
    var name = document.getElementById("newCatName").value.trim();
    if (!name) return;
    var id = _generateCatId(name);
    for (var i = 0; i < _state.categories.length; i++) {
      if (_state.categories[i].id === id) {
        _showToast("Categoria ja existe");
        return;
      }
    }
    _state.categories.push({ id: id, name: name, color: getRandomColor() });
    _state.deletedCategoryIds = _state.deletedCategoryIds.filter(function(d) { return d !== id; });
    _saveState();
    closeModal();
    _renderCategories();
    if (_state.showSettings) renderCatEditList();
    _showToast("Categoria criada: " + name);
  }

  function removeCategory(catId) {
    var existing = document.getElementById("catCtxMenu");
    if (existing) existing.remove();
    _state.categories = _state.categories.filter(function(c) {
      if (c.system) return true;
      if (c.id === catId) return false;
      if (c.parent === catId) return false;
      return true;
    });
    if (_state.activeCategory === catId || _state.activeCategory.indexOf(catId + "/") === 0) _state.activeCategory = "all";
    if (_state.deletedCategoryIds.indexOf(catId) === -1) _state.deletedCategoryIds.push(catId);
    _saveState();
    _renderCategories();
    _renderGrid();
    if (_state.showSettings) renderCatEditList();
  }

  function renameCategory(catId, newName) {
    for (var i = 0; i < _state.categories.length; i++) {
      if (_state.categories[i].id === catId && !_state.categories[i].system) {
        _state.categories[i].name = newName;
        _saveState();
        _renderCategories();
        break;
      }
    }
  }

  function cycleCatColor(catId) {
    for (var i = 0; i < _state.categories.length; i++) {
      if (_state.categories[i].id === catId) {
        var idx = CYCLE_COLORS.indexOf(_state.categories[i].color);
        _state.categories[i].color = CYCLE_COLORS[(idx + 1) % CYCLE_COLORS.length];
        _saveState();
        renderCatEditList();
        _renderCategories();
        break;
      }
    }
  }

  // -------------------------------------------------------------------------
  // Favoritos
  // -------------------------------------------------------------------------

  function toggleFileFavorite(filePath) {
    if (!_state.favoriteFiles) _state.favoriteFiles = {};
    var key = _toRelPath(filePath);
    if (_state.favoriteFiles[key]) {
      delete _state.favoriteFiles[key];
      _showToast("Removido dos favoritos");
    } else {
      _state.favoriteFiles[key] = true;
      _showToast("Adicionado aos favoritos");
    }
    _saveState();
    _renderCategories();
    _renderGrid();
  }

  // -------------------------------------------------------------------------
  // Context Menus
  // -------------------------------------------------------------------------

  function showContextMenu(e, fileIndex) {
    e.preventDefault();
    var file = _state.files[fileIndex];
    if (!file) return;
    var existing = document.getElementById("contextMenu");
    if (existing) existing.remove();

    var menu = document.createElement("div");
    menu.id = "contextMenu";
    menu.style.cssText =
      "position:fixed;left:" + e.clientX + "px;top:" + e.clientY + "px;" +
      "background:var(--bg-secondary);border:1px solid var(--border);" +
      "border-radius:var(--radius);padding:4px 0;min-width:160px;" +
      "z-index:999;box-shadow:0 4px 12px #00000066;";

    var isFav = _state.favoriteFiles && _state.favoriteFiles[_toRelPath(file.path)];
    var favItem = document.createElement("div");
    favItem.style.cssText = "padding:5px 12px;font-size:11px;cursor:pointer;color:" + (isFav ? "#e8a634" : "var(--text-primary)") + ";display:flex;align-items:center;gap:8px;";
    favItem.innerHTML =
      '<svg width="12" height="12" viewBox="0 0 24 24" fill="' + (isFav ? "#e8a634" : "none") + '" stroke="#e8a634" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
        '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>' +
      '</svg>' +
      (isFav ? "Remover dos favoritos" : "Adicionar aos favoritos");
    favItem.onmouseover = function() { favItem.style.background = "var(--bg-hover)"; };
    favItem.onmouseout = function() { favItem.style.background = "transparent"; };
    favItem.onclick = function() {
      toggleFileFavorite(file.path);
      menu.remove();
    };
    menu.appendChild(favItem);

    // Tag item
    var tagItem = document.createElement("div");
    tagItem.style.cssText = "padding:5px 12px;font-size:11px;cursor:pointer;color:var(--text-primary);display:flex;align-items:center;gap:8px;";
    tagItem.innerHTML =
      '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
        '<path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/>' +
      '</svg>' +
      'Editar tags';
    tagItem.onmouseover = function() { tagItem.style.background = "var(--bg-hover)"; };
    tagItem.onmouseout = function() { tagItem.style.background = "transparent"; };
    tagItem.onclick = function() {
      menu.remove();
      showTagModal(fileIndex);
    };
    menu.appendChild(tagItem);

    var divider = document.createElement("div");
    divider.style.cssText = "height:1px;background:var(--border);margin:4px 8px;";
    menu.appendChild(divider);

    var header = document.createElement("div");
    header.style.cssText = "padding:6px 12px;font-size:10px;color:var(--text-muted);font-weight:600;text-transform:uppercase;letter-spacing:0.3px;flex-shrink:0;";
    header.textContent = "Mover para categoria";
    menu.appendChild(header);

    var catList = document.createElement("div");
    catList.style.cssText = "overflow-y:auto;flex:1;min-height:0;";

    _state.categories.forEach(function(cat) {
      var isSub = !!cat.parent;
      var item = document.createElement("div");
      item.style.cssText =
        "padding:5px " + (isSub ? "12px 5px 24px" : "12px") + ";font-size:" + (isSub ? "10" : "11") + "px;cursor:pointer;" +
        "color:" + (file.category === cat.id ? "var(--accent)" : "var(--text-primary)") + ";" +
        (isSub ? "opacity:0.8;" : "") +
        "display:flex;align-items:center;gap:6px;";
      item.innerHTML = (isSub ? '&nbsp;&nbsp;' : '') + cat.name;
      item.onmouseover = function() { item.style.background = "var(--bg-hover)"; };
      item.onmouseout = function() { item.style.background = "transparent"; };
      item.onclick = function() {
        file.category = cat.id;
        if (!_state.fileCategories) _state.fileCategories = {};
        _state.fileCategories[_toRelPath(file.path)] = cat.id;
        _saveState();
        _renderGrid();
        menu.remove();
        _showToast("Movido para: " + cat.name);
      };
      catList.appendChild(item);
    });
    menu.appendChild(catList);

    document.body.appendChild(menu);

    var sliderBar = document.getElementById("gridSliderBar");
    var bottomLimit = sliderBar ? sliderBar.getBoundingClientRect().top : window.innerHeight;
    var maxHeight = bottomLimit - e.clientY - 8;
    if (maxHeight < 150) {
      var topSpace = e.clientY - 8;
      menu.style.top = "";
      menu.style.bottom = (window.innerHeight - e.clientY) + "px";
      maxHeight = topSpace;
    }
    menu.style.maxHeight = Math.min(maxHeight, 400) + "px";
    menu.style.display = "flex";
    menu.style.flexDirection = "column";

    var rect = menu.getBoundingClientRect();
    if (rect.right > window.innerWidth) menu.style.left = (window.innerWidth - rect.width - 4) + "px";

    var closeCtx = function() { menu.remove(); document.removeEventListener("click", closeCtx); };
    setTimeout(function() { document.addEventListener("click", closeCtx); }, 10);
  }

  function showCatContextMenu(e, catId) {
    e.preventDefault();
    e.stopPropagation();
    var existing = document.getElementById("catCtxMenu");
    if (existing) existing.remove();

    var cat = null;
    for (var i = 0; i < _state.categories.length; i++) {
      if (_state.categories[i].id === catId) { cat = _state.categories[i]; break; }
    }
    if (!cat || cat.system) return;

    var menu = document.createElement("div");
    menu.id = "catCtxMenu";
    menu.className = "cat-ctx-menu";
    menu.style.left = e.clientX + "px";
    menu.style.top = e.clientY + "px";

    menu.innerHTML =
      '<div class="cat-ctx-item" onclick="showRenameCategoryModal(\'' + catId + '\')">' +
        '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
          '<path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>' +
          '<path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>' +
        '</svg>' +
        'Renomear' +
      '</div>' +
      '<div class="cat-ctx-item danger" onclick="removeCategory(\'' + catId + '\')">' +
        '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
          '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>' +
        '</svg>' +
        'Excluir' +
      '</div>';

    document.body.appendChild(menu);

    var rect = menu.getBoundingClientRect();
    if (rect.right > window.innerWidth) menu.style.left = (window.innerWidth - rect.width - 4) + "px";
    if (rect.bottom > window.innerHeight) menu.style.top = (window.innerHeight - rect.height - 4) + "px";

    var closeFn = function() {
      menu.remove();
      document.removeEventListener("click", closeFn);
    };
    setTimeout(function() { document.addEventListener("click", closeFn); }, 10);
  }

  function showRenameCategoryModal(catId) {
    var existing = document.getElementById("catCtxMenu");
    if (existing) existing.remove();
    var cat = null;
    for (var i = 0; i < _state.categories.length; i++) {
      if (_state.categories[i].id === catId) { cat = _state.categories[i]; break; }
    }
    if (!cat) return;
    var container = document.getElementById("modalContainer");
    container.innerHTML =
      '<div class="modal-overlay" onclick="closeModal(event)">' +
        '<div class="modal" onclick="event.stopPropagation()">' +
          '<h3>Renomear Categoria</h3>' +
          '<input type="text" id="renameCatInput" value="' + cat.name.replace(/"/g, '&quot;') + '" autofocus onkeydown="if(event.key===\'Enter\'){renameCategory(\'' + catId + '\',this.value);closeModal()}">' +
          '<div class="modal-actions">' +
            '<button class="btn" onclick="closeModal()">Cancelar</button>' +
            '<button class="btn btn-primary" onclick="renameCategory(\'' + catId + '\',document.getElementById(\'renameCatInput\').value);closeModal()">Salvar</button>' +
          '</div>' +
        '</div>' +
      '</div>';
    setTimeout(function() { var inp = document.getElementById("renameCatInput"); inp.focus(); inp.select(); }, 100);
  }

  // -------------------------------------------------------------------------
  // Settings: category edit list
  // -------------------------------------------------------------------------

  function renderCatEditList() {
    var list = document.getElementById("catEditList");
    var nonSystem = _state.categories.filter(function(c) { return !c.system; });
    var parents = nonSystem.filter(function(c) { return !c.parent; });
    var html = "";
    for (var p = 0; p < parents.length; p++) {
      var cat = parents[p];
      var checked = selectedCategories[cat.id] ? "checked" : "";
      html += '<div class="cat-edit-row">' +
        '<input type="checkbox" class="cat-checkbox" data-catid="' + cat.id + '" ' + checked + ' onchange="toggleCatSelection(\'' + cat.id + '\', this.checked)">' +
        '<input value="' + cat.name + '" onblur="renameCategory(\'' + cat.id + '\', this.value)" onkeydown="if(event.key===\'Enter\')this.blur()">' +
      '</div>';
      var children = nonSystem.filter(function(c) { return c.parent === cat.id; });
      for (var c = 0; c < children.length; c++) {
        var sub = children[c];
        var subChecked = selectedCategories[sub.id] ? "checked" : "";
        html += '<div class="cat-edit-row" style="padding-left:20px;opacity:0.8;">' +
          '<input type="checkbox" class="cat-checkbox" data-catid="' + sub.id + '" ' + subChecked + ' onchange="toggleCatSelection(\'' + sub.id + '\', this.checked)">' +
          '<input value="' + sub.name + '" onblur="renameCategory(\'' + sub.id + '\', this.value)" onkeydown="if(event.key===\'Enter\')this.blur()" style="font-size:10px;">' +
        '</div>';
      }
    }
    list.innerHTML = html;
    updateSelectAllBtn();
  }

  function toggleCatSelection(catId, checked) {
    if (checked) {
      selectedCategories[catId] = true;
    } else {
      delete selectedCategories[catId];
    }
    updateSelectAllBtn();
  }

  function toggleSelectAllCategories() {
    var nonSystem = _state.categories.filter(function(c) { return !c.system; });
    var allSelected = nonSystem.length > 0 && nonSystem.every(function(c) { return selectedCategories[c.id]; });
    if (allSelected) {
      selectedCategories = {};
    } else {
      selectedCategories = {};
      nonSystem.forEach(function(c) { selectedCategories[c.id] = true; });
    }
    renderCatEditList();
  }

  function updateSelectAllBtn() {
    var btn = document.getElementById("selectAllCatsBtn");
    if (!btn) return;
    var nonSystem = _state.categories.filter(function(c) { return !c.system; });
    var allSelected = nonSystem.length > 0 && nonSystem.every(function(c) { return selectedCategories[c.id]; });
    btn.querySelector("svg").style.opacity = allSelected ? "1" : "0.5";
  }

  function removeSelectedCategories() {
    var ids = Object.keys(selectedCategories);
    if (ids.length === 0) {
      _showToast("Nenhuma categoria selecionada");
      return;
    }
    ids.forEach(function(id) {
      if (_state.deletedCategoryIds.indexOf(id) === -1) _state.deletedCategoryIds.push(id);
    });
    _state.categories = _state.categories.filter(function(c) {
      return c.system || !selectedCategories[c.id];
    });
    if (selectedCategories[_state.activeCategory]) {
      _state.activeCategory = "all";
    }
    selectedCategories = {};
    _saveState();
    _renderCategories();
    _renderGrid();
    renderCatEditList();
    _showToast(ids.length + " categoria(s) removida(s)");
  }

  // -------------------------------------------------------------------------
  // Tagging
  // -------------------------------------------------------------------------

  function showTagModal(fileIndex) {
    var file = _state.files[fileIndex];
    if (!file) return;
    var relPath = _toRelPath(file.path);
    var tags = (_state.fileTags && _state.fileTags[relPath]) || [];

    var container = document.getElementById("modalContainer");
    container.innerHTML =
      '<div class="modal-overlay" onclick="closeModal(event)">' +
        '<div class="modal" onclick="event.stopPropagation()" style="max-width:340px;">' +
          '<h3>Tags: ' + file.name + '</h3>' +
          '<div id="tagList" style="display:flex;flex-wrap:wrap;gap:4px;margin:8px 0;min-height:24px;"></div>' +
          '<div style="display:flex;gap:6px;">' +
            '<input type="text" id="tagInput" placeholder="Nova tag..." style="flex:1;" onkeydown="if(event.key===\'Enter\'){addFileTag(' + fileIndex + ',this.value);this.value=\'\';}">' +
            '<button class="btn btn-primary" onclick="addFileTag(' + fileIndex + ',document.getElementById(\'tagInput\').value);document.getElementById(\'tagInput\').value=\'\';">Adicionar</button>' +
          '</div>' +
          '<div class="modal-actions" style="margin-top:12px;">' +
            '<button class="btn btn-primary" onclick="closeModal()" style="width:100%;">Fechar</button>' +
          '</div>' +
        '</div>' +
      '</div>';
    renderTagList(fileIndex);
    setTimeout(function() { document.getElementById("tagInput").focus(); }, 100);
  }

  function renderTagList(fileIndex) {
    var file = _state.files[fileIndex];
    if (!file) return;
    var relPath = _toRelPath(file.path);
    var tags = (_state.fileTags && _state.fileTags[relPath]) || [];
    var list = document.getElementById("tagList");
    if (!list) return;
    if (tags.length === 0) {
      list.innerHTML = '<span style="font-size:10px;color:var(--text-muted);">Nenhuma tag</span>';
      return;
    }
    list.innerHTML = tags.map(function(tag) {
      return '<span style="display:inline-flex;align-items:center;gap:3px;padding:2px 8px;background:var(--bg-hover);border-radius:10px;font-size:10px;color:var(--text-primary);">' +
        tag +
        '<span style="cursor:pointer;opacity:0.6;font-size:12px;" onclick="removeFileTag(' + fileIndex + ',\'' + tag.replace(/'/g, "\\'") + '\')">&times;</span>' +
      '</span>';
    }).join("");
  }

  function addFileTag(fileIndex, tag) {
    tag = (tag || "").trim().toLowerCase();
    if (!tag) return;
    var file = _state.files[fileIndex];
    if (!file) return;
    var relPath = _toRelPath(file.path);
    if (!_state.fileTags) _state.fileTags = {};
    if (!_state.fileTags[relPath]) _state.fileTags[relPath] = [];
    if (_state.fileTags[relPath].indexOf(tag) >= 0) {
      _showToast("Tag ja existe: " + tag);
      return;
    }
    _state.fileTags[relPath].push(tag);
    _saveState();
    renderTagList(fileIndex);
    _renderGrid();
  }

  function removeFileTag(fileIndex, tag) {
    var file = _state.files[fileIndex];
    if (!file) return;
    var relPath = _toRelPath(file.path);
    if (!_state.fileTags || !_state.fileTags[relPath]) return;
    _state.fileTags[relPath] = _state.fileTags[relPath].filter(function(t) { return t !== tag; });
    if (_state.fileTags[relPath].length === 0) delete _state.fileTags[relPath];
    _saveState();
    renderTagList(fileIndex);
    _renderGrid();
  }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.CategoryManager = {
    init: function(stateRef, deps) {
      _state            = stateRef;
      _saveState        = deps.saveState;
      _showToast        = deps.showToast;
      _toRelPath        = deps.toRelPath;
      _renderCategories = deps.renderCategories;
      _renderGrid       = deps.renderGrid;
      _renderAll        = deps.renderAll;
    },
    getRandomColor:           getRandomColor,
    addCategory:              addCategory,
    removeCategory:           removeCategory,
    renameCategory:           renameCategory,
    cycleCatColor:            cycleCatColor,
    toggleFileFavorite:       toggleFileFavorite,
    showContextMenu:          showContextMenu,
    showCatContextMenu:       showCatContextMenu,
    showRenameCategoryModal:  showRenameCategoryModal,
    showAddCategoryModal:     showAddCategoryModal,
    renderCatEditList:        renderCatEditList,
    toggleCatSelection:       toggleCatSelection,
    toggleSelectAllCategories: toggleSelectAllCategories,
    removeSelectedCategories: removeSelectedCategories,
    showTagModal:             showTagModal,
    addFileTag:               addFileTag,
    removeFileTag:            removeFileTag
  };

  // Aliases globais para onclick no HTML
  window.getRandomColor           = getRandomColor;
  window.addCategory              = addCategory;
  window.removeCategory           = removeCategory;
  window.renameCategory           = renameCategory;
  window.cycleCatColor            = cycleCatColor;
  window.toggleFileFavorite       = toggleFileFavorite;
  window.showContextMenu          = showContextMenu;
  window.showCatContextMenu       = showCatContextMenu;
  window.showRenameCategoryModal  = showRenameCategoryModal;
  window.showAddCategoryModal     = showAddCategoryModal;
  window.renderCatEditList        = renderCatEditList;
  window.toggleCatSelection       = toggleCatSelection;
  window.toggleSelectAllCategories = toggleSelectAllCategories;
  window.removeSelectedCategories = removeSelectedCategories;
  window.showTagModal             = showTagModal;
  window.addFileTag               = addFileTag;
  window.removeFileTag            = removeFileTag;

})();

// Node.js exports para testes
if (typeof module !== "undefined") {
  module.exports = { _generateCatId: _generateCatId };
}
