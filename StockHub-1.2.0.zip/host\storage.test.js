// storage.test.js — Testes para core/storage.js (funcoes puras)
// Roda em Node.js puro, sem dependencias de browser

var assert = require("assert");
var mod = require("../client/core/storage.js");
var _toFileURL = mod._toFileURL;
var _migrateAbsoluteKeysToRelative = mod._migrateAbsoluteKeysToRelative;

var passed = 0;
var failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log("  PASS: " + name);
  } catch (e) {
    failed++;
    console.error("  FAIL: " + name + " — " + e.message);
  }
}

console.log("\n=== storage tests ===\n");

// --- _toFileURL ---

test("toFileURL: path Windows com drive letter", function() {
  var result = _toFileURL("C:\\Users\\test\\file.mp4");
  assert.strictEqual(result, "file:///C:/Users/test/file.mp4");
});

test("toFileURL: path Unix absoluto", function() {
  var result = _toFileURL("/Users/test/file.mp4");
  assert.strictEqual(result, "file:///Users/test/file.mp4");
});

test("toFileURL: path ja com forward slashes", function() {
  var result = _toFileURL("C:/Users/test/file.mp4");
  assert.strictEqual(result, "file:///C:/Users/test/file.mp4");
});

test("toFileURL: string vazia retorna string vazia", function() {
  var result = _toFileURL("");
  assert.strictEqual(result, "");
});

test("toFileURL: null retorna null", function() {
  var result = _toFileURL(null);
  assert.strictEqual(result, null);
});

test("toFileURL: undefined retorna undefined", function() {
  var result = _toFileURL(undefined);
  assert.strictEqual(result, undefined);
});

test("toFileURL: path com espacos", function() {
  var result = _toFileURL("C:\\Users\\Luis Sousa\\file.mp4");
  assert.strictEqual(result, "file:///C:/Users/Luis Sousa/file.mp4");
});

// --- _migrateAbsoluteKeysToRelative ---

test("migrate: converte chaves absolutas para relativas", function() {
  var p = require("path");
  var stockFolder = p.join("C:", "Users", "test", "StockHub");
  var absKey = p.join(stockFolder, "Videos", "clip.mp4");
  var dict = {};
  dict[absKey] = "overlays";
  var result = _migrateAbsoluteKeysToRelative(dict, stockFolder);
  assert.strictEqual(result["Videos/clip.mp4"], "overlays");
});

test("migrate: preserva chaves ja relativas", function() {
  var dict = { "Videos/clip.mp4": "sfx" };
  var result = _migrateAbsoluteKeysToRelative(dict, "/any/folder");
  assert.strictEqual(result["Videos/clip.mp4"], "sfx");
});

test("migrate: descarta chaves acima da pasta de stock", function() {
  var p = require("path");
  var stockFolder = p.join("C:", "Users", "test", "StockHub");
  var outsideKey = p.join("C:", "Users", "file.mp4");
  var dict = {};
  dict[outsideKey] = "cat";
  var result = _migrateAbsoluteKeysToRelative(dict, stockFolder);
  assert.strictEqual(Object.keys(result).length, 0);
});

test("migrate: null retorna null", function() {
  assert.strictEqual(_migrateAbsoluteKeysToRelative(null, "/any"), null);
});

test("migrate: objeto vazio retorna objeto vazio", function() {
  var result = _migrateAbsoluteKeysToRelative({}, "/any");
  assert.strictEqual(Object.keys(result).length, 0);
});

test("migrate: multiplas chaves mistas", function() {
  var path = require("path");
  var stockFolder = path.join("C:", "Users", "test", "Stock");
  var absKey = path.join(stockFolder, "a.mp4");
  var dict = {};
  dict[absKey] = "cat1";
  dict["relative/b.mp4"] = "cat2";
  var result = _migrateAbsoluteKeysToRelative(dict, stockFolder);
  assert.strictEqual(result["a.mp4"], "cat1");
  assert.strictEqual(result["relative/b.mp4"], "cat2");
});

// --- Resumo ---

console.log("\nTotal: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
if (failed > 0) process.exit(1);
