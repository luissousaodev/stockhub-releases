// =============================================================================
// drag-manager.js — Modulo de drag & drop do StockHub
//
// Responsabilidades:
//   - Drag de arquivos para timeline do Premiere (CEP dnd)
//   - Drop em categorias para reclassificar
//   - Drop em favoritos
//   - Double-click para inserir na timeline
//   - Import para projeto
//   - Gerenciamento de estado de drag (pausar thumbs, matar processos)
//
// Dependencias externas (recebidas via init):
//   - state, saveState, showToast, toRelPath, toFileURL
//   - stageFileIfNeeded, getStagedPathIfExists
//   - cs (CSInterface), trackEvent, pumpThumbPool
//   - renderAll
//   - FFmpegManager, PreviewManager
// =============================================================================

// IIFE — encapsula estado privado (so roda no browser)
if (typeof window !== "undefined") (function() {

  // Dependencias injetadas via init()
  var _state              = null;
  var _saveState          = null;
  var _showToast          = null;
  var _toRelPath          = null;
  var _toFileURL          = null;
  var _stageFileIfNeeded  = null;
  var _getStagedPathIfExists = null;
  var _cs                 = null;
  var _trackEvent         = null;
  var _pumpThumbPool      = null;
  var _renderAll          = null;

  // Estado de drag (compartilhado com app.js via window)
  // isDragging e thumbQueuePaused permanecem como globais no app.js

  // -------------------------------------------------------------------------
  // Import
  // -------------------------------------------------------------------------

  function importToProject(fileIndex) {
    var file = _state.files[fileIndex];
    if (!file) return;
    var importPath = _stageFileIfNeeded(file);
    var escapedPath = importPath.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
    _cs.evalScript("importFileToProject('" + escapedPath + "')", function(result) {
      try {
        var res = JSON.parse(result);
        if (res.success && !res.alreadyExists) _trackEvent(file, "import");
        _showToast(res.success ? (res.alreadyExists ? "Ja no projeto: " + file.name : "Importado: " + file.name) : (res.error || "Erro ao importar"));
      } catch (e) {
        _showToast("Erro ao importar");
      }
    });
  }

  // -------------------------------------------------------------------------
  // Drag handlers
  // -------------------------------------------------------------------------

  function onFileDragStart(e, fileIndex) {
    var file = _state.files[fileIndex];
    window.isDragging = true;
    window.thumbQueuePaused = true;
    FFmpegManager.killActiveProxyProc();
    FFmpegManager.killActiveThumbChildren();
    PreviewManager.cleanupPreview();

    e.dataTransfer.setData("text/plain", String(fileIndex));
    e.dataTransfer.effectAllowed = "copyMove";

    if (file && file.path) {
      var dragPath = _getStagedPathIfExists(file) || file.path;
      try { e.dataTransfer.setData("com.adobe.cep.dnd.file.0", dragPath); } catch (err) {}
      try {
        var uri = _toFileURL(dragPath).replace(/ /g, "%20");
        e.dataTransfer.setData("text/uri-list", uri);
      } catch (err2) {}
    }

    var item = e.target.closest && e.target.closest(".grid-item");
    if (item) item.classList.add("dragging");

    try {
      if (e.dataTransfer.setDragImage) {
        if (!window.__emptyDragImage) {
          var img = new Image();
          img.src =
            "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
          window.__emptyDragImage = img;
        }
        e.dataTransfer.setDragImage(window.__emptyDragImage, 0, 0);
      }
    } catch (errImg) {}
  }

  function onFileDragEnd(e, fileIndex) {
    var el = e.target.closest(".grid-item");
    if (el) el.classList.remove("dragging");
    var cats = document.querySelectorAll(".cat-item");
    for (var i = 0; i < cats.length; i++) cats[i].classList.remove("drag-over");

    var file = _state.files[fileIndex];
    if (file && file.path) {
      var dragPath = _getStagedPathIfExists(file) || file.path;
      var escaped = dragPath.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
      setTimeout(function() {
        _cs.evalScript("moveFileToStockHubBin('" + escaped + "')");
      }, 500);
    }

    window.isDragging = false;
    setTimeout(function() {
      window.thumbQueuePaused = false;
      _pumpThumbPool();
    }, 800);
  }

  function onCatDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    e.currentTarget.classList.add("drag-over");
  }

  function onCatDragLeave(e) {
    e.currentTarget.classList.remove("drag-over");
  }

  function onCatDrop(e, catId) {
    e.preventDefault();
    e.currentTarget.classList.remove("drag-over");
    var fileIndex = parseInt(e.dataTransfer.getData("text/plain"));
    var file = _state.files[fileIndex];
    if (!file) return;
    file.category = catId;
    if (!_state.fileCategories) _state.fileCategories = {};
    _state.fileCategories[_toRelPath(file.path)] = catId;
    _saveState();
    _renderAll();
    var catName = "";
    for (var i = 0; i < _state.categories.length; i++) {
      if (_state.categories[i].id === catId) { catName = _state.categories[i].name; break; }
    }
    _showToast("Movido para: " + catName);
  }

  function onFavoritesDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove("drag-over");
    var fileIndex = parseInt(e.dataTransfer.getData("text/plain"));
    var file = _state.files[fileIndex];
    if (!file) return;
    if (!_state.favoriteFiles) _state.favoriteFiles = {};
    _state.favoriteFiles[_toRelPath(file.path)] = true;
    _saveState();
    _renderAll();
    _showToast("Adicionado aos favoritos: " + file.name);
  }

  function onDoubleClick(fileIndex) {
    var file = _state.files[fileIndex];
    if (!file) return;
    var importPath = _stageFileIfNeeded(file);
    var escapedPath = importPath.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
    _cs.evalScript("importFileToTimeline('" + escapedPath + "')", function(result) {
      try {
        var res = JSON.parse(result);
        if (res.success) _trackEvent(file, "timeline");
        _showToast(res.success ? "Inserido na timeline: " + file.name : (res.error || "Erro ao inserir"));
      } catch (e) {
        _showToast("Erro ao inserir na timeline");
      }
    });
  }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.DragManager = {
    init: function(stateRef, deps) {
      _state              = stateRef;
      _saveState          = deps.saveState;
      _showToast          = deps.showToast;
      _toRelPath          = deps.toRelPath;
      _toFileURL          = deps.toFileURL;
      _stageFileIfNeeded  = deps.stageFileIfNeeded;
      _getStagedPathIfExists = deps.getStagedPathIfExists;
      _cs                 = deps.cs;
      _trackEvent         = deps.trackEvent;
      _pumpThumbPool      = deps.pumpThumbPool;
      _renderAll          = deps.renderAll;
    },
    importToProject: importToProject,
    onFileDragStart: onFileDragStart,
    onFileDragEnd:   onFileDragEnd,
    onCatDragOver:   onCatDragOver,
    onCatDragLeave:  onCatDragLeave,
    onCatDrop:       onCatDrop,
    onFavoritesDrop: onFavoritesDrop,
    onDoubleClick:   onDoubleClick
  };

  // Aliases globais para inline event attrs
  window.importToProject = importToProject;
  window.onFileDragStart = onFileDragStart;
  window.onFileDragEnd   = onFileDragEnd;
  window.onCatDragOver   = onCatDragOver;
  window.onCatDragLeave  = onCatDragLeave;
  window.onCatDrop       = onCatDrop;
  window.onFavoritesDrop = onFavoritesDrop;
  window.onDoubleClick   = onDoubleClick;

})();
