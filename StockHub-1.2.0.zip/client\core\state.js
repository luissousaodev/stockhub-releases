// =============================================================================
// core/state.js — Estado global e persistencia do StockHub
// =============================================================================

var state = {
  files: [],
  categories: DEFAULT_CATEGORIES.slice(),
  activeCategory: "all",
  activeFormat: "all",
  searchQuery: "",
  gridSize: 110,
  showSettings: false,
  fileCategories: {},
  customFolder: null,
  autoCategories: true,
  deletedCategoryIds: [],
  favoriteFiles: {},
  userId: null,
  stagingFolder: null,
  lastSeenVersion: null,
  lastUpdateDismissedAt: null,
  updateDismissedVersion: null,
  welcomed: false,
  selectedFiles: {},
  fileTags: {},
};

function loadState() {
  try {
    var filePath = getStoragePath();
    if (fs.existsSync(filePath)) {
      var data = JSON.parse(fs.readFileSync(filePath, "utf-8"));
      if (data.categories) state.categories = data.categories;
      if (data.gridSize) state.gridSize = data.gridSize;
      if (data.fileCategories) state.fileCategories = data.fileCategories;
      if (data.customFolder) {
        if (fs.existsSync(data.customFolder)) {
          state.customFolder = data.customFolder;
        } else {
          Logger.warn("state", "Pasta personalizada nao encontrada, revertendo para padrao: " + data.customFolder);
          state.customFolder = null;
        }
      }
      if (data.autoCategories !== undefined) state.autoCategories = data.autoCategories;
      if (data.deletedCategoryIds) state.deletedCategoryIds = data.deletedCategoryIds;
      if (data.userId) state.userId = data.userId;
      if (data.sidebarWidth) state.sidebarWidth = data.sidebarWidth;
      if (data.favoriteFiles) state.favoriteFiles = data.favoriteFiles;
      if (data.stagingFolder) state.stagingFolder = data.stagingFolder;
      if (data.lastSeenVersion) state.lastSeenVersion = data.lastSeenVersion;
      if (data.lastUpdateDismissedAt) state.lastUpdateDismissedAt = data.lastUpdateDismissedAt;
      if (data.updateDismissedVersion) state.updateDismissedVersion = data.updateDismissedVersion;
      if (data.welcomed) state.welcomed = data.welcomed;
      if (data.fileTags) state.fileTags = data.fileTags;
      state.dataSchemaVersion = data.dataSchemaVersion || 1;

      // Migracao one-shot: chaves absolutas -> chaves relativas a pasta de stock.
      if (state.dataSchemaVersion < 2) {
        var stockFolder = getStockFolder();
        state.fileCategories = migrateAbsoluteKeysToRelative(state.fileCategories, stockFolder);
        state.favoriteFiles = migrateAbsoluteKeysToRelative(state.favoriteFiles, stockFolder);
        state.dataSchemaVersion = 2;
        try { saveState(); } catch (e) { Logger.warn("state", "Falha ao salvar migracao", e.message); }
        Logger.info("state", "Migrado stockhub-data.json para schema v2 (paths relativos)");
      }
    }
  } catch (e) {
    Logger.warn("state", "Falha ao carregar state", e.message);
  }
}

function saveState() {
  try {
    var filePath = getStoragePath();
    var dataDir = path.dirname(filePath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(filePath, JSON.stringify({
      dataSchemaVersion: 2,
      categories: state.categories,
      gridSize: state.gridSize,
      fileCategories: state.fileCategories,
      customFolder: state.customFolder,
      autoCategories: state.autoCategories,
      deletedCategoryIds: state.deletedCategoryIds,
      favoriteFiles: state.favoriteFiles,
      userId: state.userId,
      sidebarWidth: state.sidebarWidth,
      stagingFolder: state.stagingFolder,
      lastSeenVersion: state.lastSeenVersion,
      lastUpdateDismissedAt: state.lastUpdateDismissedAt,
      updateDismissedVersion: state.updateDismissedVersion,
      welcomed: state.welcomed,
      fileTags: state.fileTags,
    }), "utf-8");
  } catch (e) {
    Logger.error("state", "Falha ao salvar state", e.message);
  }
}
