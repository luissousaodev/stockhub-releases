// =============================================================================
// ui/settings.js — Acoes de UI: filtros, settings panel, grid size
// =============================================================================

function setFormat(format, btn) {
  if (state.showSettings) toggleSettings();
  if (metricsState.visible) toggleMetrics();
  state.selectedFiles = {};
  state.activeFormat = format;
  var tabs = document.querySelectorAll("#formatTabs .tab");
  for (var i = 0; i < tabs.length; i++) tabs[i].classList.remove("active");
  btn.classList.add("active");
  renderGrid();
}

function setCategory(catId) {
  state.selectedFiles = {};
  state.activeCategory = catId;
  var cat = null;
  for (var i = 0; i < state.categories.length; i++) {
    if (state.categories[i].id === catId) { cat = state.categories[i]; break; }
  }
  if (cat && !cat.parent && !cat.system) {
    state.expandedCategories[catId] = true;
  } else if (cat && cat.parent) {
    state.expandedCategories[cat.parent] = true;
  }
  renderCategories();
  renderGrid();
}

var searchTimer = null;
function filterFiles() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(function() {
    state.selectedFiles = {};
    state.searchQuery = document.getElementById("searchInput").value;
    renderGrid();
  }, 200);
}

function toggleSettings() {
  state.showSettings = !state.showSettings;
  var settingsPanel = document.getElementById("settingsPanel");
  var sidebar = document.getElementById("sidebar");
  var gridContainer = document.getElementById("gridContainer");
  var settingsBtn = document.getElementById("settingsBtn");
  var gridSlider = document.getElementById("gridSliderBar");

  if (state.showSettings) {
    if (metricsState.visible) toggleMetrics();
    settingsPanel.style.display = "flex";
    sidebar.style.display = "none";
    gridContainer.style.display = "none";
    if (gridSlider) gridSlider.style.display = "none";
    settingsBtn.style.color = "var(--accent)";
    var fp = document.getElementById("stockFolderPath");
    if (fp) fp.textContent = getStockFolder();
    var sfp = document.getElementById("stagingFolderPath");
    if (sfp) sfp.textContent = getStagingFolder();
    var ss = document.getElementById("stagingSize");
    if (ss) ss.textContent = getStagingSize();

    // Atualiza toggle, cache size, ffmpeg status, versao
    var toggle = document.getElementById("previewHoverToggle");
    if (toggle) toggle.checked = state.previewHoverEnabled !== false;

    var cacheEl = document.getElementById("cacheSizeDisplay");
    if (cacheEl) cacheEl.textContent = getCacheSize();

    var verEl = document.getElementById("settingsVersion");
    if (verEl) verEl.textContent = APP_VERSION;
  } else {
    settingsPanel.style.display = "none";
    sidebar.style.display = "flex";
    gridContainer.style.display = "block";
    if (gridSlider) gridSlider.style.display = "flex";
    settingsBtn.style.color = "";
  }
}

// Tamanho total do .cache (thumbs + proxies)
function getCacheSize() {
  if (typeof FFmpegManager === "undefined" || !FFmpegManager.getCacheDir) return "—";
  var dir = FFmpegManager.getCacheDir();
  if (!fs.existsSync(dir)) return "0 KB";
  var total = 0;
  try {
    var items = fs.readdirSync(dir);
    for (var i = 0; i < items.length; i++) {
      try {
        var st = fs.statSync(path.join(dir, items[i]));
        if (st.isFile()) total += st.size;
      } catch (e) { /* arquivo inacessivel */ }
    }
  } catch (e) { return "—"; }
  if (total < 1024 * 1024) return (total / 1024).toFixed(1) + " KB";
  if (total < 1024 * 1024 * 1024) return (total / (1024 * 1024)).toFixed(1) + " MB";
  return (total / (1024 * 1024 * 1024)).toFixed(1) + " GB";
}

function _doClearCache() {
  if (typeof FFmpegManager === "undefined" || !FFmpegManager.getCacheDir) return;
  var dir = FFmpegManager.getCacheDir();
  try {
    fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true });
    FFmpegManager.clearCaches();
    thumbLookupCache = {};
    var el = document.getElementById("cacheSizeDisplay");
    if (el) el.textContent = "0 KB";
    showToast("Cache limpo");
    refreshFiles();
  } catch (e) {
    showToast("Erro ao limpar cache: " + e.message);
  }
}

function clearCacheFolder() {
  var size = getCacheSize();
  if (size === "0 KB" || size === "—") {
    showToast("Cache ja esta vazio");
    return;
  }
  showConfirmModal({
    title: "Limpar cache?",
    message: "Vamos remover <b>" + size + "</b> em thumbs e proxies de preview. " +
             "Eles serao regerados conforme voce reabrir os arquivos.",
    confirmLabel: "Limpar",
    cancelLabel: "Cancelar",
    danger: true,
    onConfirm: _doClearCache
  });
}

function togglePreviewHover() {
  var toggle = document.getElementById("previewHoverToggle");
  state.previewHoverEnabled = toggle ? toggle.checked : !state.previewHoverEnabled;
  saveState();
  showToast(state.previewHoverEnabled ? "Preview ativado" : "Preview desativado");
}

function forceUpdateCheck() {
  if (typeof UpdateManager !== "undefined" && UpdateManager.check) {
    showToast("Verificando atualizacao...");
    UpdateManager.check();
  }
}

function openFFmpegHelp() {
  if (typeof showFFmpegMissingModal === "function") showFFmpegMissingModal();
}

// Colapsa ou expande a sidebar e persiste no state.
function setSidebarCollapsed(collapsed) {
  state.sidebarCollapsed = !!collapsed;
  saveState();
  applySidebarCollapsed();
}

function applySidebarCollapsed() {
  var sidebar = document.getElementById("sidebar");
  var expandBtn = document.getElementById("sidebarExpandBtn");
  if (!sidebar) return;
  if (state.sidebarCollapsed) {
    sidebar.style.display = "none";
    if (expandBtn) expandBtn.style.display = "flex";
  } else {
    sidebar.style.display = "";
    if (expandBtn) expandBtn.style.display = "none";
  }
}

// Sincroniza estado visual do menu de ordenacao com state.sortBy / sortOrder
function syncSortMenuActive() {
  var items = document.querySelectorAll("#sortMenu .sort-menu-item[data-sort]");
  for (var i = 0; i < items.length; i++) {
    items[i].classList.toggle("active", items[i].getAttribute("data-sort") === state.sortBy);
  }
  var label = document.getElementById("sortOrderLabel");
  var icon = document.getElementById("sortOrderIcon");
  if (label) label.textContent = state.sortOrder === "desc" ? "Decrescente" : "Crescente";
  if (icon) icon.classList.toggle("flipped", state.sortOrder === "desc");
}

// Atualiza o indicador de cloud na status bar conforme a pasta atual.
function updateCloudIndicator(folder) {
  var el = document.getElementById("cloudIndicator");
  var txt = document.getElementById("cloudIndicatorText");
  if (!el) return;
  var info = (typeof detectCloudPath === "function") ? detectCloudPath(folder) : null;
  state.cloudFolderInfo = info;
  if (!info) { el.style.display = "none"; return; }
  el.style.display = "inline-flex";
  el.classList.remove("staging");
  var label = "DRIVE";
  if (info.provider === "google-drive") label = info.shared ? "DRIVE COMPARTILHADO" : "GOOGLE DRIVE";
  else if (info.provider === "onedrive") label = "ONEDRIVE";
  else if (info.provider === "dropbox") label = "DROPBOX";
  else if (info.provider === "box") label = "BOX";
  if (txt) txt.textContent = label;
  el.title = "Pasta de assets em " + label.toLowerCase() + " — staging local ativo automaticamente para evitar problemas de Collect/Export.";
}

// Sinaliza atividade de staging (chamado pelo staging.js)
function setCloudIndicatorBusy(busy) {
  var el = document.getElementById("cloudIndicator");
  if (!el || el.style.display === "none") return;
  el.classList.toggle("staging", !!busy);
  var txt = document.getElementById("cloudIndicatorText");
  if (txt && busy) txt.textContent = "COPIANDO...";
  else if (txt && state.cloudFolderInfo) {
    var info = state.cloudFolderInfo;
    if (info.provider === "google-drive") txt.textContent = info.shared ? "DRIVE COMPARTILHADO" : "GOOGLE DRIVE";
    else if (info.provider === "onedrive") txt.textContent = "ONEDRIVE";
    else if (info.provider === "dropbox") txt.textContent = "DROPBOX";
    else if (info.provider === "box") txt.textContent = "BOX";
  }
}

function saveSettings() {
  saveState();
  toggleSettings();
  refreshFiles();
}

function updateGridSize() {
  state.gridSize = parseInt(document.getElementById("gridSize").value);
  document.getElementById("fileGrid").style.gridTemplateColumns =
    "repeat(auto-fill, minmax(" + state.gridSize + "px, 1fr))";
  saveState();
}
