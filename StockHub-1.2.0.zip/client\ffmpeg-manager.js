// =============================================================================
// ffmpeg-manager.js — Modulo de FFmpeg do StockHub
//
// Responsabilidades:
//   - Localizar binarios ffmpeg/ffprobe no sistema
//   - Gerar thumbnails de video (JPG)
//   - Gerar proxy de preview (MP4 360p)
//   - Obter duracao e resolucao de video
//   - Gerenciar cache de thumbs/proxy/resolucao
//   - Controlar processos ffmpeg ativos (kill on demand)
//
// Dependencias externas (recebidas via init):
//   - getStockFolder, toRelPath, toFileURL
// =============================================================================

// Funcao pura testavel (fora da IIFE)
function _hashDjb2(str) {
  if (!str) return "0";
  var h = 5381;
  for (var i = 0; i < str.length; i++) {
    h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  }
  var base = String(str).replace(/[^a-zA-Z0-9]/g, "_");
  var tail = base.substring(Math.max(0, base.length - 60));
  return tail + "_" + (h >>> 0).toString(16);
}

// IIFE — encapsula estado privado (so roda no browser)
if (typeof window !== "undefined") (function() {
  var _fs    = require("fs");
  var _path  = require("path");
  var _child = require("child_process");
  var _isWin = process.platform === "win32";

  // Dependencias injetadas via init()
  var _getStockFolder = null;
  var _toRelPath      = null;
  var _toFileURL      = null;

  // Estado privado
  var thumbCache      = {};
  var proxyCache      = {};
  var resolutionCache = {};
  var ffmpegPath      = null;
  var ffprobePath     = null;
  var activeProxyProc = null;
  var activeThumbChildren = [];

  // -------------------------------------------------------------------------
  // Cache
  // -------------------------------------------------------------------------

  function getCacheDir() {
    return _path.join(_getStockFolder(), ".cache");
  }

  function ensureCacheDir() {
    var dir = getCacheDir();
    if (!_fs.existsSync(dir)) {
      _fs.mkdirSync(dir, { recursive: true });
    }
    return dir;
  }

  function hashPath(absPath) {
    var rel = _toRelPath(absPath);
    return _hashDjb2(rel);
  }

  // -------------------------------------------------------------------------
  // Localizar FFmpeg
  // -------------------------------------------------------------------------

  function findFFmpeg() {
    if (ffmpegPath) return ffmpegPath;
    var ffprobeBin = _isWin ? "ffprobe.exe" : "ffprobe";

    // Try system PATH lookup
    try {
      var whichCmd = _isWin ? "where ffmpeg" : "which ffmpeg";
      var result = _child.execSync(whichCmd, { timeout: 5000, encoding: "utf-8" });
      var lines = result.trim().split("\n");
      if (lines[0] && _fs.existsSync(lines[0].trim())) {
        ffmpegPath = lines[0].trim();
        ffprobePath = _path.join(_path.dirname(ffmpegPath), ffprobeBin);
        if (!_fs.existsSync(ffprobePath)) ffprobePath = null;
        return ffmpegPath;
      }
    } catch (e) {}

    var locations = [];

    if (_isWin) {
      var localAppData = process.env.LOCALAPPDATA || "";
      var userProfile = process.env.USERPROFILE || "";
      locations = [
        "C:\\ffmpeg\\bin\\ffmpeg.exe",
        "C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe",
        "C:\\Program Files (x86)\\ffmpeg\\bin\\ffmpeg.exe",
        _path.join(localAppData, "ffmpeg", "bin", "ffmpeg.exe"),
        _path.join(userProfile, "ffmpeg", "bin", "ffmpeg.exe"),
        _path.join(userProfile, "scoop", "shims", "ffmpeg.exe")
      ];

      // Search WinGet packages
      try {
        var wingetPkgs = _path.join(localAppData, "Microsoft", "WinGet", "Packages");
        if (_fs.existsSync(wingetPkgs)) {
          var pkgDirs = _fs.readdirSync(wingetPkgs);
          for (var w = 0; w < pkgDirs.length; w++) {
            if (pkgDirs[w].toLowerCase().indexOf("ffmpeg") >= 0) {
              var pkgDir = _path.join(wingetPkgs, pkgDirs[w]);
              var subDirs = _fs.readdirSync(pkgDir);
              for (var s = 0; s < subDirs.length; s++) {
                var binPath = _path.join(pkgDir, subDirs[s], "bin", "ffmpeg.exe");
                if (_fs.existsSync(binPath)) {
                  locations.unshift(binPath);
                }
              }
            }
          }
        }
      } catch (e) {}
    } else {
      // macOS / Linux common locations
      locations = [
        "/usr/local/bin/ffmpeg",
        "/opt/homebrew/bin/ffmpeg",
        "/usr/bin/ffmpeg",
        "/opt/local/bin/ffmpeg"
      ];
    }

    for (var i = 0; i < locations.length; i++) {
      if (locations[i] && _fs.existsSync(locations[i])) {
        ffmpegPath = locations[i];
        ffprobePath = _path.join(_path.dirname(ffmpegPath), ffprobeBin);
        if (!_fs.existsSync(ffprobePath)) ffprobePath = null;
        return ffmpegPath;
      }
    }

    return null;
  }

  // -------------------------------------------------------------------------
  // Metadata
  // -------------------------------------------------------------------------

  function getVideoDuration(filePath, callback) {
    if (!ffprobePath) { callback(null); return; }
    _child.execFile(ffprobePath, [
      "-v", "error",
      "-show_entries", "format=duration",
      "-of", "csv=p=0",
      filePath
    ], { timeout: 10000 }, function(err, stdout) {
      if (err) { callback(null); return; }
      var dur = parseFloat(stdout);
      callback(isNaN(dur) ? null : dur);
    });
  }

  function getVideoResolution(filePath, callback) {
    if (resolutionCache[filePath]) { callback(resolutionCache[filePath]); return; }
    if (!ffprobePath) { callback(null); return; }
    _child.execFile(ffprobePath, [
      "-v", "error",
      "-select_streams", "v:0",
      "-show_entries", "stream=width,height",
      "-of", "csv=s=x:p=0",
      filePath
    ], { timeout: 10000 }, function(err, stdout) {
      if (err || !stdout) { callback(null); return; }
      var parts = stdout.trim().split("x");
      if (parts.length === 2) {
        var res = parts[0] + "x" + parts[1];
        resolutionCache[filePath] = res;
        callback(res);
      } else {
        callback(null);
      }
    });
  }

  // -------------------------------------------------------------------------
  // Thumbnail & Proxy generation
  // -------------------------------------------------------------------------

  function generateThumbFFmpeg(filePath, callback) {
    var ffmpeg = findFFmpeg();
    if (!ffmpeg) { callback(null); return; }

    var cacheDir = ensureCacheDir();
    var hash = hashPath(filePath);
    var thumbFile = _path.join(cacheDir, hash + "_thumb.jpg");

    if (_fs.existsSync(thumbFile)) {
      thumbCache[filePath] = _toFileURL(thumbFile);
      callback(thumbCache[filePath]);
      return;
    }

    getVideoDuration(filePath, function(duration) {
      var seekTime = duration ? (duration / 2) : 1;
      var proc = _child.execFile(ffmpeg, [
        "-ss", String(seekTime),
        "-i", filePath,
        "-vframes", "1",
        "-q:v", "5",
        "-vf", "scale=240:-1",
        "-y",
        thumbFile
      ], { timeout: 15000 }, function(err) {
        var idx = activeThumbChildren.indexOf(proc);
        if (idx >= 0) activeThumbChildren.splice(idx, 1);
        if (err || !_fs.existsSync(thumbFile)) {
          callback(null);
          return;
        }
        thumbCache[filePath] = _toFileURL(thumbFile);
        callback(thumbCache[filePath]);
      });
      activeThumbChildren.push(proc);
    });
  }

  function generateProxyFFmpeg(filePath, callback) {
    var ffmpeg = findFFmpeg();
    if (!ffmpeg) { callback(null); return; }

    var cacheDir = ensureCacheDir();
    var hash = hashPath(filePath);
    var proxyFile = _path.join(cacheDir, hash + "_proxy.mp4");

    if (_fs.existsSync(proxyFile)) {
      proxyCache[filePath] = _toFileURL(proxyFile);
      callback(proxyCache[filePath]);
      return;
    }

    killActiveProxyProc();
    activeProxyProc = _child.execFile(ffmpeg, [
      "-i", filePath,
      "-vf", "scale=-2:360",
      "-c:v", "libx264",
      "-preset", "ultrafast",
      "-crf", "30",
      "-an",
      "-movflags", "+faststart",
      "-t", "15",
      "-y",
      proxyFile
    ], { timeout: 60000 }, function(err) {
      activeProxyProc = null;
      if (err || !_fs.existsSync(proxyFile)) {
        callback(null);
        return;
      }
      proxyCache[filePath] = _toFileURL(proxyFile);
      callback(proxyCache[filePath]);
    });
  }

  // -------------------------------------------------------------------------
  // Process management
  // -------------------------------------------------------------------------

  function killActiveProxyProc() {
    if (activeProxyProc) {
      try { activeProxyProc.kill("SIGKILL"); } catch (e) {}
      activeProxyProc = null;
    }
  }

  function killActiveThumbChildren() {
    for (var i = 0; i < activeThumbChildren.length; i++) {
      try { activeThumbChildren[i].kill("SIGKILL"); } catch (e) {}
    }
    activeThumbChildren = [];
  }

  function clearCaches() {
    thumbCache = {};
    proxyCache = {};
    resolutionCache = {};
  }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.FFmpegManager = {
    init: function(deps) {
      _getStockFolder = deps.getStockFolder;
      _toRelPath      = deps.toRelPath;
      _toFileURL      = deps.toFileURL;
    },
    findFFmpeg:            findFFmpeg,
    getVideoDuration:      getVideoDuration,
    getVideoResolution:    getVideoResolution,
    generateThumbFFmpeg:   generateThumbFFmpeg,
    generateProxyFFmpeg:   generateProxyFFmpeg,
    killActiveProxyProc:   killActiveProxyProc,
    killActiveThumbChildren: killActiveThumbChildren,
    getCacheDir:           getCacheDir,
    ensureCacheDir:        ensureCacheDir,
    hashPath:              hashPath,
    clearCaches:           clearCaches,
    thumbCache:            thumbCache,
    proxyCache:            proxyCache,
    resolutionCache:       resolutionCache
  };

  // Aliases globais para acesso direto no app.js
  window.findFFmpeg            = findFFmpeg;
  window.getVideoDuration      = getVideoDuration;
  window.getVideoResolution    = getVideoResolution;
  window.generateThumbFFmpeg   = generateThumbFFmpeg;
  window.generateProxyFFmpeg   = generateProxyFFmpeg;
  window.killActiveProxyProc   = killActiveProxyProc;
  window.killActiveThumbChildren = killActiveThumbChildren;
  window.getCacheDir           = getCacheDir;
  window.ensureCacheDir        = ensureCacheDir;
  window.hashPath              = hashPath;
  window.thumbCache            = thumbCache;
  window.proxyCache            = proxyCache;
  window.resolutionCache       = resolutionCache;

})();

// Node.js exports para testes
if (typeof module !== "undefined") {
  module.exports = { _hashDjb2: _hashDjb2 };
}
