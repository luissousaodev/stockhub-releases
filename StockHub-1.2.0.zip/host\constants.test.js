// constants.test.js — Testes para core/constants.js
// Roda em Node.js puro, sem dependencias de browser

var assert = require("assert");
var mod = require("../client/core/constants.js");
var getFileType = mod.getFileType;
var FORMAT_GROUPS = mod.FORMAT_GROUPS;
var ALL_EXTENSIONS = mod.ALL_EXTENSIONS;
var DEFAULT_CATEGORIES = mod.DEFAULT_CATEGORIES;

var passed = 0;
var failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log("  PASS: " + name);
  } catch (e) {
    failed++;
    console.error("  FAIL: " + name + " — " + e.message);
  }
}

console.log("\n=== constants tests ===\n");

// --- getFileType ---

test("getFileType: .mp4 retorna video", function() {
  assert.strictEqual(getFileType(".mp4"), "video");
});

test("getFileType: .mov retorna video", function() {
  assert.strictEqual(getFileType(".mov"), "video");
});

test("getFileType: .mp3 retorna audio", function() {
  assert.strictEqual(getFileType(".mp3"), "audio");
});

test("getFileType: .wav retorna audio", function() {
  assert.strictEqual(getFileType(".wav"), "audio");
});

test("getFileType: .jpg retorna image", function() {
  assert.strictEqual(getFileType(".jpg"), "image");
});

test("getFileType: .png retorna image", function() {
  assert.strictEqual(getFileType(".png"), "image");
});

test("getFileType: .mogrt retorna mogrt", function() {
  assert.strictEqual(getFileType(".mogrt"), "mogrt");
});

test("getFileType: extensao desconhecida retorna null", function() {
  assert.strictEqual(getFileType(".xyz"), null);
});

test("getFileType: string vazia retorna null", function() {
  assert.strictEqual(getFileType(""), null);
});

test("getFileType: .braw retorna video", function() {
  assert.strictEqual(getFileType(".braw"), "video");
});

test("getFileType: .flac retorna audio", function() {
  assert.strictEqual(getFileType(".flac"), "audio");
});

test("getFileType: .psd retorna image", function() {
  assert.strictEqual(getFileType(".psd"), "image");
});

// --- FORMAT_GROUPS ---

test("FORMAT_GROUPS: tem 4 grupos", function() {
  var keys = Object.keys(FORMAT_GROUPS);
  assert.strictEqual(keys.length, 4);
  assert.ok(keys.indexOf("video") >= 0);
  assert.ok(keys.indexOf("audio") >= 0);
  assert.ok(keys.indexOf("image") >= 0);
  assert.ok(keys.indexOf("mogrt") >= 0);
});

test("FORMAT_GROUPS: video contem extensoes comuns", function() {
  assert.ok(FORMAT_GROUPS.video.indexOf(".mp4") >= 0);
  assert.ok(FORMAT_GROUPS.video.indexOf(".mov") >= 0);
  assert.ok(FORMAT_GROUPS.video.indexOf(".avi") >= 0);
});

test("FORMAT_GROUPS: audio contem extensoes comuns", function() {
  assert.ok(FORMAT_GROUPS.audio.indexOf(".mp3") >= 0);
  assert.ok(FORMAT_GROUPS.audio.indexOf(".wav") >= 0);
});

// --- ALL_EXTENSIONS ---

test("ALL_EXTENSIONS: contem todas as extensoes de todos os grupos", function() {
  var total = FORMAT_GROUPS.video.length + FORMAT_GROUPS.audio.length +
    FORMAT_GROUPS.image.length + FORMAT_GROUPS.mogrt.length;
  assert.strictEqual(ALL_EXTENSIONS.length, total);
});

test("ALL_EXTENSIONS: inclui .mp4 e .mogrt", function() {
  assert.ok(ALL_EXTENSIONS.indexOf(".mp4") >= 0);
  assert.ok(ALL_EXTENSIONS.indexOf(".mogrt") >= 0);
});

// --- DEFAULT_CATEGORIES ---

test("DEFAULT_CATEGORIES: primeira categoria e 'all' (system)", function() {
  assert.strictEqual(DEFAULT_CATEGORIES[0].id, "all");
  assert.strictEqual(DEFAULT_CATEGORIES[0].system, true);
});

test("DEFAULT_CATEGORIES: tem pelo menos 5 categorias", function() {
  assert.ok(DEFAULT_CATEGORIES.length >= 5);
});

test("DEFAULT_CATEGORIES: cada categoria tem id, name e color", function() {
  DEFAULT_CATEGORIES.forEach(function(cat) {
    assert.ok(cat.id, "categoria sem id");
    assert.ok(cat.name, "categoria sem name");
    assert.ok(cat.color, "categoria sem color");
  });
});

// --- Resumo ---

console.log("\nTotal: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
if (failed > 0) process.exit(1);
