// StockHub - CEP Extension for Premiere Pro
var APP_VERSION = (function () {
  try {
    var vf = require("path").join(__dirname, "..", "version.json");
    return JSON.parse(require("fs").readFileSync(vf, "utf-8")).version || "0.0.0";
  } catch (e) { return "0.0.0"; }
})();
var cs = new CSInterface();
var fs = require("fs");
var path = require("path");
var child = require("child_process");
var os = require("os");
var https = require("https");
var isWindows = process.platform === "win32";
var isMac = process.platform === "darwin";

// Estado global de drag — usado para pausar trabalho pesado de ffmpeg
var isDragging = false;
// Sinalizador para pausar a fila de geracao de thumbs em background
var thumbQueuePaused = false;

// Converte caminho do filesystem para URL file:// valida em Windows e macOS.
// Windows: C:\foo\bar -> file:///C:/foo/bar
// macOS:   /Users/foo -> file:///Users/foo
function toFileURL(p) {
  if (!p) return p;
  var normalized = String(p).replace(/\\/g, "/");
  if (normalized.charAt(0) === "/") {
    // path absoluto unix: remove a barra inicial para nao gerar file:////
    return "file://" + normalized;
  }
  return "file:///" + normalized;
}

// --- Format Groups ---
var FORMAT_GROUPS = {
  video: [".mp4",".mov",".avi",".mxf",".m4v",".wmv",".mkv",".flv",".mpg",".mpeg",".m2v",".m2t",".m2ts",".mts",".ts",".vob",".webm",".3gp",".f4v",".r3d",".braw"],
  audio: [".mp3",".wav",".aac",".aif",".aiff",".ogg",".wma",".flac",".m4a"],
  image: [".jpg",".jpeg",".png",".bmp",".tif",".tiff",".psd",".gif",".dpx",".exr",".tga",".ai",".eps",".svg"],
  mogrt: [".mogrt"]
};

var ALL_EXTENSIONS = [].concat(FORMAT_GROUPS.video, FORMAT_GROUPS.audio, FORMAT_GROUPS.image, FORMAT_GROUPS.mogrt);

// --- State ---
var state = {
  files: [],
  categories: [
    { id: "all", name: "Todos", color: "#0078d4", system: true },
    { id: "overlays", name: "Overlays", color: "#f44747" },
    { id: "transitions", name: "Transicoes", color: "#4ec9b0" },
    { id: "backgrounds", name: "Backgrounds", color: "#ce9178" },
    { id: "lower-thirds", name: "Lower Thirds", color: "#dcdcaa" },
    { id: "icons", name: "Icones", color: "#c586c0" },
    { id: "sfx", name: "SFX/Audio", color: "#569cd6" },
  ],
  activeCategory: "all",
  activeFormat: "all",
  searchQuery: "",
  gridSize: 110,
  showSettings: false,
  fileCategories: {},
  customFolder: null,
  autoCategories: true,
  deletedCategoryIds: [],
  favoriteFiles: {},
  userId: null,
  stagingFolder: null,
  lastSeenVersion: null,
  lastUpdateDismissedAt: null,
  updateDismissedVersion: null,
  welcomed: false,
};

// --- Stock Folder ---
function getDefaultStockFolder() {
  var home = process.env.HOME || process.env.USERPROFILE || "";
  return path.join(home, "StockHub");
}

function getStockFolder() {
  return state.customFolder || getDefaultStockFolder();
}

function ensureStockFolder() {
  try {
    var folder = getStockFolder();
    if (!fs.existsSync(folder)) {
      fs.mkdirSync(folder, { recursive: true });
      ["Videos", "Imagens", "Audio", "Transicoes", "MOGRT"].forEach(function(sub) {
        fs.mkdirSync(path.join(folder, sub), { recursive: true });
      });
    }
    return folder;
  } catch (e) {
    alert("Erro ao criar pasta StockHub: " + e.toString());
    return null;
  }
}

function openStockFolder() {
  try {
    var folder = getStockFolder().replace(/\\/g, "/");
    cs.evalScript('new Folder("' + folder + '").execute()');
  } catch (e) {}
}

function changeStockFolder() {
  if (isWindows) {
    var psFile = path.join(os.tmpdir(), "stockhub_folder_picker.ps1");
    var psContent = [
      'Add-Type -AssemblyName System.Windows.Forms',
      '',
      '$source = @"',
      'using System;',
      'using System.Runtime.InteropServices;',
      'using System.Windows.Forms;',
      '',
      '[ComImport, Guid("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7")]',
      'class FileOpenDialogRCW {}',
      '',
      '[ComImport, Guid("d57c7288-d4ad-4768-be02-9d969532d960"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]',
      'interface IFileOpenDialog {',
      '    [PreserveSig] int Show(IntPtr hwndOwner);',
      '    void SetFileTypes(); void SetFileTypeIndex(); void GetFileTypeIndex();',
      '    void Advise(); void Unadvise();',
      '    void SetOptions(uint fos); void GetOptions(out uint pfos);',
      '    void SetDefaultFolder(IShellItem psi); void SetFolder(IShellItem psi);',
      '    void GetFolder(out IShellItem ppsi); void GetCurrentSelection(out IShellItem ppsi);',
      '    void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string pszName);',
      '    void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string pszName);',
      '    void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string pszTitle);',
      '    void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string pszText);',
      '    void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string pszLabel);',
      '    void GetResult(out IShellItem ppsi);',
      '    void AddPlace(IShellItem psi, int alignment);',
      '    void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string pszDefaultExtension);',
      '    void Close(int hr); void SetClientGuid(ref Guid guid);',
      '    void ClearClientData(); void SetFilter(IntPtr pFilter);',
      '}',
      '',
      '[ComImport, Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]',
      'interface IShellItem {',
      '    void BindToHandler(); void GetParent();',
      '    [PreserveSig] int GetDisplayName(uint sigdnName, [MarshalAs(UnmanagedType.LPWStr)] out string ppszName);',
      '    void GetAttributes(); void Compare();',
      '}',
      '',
      'public class FolderPicker {',
      '    public static string Show(IntPtr hwnd) {',
      '        var dlg = (IFileOpenDialog)new FileOpenDialogRCW();',
      '        dlg.SetTitle("Selecionar pasta de assets");',
      '        dlg.SetOkButtonLabel("Selecionar pasta");',
      '        uint opts; dlg.GetOptions(out opts);',
      '        dlg.SetOptions(opts | 0x20);',
      '        if (dlg.Show(hwnd) != 0) return "";',
      '        IShellItem item; dlg.GetResult(out item);',
      '        string path; item.GetDisplayName(0x80058000, out path);',
      '        return path;',
      '    }',
      '}',
      '"@',
      '',
      'Add-Type -TypeDefinition $source -ReferencedAssemblies System.Windows.Forms',
      '',
      '$form = New-Object System.Windows.Forms.Form',
      '$form.TopMost = $true',
      '$form.Width = 0',
      '$form.Height = 0',
      '$form.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual',
      '$form.Location = New-Object System.Drawing.Point(-1000,-1000)',
      '$form.Show()',
      '$result = [FolderPicker]::Show($form.Handle)',
      '$form.Close()',
      'if ($result) { $result }',
    ].join("\n");
    fs.writeFileSync(psFile, psContent, "utf-8");
    child.exec('powershell -ExecutionPolicy Bypass -File "' + psFile + '"', function(err, stdout, stderr) {
      try { fs.unlinkSync(psFile); } catch(e) {}
      var result = stdout ? stdout.trim() : "";
      if (!err && result) {
        showAutoCategoryModal(result);
      }
    });
  } else {
    var appleScript = "osascript -e 'tell application \"System Events\"' -e 'activate' -e 'set folderPath to POSIX path of (choose folder with prompt \"Selecionar pasta de assets\")' -e 'end tell'";
    child.exec(appleScript, function(err, stdout) {
      var result = stdout ? stdout.trim() : "";
      if (!err && result) {
        showAutoCategoryModal(result);
      }
    });
  }
}

function showAutoCategoryModal(folderPath) {
  var container = document.getElementById("modalContainer");
  container.innerHTML =
    '<div class="modal-overlay" onclick="closeModal(event)">' +
      '<div class="modal" onclick="event.stopPropagation()">' +
        '<h3>Criar categorias automaticamente?</h3>' +
        '<p style="font-size:11px;color:var(--text-secondary);margin:8px 0 12px;">Subpastas encontradas serao adicionadas como categorias no painel lateral.</p>' +
        '<div class="modal-actions">' +
          '<button class="btn" onclick="applyFolderChange(\'' + folderPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + '\', false)">Nao criar</button>' +
          '<button class="btn btn-primary" onclick="applyFolderChange(\'' + folderPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + '\', true)">Criar categorias</button>' +
        '</div>' +
      '</div>' +
    '</div>';
}

function applyFolderChange(folderPath, autoCategories) {
  closeModal();
  // Fechar configs/métricas e voltar para tela de assets
  if (state.showSettings) toggleSettings();
  if (metricsState.visible) toggleMetrics();
  state.customFolder = folderPath;
  state.autoCategories = autoCategories;
  state.categories = state.categories.filter(function(c) { return c.system; });
  state.fileCategories = {};
  state.deletedCategoryIds = [];
  state.activeCategory = "all";
  saveState();
  ensureStockFolder();
  thumbLookupCache = {};
  FFmpegManager.clearCaches();
  refreshFiles();
  showToast("Pasta alterada: " + folderPath);
}

function resetStockFolder() {
  if (state.showSettings) toggleSettings();
  if (metricsState.visible) toggleMetrics();
  state.customFolder = null;
  state.categories = state.categories.filter(function(c) { return c.system; });
  state.fileCategories = {};
  state.deletedCategoryIds = [];
  state.activeCategory = "all";
  saveState();
  ensureStockFolder();
  thumbLookupCache = {};
  FFmpegManager.clearCaches();
  refreshFiles();
  showToast("Pasta restaurada para padrao: " + getDefaultStockFolder());
}

// --- Storage ---
function getStoragePath() {
  var dataDir = cs.getSystemPath(SystemPath.USER_DATA);
  return path.join(dataDir, "stockhub-data.json");
}

// Migra um dicionario keyed por path absoluto para path relativo a pasta
// de stock. Usado uma unica vez quando o stockhub-data.json esta no formato
// antigo (dataSchemaVersion < 2). Retorna o novo objeto.
function migrateAbsoluteKeysToRelative(dict, stockFolder) {
  if (!dict) return dict;
  var out = {};
  var keys = Object.keys(dict);
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    // Detecta path absoluto: "C:\..." no Windows, "/..." no Unix
    var isAbs = (k.length > 2 && k.charAt(1) === ":") || k.charAt(0) === "/" || k.charAt(0) === "\\";
    if (!isAbs) {
      out[k] = dict[k]; // ja esta relativo
      continue;
    }
    try {
      var rel = path.relative(stockFolder, k);
      if (!rel || rel.indexOf("..") === 0) continue; // fora da pasta — descarta
      out[rel.split(path.sep).join("/")] = dict[k];
    } catch (e) {}
  }
  return out;
}

function loadState() {
  try {
    var filePath = getStoragePath();
    if (fs.existsSync(filePath)) {
      var data = JSON.parse(fs.readFileSync(filePath, "utf-8"));
      if (data.categories) state.categories = data.categories;
      if (data.gridSize) state.gridSize = data.gridSize;
      if (data.fileCategories) state.fileCategories = data.fileCategories;
      if (data.customFolder) {
        if (fs.existsSync(data.customFolder)) {
          state.customFolder = data.customFolder;
        } else {
          console.warn("Pasta personalizada nao encontrada, revertendo para padrao:", data.customFolder);
          state.customFolder = null;
        }
      }
      if (data.autoCategories !== undefined) state.autoCategories = data.autoCategories;
      if (data.deletedCategoryIds) state.deletedCategoryIds = data.deletedCategoryIds;
      if (data.userId) state.userId = data.userId;
      if (data.sidebarWidth) state.sidebarWidth = data.sidebarWidth;
      if (data.favoriteFiles) state.favoriteFiles = data.favoriteFiles;
      if (data.stagingFolder) state.stagingFolder = data.stagingFolder;
      if (data.lastSeenVersion) state.lastSeenVersion = data.lastSeenVersion;
      if (data.lastUpdateDismissedAt) state.lastUpdateDismissedAt = data.lastUpdateDismissedAt;
      if (data.updateDismissedVersion) state.updateDismissedVersion = data.updateDismissedVersion;
      if (data.welcomed) state.welcomed = data.welcomed;
      state.dataSchemaVersion = data.dataSchemaVersion || 1;

      // Migracao one-shot: chaves absolutas -> chaves relativas a pasta de stock.
      // Roda uma unica vez quando o arquivo esta no formato antigo (v1).
      if (state.dataSchemaVersion < 2) {
        var stockFolder = getStockFolder();
        state.fileCategories = migrateAbsoluteKeysToRelative(state.fileCategories, stockFolder);
        state.favoriteFiles = migrateAbsoluteKeysToRelative(state.favoriteFiles, stockFolder);
        state.dataSchemaVersion = 2;
        try { saveState(); } catch (e) {}
        console.log("StockHub: migrado stockhub-data.json para schema v2 (paths relativos)");
      }
    }
  } catch (e) {
    console.log("No saved state:", e);
  }
}

function saveState() {
  try {
    var filePath = getStoragePath();
    var dataDir = path.dirname(filePath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(filePath, JSON.stringify({
      dataSchemaVersion: 2,
      categories: state.categories,
      gridSize: state.gridSize,
      fileCategories: state.fileCategories,
      customFolder: state.customFolder,
      autoCategories: state.autoCategories,
      deletedCategoryIds: state.deletedCategoryIds,
      favoriteFiles: state.favoriteFiles,
      userId: state.userId,
      sidebarWidth: state.sidebarWidth,
      stagingFolder: state.stagingFolder,
      lastSeenVersion: state.lastSeenVersion,
      lastUpdateDismissedAt: state.lastUpdateDismissedAt,
      updateDismissedVersion: state.updateDismissedVersion,
      welcomed: state.welcomed,
    }), "utf-8");
  } catch (e) {
    console.error("Save failed:", e);
  }
}

// --- Staging Local ---
function getDefaultStagingFolder() {
  var home = process.env.HOME || process.env.USERPROFILE || "";
  return path.join(home, "StockHub_staging");
}
function getStagingFolder() {
  return state.stagingFolder || getDefaultStagingFolder();
}

function stageFileIfNeeded(file) {
  if (!file || !file.cloudOnly) return file.path;
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  // Se ja existe com mesmo tamanho, reusar
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size === file.size && st.size > 0) return stagedPath;
    }
  } catch (e) {}
  // Copiar para staging
  try {
    fs.mkdirSync(path.dirname(stagedPath), { recursive: true });
    fs.copyFileSync(file.path, stagedPath);
    showToast("Asset copiado para staging local");
    return stagedPath;
  } catch (e) {
    console.error("Staging copy failed:", e);
    return file.path; // fallback para path original
  }
}

function getStagedPathIfExists(file) {
  if (!file || !file.cloudOnly) return null;
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size > 0) return stagedPath;
    }
  } catch (e) {}
  return null;
}

function changeStagingFolder() {
  var result = window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx
    ? window.cep.fs.showOpenDialogEx(false, true, "Escolha a pasta de staging", "")
    : null;
  if (result && result.data && result.data.length > 0) {
    state.stagingFolder = result.data[0];
    saveState();
    var el = document.getElementById("stagingFolderPath");
    if (el) el.textContent = state.stagingFolder;
    showToast("Pasta de staging alterada");
  }
}

function getStagingSize() {
  var folder = getStagingFolder();
  var total = 0;
  function walk(dir) {
    try {
      var items = fs.readdirSync(dir);
      for (var i = 0; i < items.length; i++) {
        var full = path.join(dir, items[i]);
        var st = fs.statSync(full);
        if (st.isDirectory()) walk(full);
        else total += st.size;
      }
    } catch (e) {}
  }
  try { if (fs.existsSync(folder)) walk(folder); } catch (e) {}
  if (total < 1024 * 1024) return (total / 1024).toFixed(1) + " KB";
  if (total < 1024 * 1024 * 1024) return (total / (1024 * 1024)).toFixed(1) + " MB";
  return (total / (1024 * 1024 * 1024)).toFixed(1) + " GB";
}

function clearStagingFolder() {
  var folder = getStagingFolder();
  try {
    fs.rmSync(folder, { recursive: true, force: true });
    fs.mkdirSync(folder, { recursive: true });
    var el = document.getElementById("stagingSize");
    if (el) el.textContent = "0 KB";
    showToast("Staging limpo com sucesso");
  } catch (e) {
    showToast("Erro ao limpar staging: " + e.message);
  }
}

// Auto-update gerenciado por update-manager.js

// --- File Scanning ---
function getFileType(ext) {
  if (FORMAT_GROUPS.video.indexOf(ext) >= 0) return "video";
  if (FORMAT_GROUPS.audio.indexOf(ext) >= 0) return "audio";
  if (FORMAT_GROUPS.image.indexOf(ext) >= 0) return "image";
  if (FORMAT_GROUPS.mogrt.indexOf(ext) >= 0) return "mogrt";
  return null;
}

function scanFolder(folderPath) {
  var files = [];

  try {
    if (!folderPath || !fs.existsSync(folderPath)) {
      console.error("Pasta nao encontrada:", folderPath);
      return files;
    }

    function walk(dir, category, depth, parentCatId) {
      var items;
      try {
        items = fs.readdirSync(dir);
      } catch (e) {
        return;
      }

      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var fullPath = path.join(dir, item);
        var stat;
        try {
          stat = fs.statSync(fullPath);
        } catch (e) {
          continue;
        }

        if (stat.isDirectory()) {
          if (item.charAt(0) === "." || item === "stockhub-data") continue;
          var catId = item.toLowerCase().replace(/[^a-z0-9]/g, "-");
          if (depth === 1 && parentCatId) catId = parentCatId + "/" + catId;
          if (depth <= 1 && state.autoCategories) {
            var exists = false;
            for (var j = 0; j < state.categories.length; j++) {
              if (state.categories[j].id === catId) { exists = true; break; }
            }
            if (!exists && state.deletedCategoryIds.indexOf(catId) === -1) {
              var catObj = { id: catId, name: item, color: getRandomColor() };
              if (depth === 1) catObj.parent = parentCatId;
              state.categories.push(catObj);
            }
          }
          var nextParent = (depth === 0) ? catId : parentCatId;
          walk(fullPath, catId, depth + 1, nextParent);
        } else {
          var ext = path.extname(item).toLowerCase();
          if (ALL_EXTENSIONS.indexOf(ext) >= 0) {
            // Heuristica de placeholder do Google Drive Stream:
            // - macOS: stat.blocks === 0 para arquivos nao baixados
            // - Windows: cloud files reportam size === 0 ate o download
            // (campo .blocks pode ser undefined no Windows; tratamos como 0)
            var blocks = (typeof stat.blocks === "number") ? stat.blocks : -1;
            var cloudOnly = (blocks === 0) || (stat.size === 0);
            files.push({
              name: item,
              path: fullPath,
              ext: ext.replace(".", ""),
              type: getFileType(ext),
              category: (state.fileCategories && state.fileCategories[toRelPath(fullPath)]) || category || "all",
              size: stat.size,
              modified: stat.mtime,
              cloudOnly: cloudOnly,
            });
          }
        }
      }
    }

    walk(folderPath, null, 0, null);
  } catch (e) {
    console.error("Scan error:", e);
  }
  return files;
}

// --- Filesystem watcher (polling) ---
// fs.watch recursivo nao funciona no macOS, e Drive Desktop tampouco emite
// eventos confiaveis. Substituido por polling: a cada 5s reconstroi um snapshot
// (relPath -> {mtimeMs, size}) e dispara re-scan se houver diff. Polling tem
// custo baixo mesmo em pastas grandes do Drive porque readdir nao baixa nada.
var _watchSnapshot = null;
var _watchTimer = null;
var _watchInterval = null;
var _watchedFolder = null;
var POLL_INTERVAL_MS = 5000;

function buildSnapshot(rootDir) {
  var snap = {};
  function walk(dir) {
    var items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (var i = 0; i < items.length; i++) {
      var d = items[i];
      var name = d.name;
      if (name.charAt(0) === "." || name === "stockhub-data") continue;
      var full = path.join(dir, name);
      if (d.isDirectory()) {
        walk(full);
      } else {
        var ext = path.extname(name).toLowerCase();
        if (ALL_EXTENSIONS.indexOf(ext) < 0) continue;
        try {
          var st = fs.statSync(full);
          var rel = path.relative(rootDir, full).split(path.sep).join("/");
          snap[rel] = { m: st.mtimeMs, s: st.size };
        } catch (e) {}
      }
    }
  }
  walk(rootDir);
  return snap;
}

function snapshotsDiffer(a, b) {
  if (!a || !b) return true;
  var ak = Object.keys(a), bk = Object.keys(b);
  if (ak.length !== bk.length) return true;
  for (var i = 0; i < ak.length; i++) {
    var k = ak[i];
    if (!b[k]) return true;
    if (a[k].m !== b[k].m || a[k].s !== b[k].s) return true;
  }
  return false;
}

function stopFolderWatcher() {
  if (_watchInterval) {
    clearInterval(_watchInterval);
    _watchInterval = null;
  }
  if (_watchTimer) {
    clearTimeout(_watchTimer);
    _watchTimer = null;
  }
  _watchSnapshot = null;
  _watchedFolder = null;
}

function startFolderWatcher(folder) {
  if (_watchedFolder === folder && _watchInterval) return;
  stopFolderWatcher();
  if (!folder || !fs.existsSync(folder)) return;
  _watchedFolder = folder;
  _watchSnapshot = buildSnapshot(folder);

  function pollOnce() {
    if (_watchedFolder !== folder) return;
    var next;
    try { next = buildSnapshot(folder); } catch (e) { return; }
    if (snapshotsDiffer(_watchSnapshot, next)) {
      _watchSnapshot = next;
      // Reusa o debounce de 400ms para coalescer rajadas de mudancas
      if (_watchTimer) clearTimeout(_watchTimer);
      _watchTimer = setTimeout(function() {
        _watchTimer = null;
        try {
          state.files = scanFolder(folder);
          renderAll();
          var statusEl = document.getElementById("statusText");
          if (statusEl) statusEl.textContent = "Atualizado automaticamente";
        } catch (e) {
          console.error("Auto-refresh error:", e);
        }
      }, 400);
    } else {
      _watchSnapshot = next; // mantem snapshot atualizado
    }
  }

  _watchInterval = setInterval(pollOnce, POLL_INTERVAL_MS);
}

// Para o watcher quando a janela e fechada/recarregada
if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", function() { stopFolderWatcher(); });
}

function refreshFiles() {
  var folder = getStockFolder();
  if (state.customFolder && !fs.existsSync(state.customFolder)) {
    var invalidFolder = state.customFolder;
    state.customFolder = null;
    saveState();
    folder = getStockFolder();
    var fp = document.getElementById("stockFolderPath");
    if (fp) fp.textContent = folder;
    showToast("Pasta \"" + invalidFolder + "\" nao encontrada. Revertendo para pasta padrao.");
  }
  state.files = scanFolder(folder);
  renderAll();
  showToast(state.files.length + " arquivos encontrados");
  document.getElementById("statusText").textContent = "Atualizado";
  startFolderWatcher(folder);

  // Pre-generate ffmpeg thumbnails + detect resolutions in background
  if (findFFmpeg()) {
    var queue = [];
    var resQueue = [];
    for (var i = 0; i < state.files.length; i++) {
      var f = state.files[i];
      // Pula placeholders do Drive Stream — gerar thumb forcaria download
      if (f.cloudOnly) continue;
      if (f.type === "video") {
        if (!thumbCache[f.path]) queue.push(f);
        if (!resolutionCache[f.path]) resQueue.push(f);
      } else if (f.type === "image" && !resolutionCache[f.path]) {
        resQueue.push(f);
      }
    }

    // Detect resolutions in parallel (lightweight ffprobe calls)
    function processResQueue(idx) {
      if (idx >= resQueue.length) return;
      var rf = resQueue[idx];
      if (rf.type === "image") {
        // Use Image object for image resolution
        var img = new Image();
        img.onload = function() {
          resolutionCache[rf.path] = img.naturalWidth + "x" + img.naturalHeight;
          updateResBadge(rf.path, resolutionCache[rf.path]);
          processResQueue(idx + 1);
        };
        img.onerror = function() { processResQueue(idx + 1); };
        img.src = toFileURL(rf.path);
      } else {
        getVideoResolution(rf.path, function(res) {
          if (res) updateResBadge(rf.path, res);
          processResQueue(idx + 1);
        });
      }
    }

    function updateResBadge(filePath, res) {
      var el = document.querySelector('[data-filepath="' + CSS.escape(filePath) + '"] .res-badge');
      if (el) el.textContent = res;
    }

    // Pool paralelo de geracao de thumbs:
    // - Duas filas: visiveis (prioridade) e o resto
    // - Ate THUMB_CONCURRENCY ffmpegs simultaneos
    // - IntersectionObserver promove cards visiveis para a fila prioritaria
    state.thumbQueueVisible = [];
    state.thumbQueueRest = queue.slice();
    state._thumbTotal = queue.length;
    state._thumbDone = 0;
    pumpThumbPool();
    setupViewportObserver();
    processResQueue(0);
  }
}

// --- Worker pool de thumbs ---
var THUMB_CONCURRENCY = 2;
var thumbPoolActive = 0;

function pumpThumbPool() {
  if (!state.thumbQueueVisible) return;
  // Consome a fila respeitando a pausa de drag e o limite de concorrencia
  while (
    !thumbQueuePaused &&
    thumbPoolActive < THUMB_CONCURRENCY &&
    (state.thumbQueueVisible.length + state.thumbQueueRest.length > 0)
  ) {
    var f = state.thumbQueueVisible.length > 0
      ? state.thumbQueueVisible.shift()
      : state.thumbQueueRest.shift();
    if (!f) break;
    thumbPoolActive++;
    (function(file) {
      generateThumbFFmpeg(file.path, function(url) {
        thumbPoolActive--;
        state._thumbDone = (state._thumbDone || 0) + 1;
        if (url) {
          var el = document.querySelector('[data-filepath="' + CSS.escape(file.path) + '"] .thumbnail, [data-filepath="' + CSS.escape(file.path) + '"] .placeholder');
          if (el) {
            var img = document.createElement("img");
            img.className = "thumbnail";
            img.src = url;
            img.loading = "lazy";
            el.replaceWith(img);
          }
        }
        var statusEl = document.getElementById("statusText");
        var pending = state.thumbQueueVisible.length + state.thumbQueueRest.length + thumbPoolActive;
        if (statusEl) {
          statusEl.textContent = pending > 0
            ? "Gerando thumbs... " + state._thumbDone + "/" + state._thumbTotal
            : "Pronto";
        }
        pumpThumbPool();
      });
    })(f);
  }
  if (thumbQueuePaused && (state.thumbQueueVisible.length + state.thumbQueueRest.length > 0)) {
    var statusEl2 = document.getElementById("statusText");
    if (statusEl2) statusEl2.textContent = "Pausado (drag em andamento)";
  }
}

// IntersectionObserver: promove cards visiveis na viewport para a fila
// prioritaria, fazendo as primeiras telas se popularem antes do resto.
var _thumbIO = null;
function setupViewportObserver() {
  if (_thumbIO) { try { _thumbIO.disconnect(); } catch (e) {} _thumbIO = null; }
  if (typeof IntersectionObserver === "undefined") return;
  var grid = document.getElementById("grid");
  if (!grid) return;
  _thumbIO = new IntersectionObserver(function(entries) {
    var promoted = false;
    for (var i = 0; i < entries.length; i++) {
      if (!entries[i].isIntersecting) continue;
      var rel = entries[i].target.getAttribute("data-rel");
      if (!rel) continue;
      // Procura na fila do "resto" e move para a frente da fila visivel
      for (var j = 0; j < state.thumbQueueRest.length; j++) {
        if (toRelPath(state.thumbQueueRest[j].path) === rel) {
          state.thumbQueueVisible.unshift(state.thumbQueueRest.splice(j, 1)[0]);
          promoted = true;
          break;
        }
      }
    }
    if (promoted) pumpThumbPool();
  }, { root: grid, rootMargin: "200px" });
  var items = grid.querySelectorAll(".grid-item");
  for (var k = 0; k < items.length; k++) _thumbIO.observe(items[k]);
}

// --- Thumbnails (cached, no filesystem hit on re-render) ---
var thumbLookupCache = {};

function getThumbnail(file) {
  if (thumbLookupCache[file.path] !== undefined) return thumbLookupCache[file.path];
  try {
    var dir = path.dirname(file.path);
    var base = path.basename(file.path, path.extname(file.path));
    var thumbExts = [".png", ".jpg", ".jpeg", ".gif"];
    for (var i = 0; i < thumbExts.length; i++) {
      var thumbPath = path.join(dir, base + thumbExts[i]);
      if (fs.existsSync(thumbPath)) {
        var url = toFileURL(thumbPath);
        thumbLookupCache[file.path] = url;
        return url;
      }
      var thumbPath2 = path.join(dir, "thumbs", base + thumbExts[i]);
      if (fs.existsSync(thumbPath2)) {
        var url2 = toFileURL(thumbPath2);
        thumbLookupCache[file.path] = url2;
        return url2;
      }
    }
  } catch (e) {}
  thumbLookupCache[file.path] = null;
  return null;
}

// Converte um path absoluto para um path relativo a pasta de stock,
// normalizado para barra "/" para que Windows e Mac gerem a mesma chave
// para o mesmo arquivo logico (essencial em pastas compartilhadas via Drive).
// Se o path estiver fora da pasta de stock, retorna o proprio path absoluto.
function toRelPath(absPath) {
  if (!absPath) return absPath;
  try {
    var rel = path.relative(getStockFolder(), absPath);
    if (!rel || rel.indexOf("..") === 0) return absPath;
    return rel.split(path.sep).join("/");
  } catch (e) {
    return absPath;
  }
}

// --- Filtering ---
function getFilteredFiles() {
  return state.files.filter(function(f) {
    if (state.activeFormat !== "all" && f.type !== state.activeFormat) return false;
    if (state.activeCategory === "__favorites") {
      if (!state.favoriteFiles || !state.favoriteFiles[toRelPath(f.path)]) return false;
    } else if (state.activeCategory !== "all") {
      if (f.category !== state.activeCategory) {
        if (f.category && f.category.indexOf(state.activeCategory + "/") === 0) {
          // match — subcategoria do pai ativo
        } else {
          return false;
        }
      }
    }
    if (state.searchQuery) {
      return f.name.toLowerCase().indexOf(state.searchQuery.toLowerCase()) >= 0;
    }
    return true;
  });
}

// --- UI Actions ---
function setFormat(format, btn) {
  if (state.showSettings) toggleSettings();
  if (metricsState.visible) toggleMetrics();
  state.activeFormat = format;
  var tabs = document.querySelectorAll("#formatTabs .tab");
  for (var i = 0; i < tabs.length; i++) tabs[i].classList.remove("active");
  btn.classList.add("active");
  renderGrid();
}

function setCategory(catId) {
  state.activeCategory = catId;
  // Auto-expand parent when selecting it or a subcategory
  var cat = null;
  for (var i = 0; i < state.categories.length; i++) {
    if (state.categories[i].id === catId) { cat = state.categories[i]; break; }
  }
  if (cat && !cat.parent && !cat.system) {
    state.expandedCategories[catId] = true;
  } else if (cat && cat.parent) {
    state.expandedCategories[cat.parent] = true;
  }
  renderCategories();
  renderGrid();
}

var searchTimer = null;
function filterFiles() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(function() {
    state.searchQuery = document.getElementById("searchInput").value;
    renderGrid();
  }, 200);
}

function toggleSettings() {
  state.showSettings = !state.showSettings;
  var settingsPanel = document.getElementById("settingsPanel");
  var sidebar = document.getElementById("sidebar");
  var gridContainer = document.getElementById("gridContainer");
  var settingsBtn = document.getElementById("settingsBtn");
  var gridSlider = document.getElementById("gridSliderBar");

  if (state.showSettings) {
    if (metricsState.visible) toggleMetrics();
    settingsPanel.style.display = "flex";
    sidebar.style.display = "none";
    gridContainer.style.display = "none";
    if (gridSlider) gridSlider.style.display = "none";
    settingsBtn.style.color = "var(--accent)";
    var fp = document.getElementById("stockFolderPath");
    if (fp) fp.textContent = getStockFolder();
    var sfp = document.getElementById("stagingFolderPath");
    if (sfp) sfp.textContent = getStagingFolder();
    var ss = document.getElementById("stagingSize");
    if (ss) ss.textContent = getStagingSize();
    renderCatEditList();
  } else {
    settingsPanel.style.display = "none";
    sidebar.style.display = "flex";
    gridContainer.style.display = "block";
    if (gridSlider) gridSlider.style.display = "flex";
    settingsBtn.style.color = "";
  }
}

function saveSettings() {
  saveState();
  toggleSettings();
  refreshFiles();
}

function updateGridSize() {
  state.gridSize = parseInt(document.getElementById("gridSize").value);
  document.getElementById("fileGrid").style.gridTemplateColumns =
    "repeat(auto-fill, minmax(" + state.gridSize + "px, 1fr))";
  saveState();
}

// --- Categories ---
// --- Render ---
if (!state.expandedCategories) state.expandedCategories = {};

function getCatFileCount(catId, isSystem) {
  if (isSystem) return state.files.length;
  return state.files.filter(function(f) {
    return f.category === catId || (f.category && f.category.indexOf(catId + "/") === 0);
  }).length;
}

function toggleCategoryExpand(catId, e) {
  e.stopPropagation();
  state.expandedCategories[catId] = !state.expandedCategories[catId];
  renderCategories();
}

function renderCatItem(cat, isSub, childrenMap) {
  var children = childrenMap[cat.id] || [];
  var hasChildren = children.length > 0;
  var isExpanded = state.expandedCategories[cat.id];
  var count = isSub
    ? state.files.filter(function(f) { return f.category === cat.id; }).length
    : getCatFileCount(cat.id, cat.system);

  var arrow = '';
  if (hasChildren && !cat.system) {
    arrow = '<span class="cat-arrow ' + (isExpanded ? "expanded" : "") + '" ' +
      'onclick="toggleCategoryExpand(\'' + cat.id + '\', event)">' +
      '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
        '<polyline points="9 18 15 12 9 6"/>' +
      '</svg></span>';
  }

  var ctxMenu = cat.system ? '' : 'oncontextmenu="showCatContextMenu(event, \'' + cat.id + '\')"';

  var isActive = state.activeCategory === cat.id;
  var isParentActive = !isActive && typeof state.activeCategory === "string" &&
    state.activeCategory.indexOf(cat.id + "/") === 0;
  var stateClass = isActive ? "active" : (isParentActive ? "parent-active" : "");
  var html = '<div class="cat-item ' + (isSub ? "cat-sub " : "") + stateClass + '" ' +
    'onclick="setCategory(\'' + cat.id + '\')" ' +
    ctxMenu + ' ' +
    'ondragover="onCatDragOver(event)" ' +
    'ondragleave="onCatDragLeave(event)" ' +
    'ondrop="onCatDrop(event, \'' + cat.id + '\')">' +
    '<span style="display:flex;align-items:center;gap:6px;overflow:hidden;">' +
      arrow +
      '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + cat.name + '</span>' +
    '</span>' +
    '<span class="cat-count">' + count + '</span>' +
  '</div>';

  // Subcategories wrapped in a group container with vertical line
  if (hasChildren && isExpanded) {
    html += '<div class="cat-sub-group">';
    for (var c = 0; c < children.length; c++) {
      html += renderCatItem(children[c], true, childrenMap);
    }
    html += '</div>';
  }

  return html;
}

function getFavoriteCount() {
  if (!state.favoriteFiles) return 0;
  var count = 0;
  for (var i = 0; i < state.files.length; i++) {
    if (state.favoriteFiles[toRelPath(state.files[i].path)]) count++;
  }
  return count;
}

function renderCategories() {
  var list = document.getElementById("categoryList");
  var html = "";

  // Favorites (files) section — always on top
  var favCount = getFavoriteCount();
  html += '<div class="cat-item ' + (state.activeCategory === "__favorites" ? "active" : "") + '" ' +
    'onclick="setCategory(\'__favorites\')" ' +
    'ondragover="onCatDragOver(event)" ' +
    'ondragleave="onCatDragLeave(event)" ' +
    'ondrop="onFavoritesDrop(event)">' +
    '<span style="display:flex;align-items:center;gap:6px;overflow:hidden;">' +
      '<svg width="11" height="11" viewBox="0 0 24 24" fill="' + (state.activeCategory === "__favorites" ? "#e8a634" : "none") + '" stroke="#e8a634" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
        '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>' +
      '</svg>' +
      '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Favoritos</span>' +
    '</span>' +
    '<span class="cat-count">' + favCount + '</span>' +
  '</div>';

  html += '<div class="cat-divider"></div>';

  // Separate: system, parents, subcategories
  var systemCats = [];
  var normalCats = [];
  var childrenMap = {};

  for (var i = 0; i < state.categories.length; i++) {
    var cat = state.categories[i];
    if (cat.parent) {
      if (!childrenMap[cat.parent]) childrenMap[cat.parent] = [];
      childrenMap[cat.parent].push(cat);
    } else if (cat.system) {
      systemCats.push(cat);
    } else {
      normalCats.push(cat);
    }
  }

  // System categories (Todos)
  for (var s = 0; s < systemCats.length; s++) {
    html += renderCatItem(systemCats[s], false, childrenMap);
  }

  // Normal categories
  if (normalCats.length > 0) {
    html += '<div class="cat-divider"></div>';
    for (var n = 0; n < normalCats.length; n++) {
      html += renderCatItem(normalCats[n], false, childrenMap);
    }
  }

  list.innerHTML = html;
}

// --- Sidebar Resize ---
function initSidebarResize() {
  var handle = document.getElementById("sidebarResizeHandle");
  var sidebar = document.getElementById("sidebar");
  if (!handle || !sidebar) return;

  var dragging = false;
  var startX, startWidth;

  handle.addEventListener("mousedown", function(e) {
    e.preventDefault();
    dragging = true;
    startX = e.clientX;
    startWidth = sidebar.offsetWidth;
    handle.classList.add("dragging");
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
  });

  document.addEventListener("mousemove", function(e) {
    if (!dragging) return;
    var newWidth = startWidth + (e.clientX - startX);
    if (newWidth >= 100 && newWidth <= 280) {
      sidebar.style.width = newWidth + "px";
    }
  });

  document.addEventListener("mouseup", function() {
    if (!dragging) return;
    dragging = false;
    handle.classList.remove("dragging");
    document.body.style.cursor = "";
    document.body.style.userSelect = "";
    state.sidebarWidth = sidebar.offsetWidth;
    saveState();
  });
}

function renderGrid() {
  var grid = document.getElementById("fileGrid");
  var files = getFilteredFiles();

  // Cleanup any active preview
  cleanupPreview();

  document.getElementById("fileCount").textContent = files.length + " arquivos";

  if (files.length === 0) {
    grid.innerHTML = "";
    var container = document.getElementById("gridContainer");
    var emptyEl = container.querySelector(".empty-state");
    if (!emptyEl) {
      emptyEl = document.createElement("div");
      emptyEl.className = "empty-state";
      container.appendChild(emptyEl);
    }

    if (state.files.length === 0) {
      var folder = getStockFolder();
      emptyEl.innerHTML =
        '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round">' +
          '<path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>' +
        '</svg>' +
        '<h3>Nenhum arquivo encontrado</h3>' +
        '<p>Coloque seus stocks na pasta:</p>' +
        '<p style="color:var(--green);font-size:10px;word-break:break-all;">' + folder + '</p>' +
        '<button class="btn btn-primary" onclick="openStockFolder()">Abrir pasta</button>';
    } else {
      emptyEl.innerHTML =
        '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
          '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>' +
        '</svg>' +
        '<h3>Nenhum arquivo encontrado</h3>' +
        '<p>Tente ajustar os filtros ou busca.</p>';
    }
    emptyEl.style.display = "flex";
    return;
  }

  var emptyEl2 = document.getElementById("gridContainer").querySelector(".empty-state");
  if (emptyEl2) emptyEl2.style.display = "none";

  grid.style.gridTemplateColumns = "repeat(auto-fill, minmax(" + state.gridSize + "px, 1fr))";

  // Build index for fast lookup
  var fileIndexMap = {};
  for (var m = 0; m < state.files.length; m++) {
    fileIndexMap[state.files[m].path] = m;
  }

  grid.innerHTML = files.map(function(f) {
    var thumb = getThumbnail(f);
    var idx = fileIndexMap[f.path];
    var badgeClass = "badge-" + (f.type || "video");
    var res = resolutionCache[f.path] || "";

    // Determine thumbnail content - prefer cached images over <video> elements
    var thumbContent;
    if (thumb) {
      thumbContent = '<img class="thumbnail" src="' + thumb + '" loading="lazy" />';
    } else if (f.type === "video" && thumbCache[f.path]) {
      thumbContent = '<img class="thumbnail" src="' + thumbCache[f.path] + '" loading="lazy" />';
    } else if (f.type === "image") {
      thumbContent = '<img class="thumbnail" src="' + toFileURL(f.path) + '" loading="lazy" />';
    } else {
      // Lightweight placeholder - NO <video> elements in grid
      var iconSvg;
      if (f.type === "audio") {
        iconSvg = '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>';
      } else {
        iconSvg = '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>';
      }
      thumbContent = '<div class="placeholder">' +
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
              iconSvg +
            '</svg>' +
            '<span style="font-size:9px;">' + f.ext.toUpperCase() + '</span>' +
          '</div>';
    }

    var cloudBadge = f.cloudOnly
      ? '<span class="cloud-badge" title="Arquivo na nuvem (nao baixado)">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M18 10h-1.26A8 8 0 109 20h9a5 5 0 000-10z"/>' +
          '</svg>' +
        '</span>'
      : '';

    return '<div class="grid-item' + (f.cloudOnly ? ' cloud-only' : '') + '" ' +
      'data-filepath="' + f.path.replace(/"/g, '&quot;') + '" ' +
      'data-rel="' + toRelPath(f.path).replace(/"/g, '&quot;') + '" ' +
      'draggable="true" ' +
      'ondragstart="onFileDragStart(event, ' + idx + ')" ' +
      'ondragend="onFileDragEnd(event, ' + idx + ')" ' +
      'ondblclick="onDoubleClick(' + idx + ')" ' +
      'oncontextmenu="showContextMenu(event, ' + idx + ')" ' +
      'onmouseenter="onMouseEnter(this, ' + idx + ')" ' +
      'onmouseleave="onMouseLeave(this)" ' +
      'title="' + f.name + (f.cloudOnly ? " (na nuvem)" : "") + '">' +
      thumbContent +
      cloudBadge +
      '<span class="file-badge ' + badgeClass + '">' + f.ext + '</span>' +
      '<span class="res-badge">' + res + '</span>' +
      '<button class="import-btn" onclick="event.stopPropagation(); importToProject(' + idx + ')" title="Importar no projeto">' +
        '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
          '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>' +
        '</svg>' +
      '</button>' +
      '<span class="file-name">' + f.name.replace(/\.[^.]+$/, "") + '</span>' +
    '</div>';
  }).join("");

  // Reconfigura o IntersectionObserver apos cada render para que cards
  // visiveis sejam priorizados na fila de geracao de thumbs
  if (typeof setupViewportObserver === "function") setupViewportObserver();
}

function renderAll() {
  renderCategories();
  renderGrid();
}

// --- Toast ---
function showToast(msg) {
  var existing = document.querySelector(".toast");
  if (existing) existing.remove();
  var toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(function() { toast.remove(); }, 3000);
}

// --- User ID Setup ---
// --- Init ---
function init() {
  try {
    loadState();
    document.getElementById("gridSize").value = state.gridSize;
    ensureStockFolder();

    // Version label no footer
    var vl = document.getElementById("versionLabel");
    if (vl) vl.textContent = "v" + APP_VERSION;

    // FFmpeg — inicializa modulo (antes de findFFmpeg)
    FFmpegManager.init({
      getStockFolder: getStockFolder,
      toRelPath: toRelPath,
      toFileURL: toFileURL
    });

    var ff = findFFmpeg();
    if (ff) {
      console.log("StockHub: FFmpeg found at " + ff);
    } else {
      console.log("StockHub: FFmpeg not found. MOV previews disabled.");
    }

    // Modais — inicializa modulo
    ModalManager.init(state, {
      saveState: saveState,
      showToast: showToast
    });
    ModalManager.loadChangelog();

    // Restore sidebar width
    if (state.sidebarWidth) {
      var sb = document.getElementById("sidebar");
      if (sb) sb.style.width = state.sidebarWidth + "px";
    }
    initSidebarResize();

    refreshFiles();

    // Show userId modal if not set
    if (!state.userId) {
      showUserIdModal();
    }

    // Welcome modal (primeira execucao)
    if (!state.welcomed) {
      showWelcomeModal(0);
    }

    // What's new modal (apos update)
    if (state.lastSeenVersion && _compareSemver(APP_VERSION, state.lastSeenVersion) > 0) {
      showWhatsNewModal();
    } else if (!state.lastSeenVersion) {
      state.lastSeenVersion = APP_VERSION;
      saveState();
    }

    // Categorias — inicializa modulo
    CategoryManager.init(state, {
      saveState: saveState,
      showToast: showToast,
      toRelPath: toRelPath,
      renderCategories: renderCategories,
      renderGrid: renderGrid,
      renderAll: renderAll
    });

    // Drag — inicializa modulo
    DragManager.init(state, {
      saveState: saveState,
      showToast: showToast,
      toRelPath: toRelPath,
      toFileURL: toFileURL,
      stageFileIfNeeded: stageFileIfNeeded,
      getStagedPathIfExists: getStagedPathIfExists,
      cs: cs,
      trackEvent: trackEvent,
      pumpThumbPool: pumpThumbPool,
      renderAll: renderAll
    });

    // Preview — inicializa modulo
    PreviewManager.init(state, {
      toFileURL: toFileURL,
      stageFileIfNeeded: stageFileIfNeeded
    });

    // Metricas — inicializa modulo
    MetricsManager.init(state, {
      getStockFolder: getStockFolder,
      showToast: showToast,
      toggleSettings: toggleSettings,
      cs: cs
    });

    // Auto-update — verificação imediata + intervalo de 2h
    UpdateManager.init(state, saveState);
    UpdateManager.check();
    UpdateManager.schedulePeriodicCheck();

    // Dev hot reload: Ctrl+Shift+R recarrega o painel
    document.addEventListener("keydown", function(e) {
      if (e.ctrlKey && e.shiftKey && e.key === "R") {
        e.preventDefault();
        location.reload();
      }
    });
  } catch (e) {
    alert("StockHub init error: " + e.toString());
  }
}

init();
