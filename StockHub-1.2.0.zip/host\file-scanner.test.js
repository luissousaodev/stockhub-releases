// file-scanner.test.js — Testes para features/file-scanner.js (funcoes puras)
// Roda em Node.js puro, sem dependencias de browser

var assert = require("assert");
var mod = require("../client/features/file-scanner.js");
var snapshotsDiffer = mod.snapshotsDiffer;

var passed = 0;
var failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log("  PASS: " + name);
  } catch (e) {
    failed++;
    console.error("  FAIL: " + name + " — " + e.message);
  }
}

console.log("\n=== file-scanner tests ===\n");

// --- snapshotsDiffer ---

test("snapshotsDiffer: snapshots identicos retorna false", function() {
  var a = { "a.mp4": { m: 100, s: 200 }, "b.wav": { m: 300, s: 400 } };
  var b = { "a.mp4": { m: 100, s: 200 }, "b.wav": { m: 300, s: 400 } };
  assert.strictEqual(snapshotsDiffer(a, b), false);
});

test("snapshotsDiffer: mtime diferente retorna true", function() {
  var a = { "a.mp4": { m: 100, s: 200 } };
  var b = { "a.mp4": { m: 999, s: 200 } };
  assert.strictEqual(snapshotsDiffer(a, b), true);
});

test("snapshotsDiffer: size diferente retorna true", function() {
  var a = { "a.mp4": { m: 100, s: 200 } };
  var b = { "a.mp4": { m: 100, s: 999 } };
  assert.strictEqual(snapshotsDiffer(a, b), true);
});

test("snapshotsDiffer: arquivo adicionado retorna true", function() {
  var a = { "a.mp4": { m: 100, s: 200 } };
  var b = { "a.mp4": { m: 100, s: 200 }, "b.mp4": { m: 300, s: 400 } };
  assert.strictEqual(snapshotsDiffer(a, b), true);
});

test("snapshotsDiffer: arquivo removido retorna true", function() {
  var a = { "a.mp4": { m: 100, s: 200 }, "b.mp4": { m: 300, s: 400 } };
  var b = { "a.mp4": { m: 100, s: 200 } };
  assert.strictEqual(snapshotsDiffer(a, b), true);
});

test("snapshotsDiffer: ambos vazios retorna false", function() {
  assert.strictEqual(snapshotsDiffer({}, {}), false);
});

test("snapshotsDiffer: null vs objeto retorna true", function() {
  assert.strictEqual(snapshotsDiffer(null, {}), true);
});

test("snapshotsDiffer: objeto vs null retorna true", function() {
  assert.strictEqual(snapshotsDiffer({}, null), true);
});

test("snapshotsDiffer: ambos null retorna true", function() {
  assert.strictEqual(snapshotsDiffer(null, null), true);
});

test("snapshotsDiffer: arquivo renomeado detecta diferenca", function() {
  var a = { "old.mp4": { m: 100, s: 200 } };
  var b = { "new.mp4": { m: 100, s: 200 } };
  assert.strictEqual(snapshotsDiffer(a, b), true);
});

// --- Resumo ---

console.log("\nTotal: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
if (failed > 0) process.exit(1);
