// =============================================================================
// features/folder-manager.js — Gestao da pasta de stocks
// =============================================================================

function getDefaultStockFolder() {
  var home = process.env.HOME || process.env.USERPROFILE || "";
  return path.join(home, "StockHub");
}

function getStockFolder() {
  return state.customFolder || getDefaultStockFolder();
}

function ensureStockFolder() {
  try {
    var folder = getStockFolder();
    if (!fs.existsSync(folder)) {
      fs.mkdirSync(folder, { recursive: true });
      ["Videos", "Imagens", "Audio", "Transicoes", "MOGRT"].forEach(function(sub) {
        fs.mkdirSync(path.join(folder, sub), { recursive: true });
      });
    }
    return folder;
  } catch (e) {
    alert("Erro ao criar pasta StockHub: " + e.toString());
    return null;
  }
}

function openStockFolder() {
  try {
    var folder = getStockFolder().replace(/\\/g, "/");
    cs.evalScript('new Folder("' + folder + '").execute()');
  } catch (e) { Logger.warn("folder", "Falha ao abrir pasta", e.message); }
}

function changeStockFolder() {
  if (isWindows) {
    var psFile = path.join(os.tmpdir(), "stockhub_folder_picker.ps1");
    var psContent = [
      'Add-Type -AssemblyName System.Windows.Forms',
      '',
      '$source = @"',
      'using System;',
      'using System.Runtime.InteropServices;',
      'using System.Windows.Forms;',
      '',
      '[ComImport, Guid("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7")]',
      'class FileOpenDialogRCW {}',
      '',
      '[ComImport, Guid("d57c7288-d4ad-4768-be02-9d969532d960"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]',
      'interface IFileOpenDialog {',
      '    [PreserveSig] int Show(IntPtr hwndOwner);',
      '    void SetFileTypes(); void SetFileTypeIndex(); void GetFileTypeIndex();',
      '    void Advise(); void Unadvise();',
      '    void SetOptions(uint fos); void GetOptions(out uint pfos);',
      '    void SetDefaultFolder(IShellItem psi); void SetFolder(IShellItem psi);',
      '    void GetFolder(out IShellItem ppsi); void GetCurrentSelection(out IShellItem ppsi);',
      '    void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string pszName);',
      '    void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string pszName);',
      '    void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string pszTitle);',
      '    void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string pszText);',
      '    void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string pszLabel);',
      '    void GetResult(out IShellItem ppsi);',
      '    void AddPlace(IShellItem psi, int alignment);',
      '    void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string pszDefaultExtension);',
      '    void Close(int hr); void SetClientGuid(ref Guid guid);',
      '    void ClearClientData(); void SetFilter(IntPtr pFilter);',
      '}',
      '',
      '[ComImport, Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]',
      'interface IShellItem {',
      '    void BindToHandler(); void GetParent();',
      '    [PreserveSig] int GetDisplayName(uint sigdnName, [MarshalAs(UnmanagedType.LPWStr)] out string ppszName);',
      '    void GetAttributes(); void Compare();',
      '}',
      '',
      'public class FolderPicker {',
      '    public static string Show(IntPtr hwnd) {',
      '        var dlg = (IFileOpenDialog)new FileOpenDialogRCW();',
      '        dlg.SetTitle("Selecionar pasta de assets");',
      '        dlg.SetOkButtonLabel("Selecionar pasta");',
      '        uint opts; dlg.GetOptions(out opts);',
      '        dlg.SetOptions(opts | 0x20);',
      '        if (dlg.Show(hwnd) != 0) return "";',
      '        IShellItem item; dlg.GetResult(out item);',
      '        string path; item.GetDisplayName(0x80058000, out path);',
      '        return path;',
      '    }',
      '}',
      '"@',
      '',
      'Add-Type -TypeDefinition $source -ReferencedAssemblies System.Windows.Forms',
      '',
      '$form = New-Object System.Windows.Forms.Form',
      '$form.TopMost = $true',
      '$form.Width = 0',
      '$form.Height = 0',
      '$form.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual',
      '$form.Location = New-Object System.Drawing.Point(-1000,-1000)',
      '$form.Show()',
      '$result = [FolderPicker]::Show($form.Handle)',
      '$form.Close()',
      'if ($result) { $result }',
    ].join("\n");
    fs.writeFileSync(psFile, psContent, "utf-8");
    child.exec('powershell -ExecutionPolicy Bypass -File "' + psFile + '"', function(err, stdout) {
      try { fs.unlinkSync(psFile); } catch(e) { Logger.warn("folder", "Falha ao remover ps1 temp", e.message); }
      var result = stdout ? stdout.trim() : "";
      if (!err && result) {
        showAutoCategoryModal(result);
      }
    });
  } else {
    var appleScript = "osascript -e 'tell application \"System Events\"' -e 'activate' -e 'set folderPath to POSIX path of (choose folder with prompt \"Selecionar pasta de assets\")' -e 'end tell'";
    child.exec(appleScript, function(err, stdout) {
      var result = stdout ? stdout.trim() : "";
      if (!err && result) {
        showAutoCategoryModal(result);
      }
    });
  }
}

function showAutoCategoryModal(folderPath) {
  var container = document.getElementById("modalContainer");
  container.innerHTML =
    '<div class="modal-overlay" onclick="closeModal(event)">' +
      '<div class="modal" onclick="event.stopPropagation()">' +
        '<h3>Criar categorias automaticamente?</h3>' +
        '<p style="font-size:11px;color:var(--text-secondary);margin:8px 0 12px;">Subpastas encontradas serao adicionadas como categorias no painel lateral.</p>' +
        '<div class="modal-actions">' +
          '<button class="btn" onclick="applyFolderChange(\'' + folderPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + '\', false)">Nao criar</button>' +
          '<button class="btn btn-primary" onclick="applyFolderChange(\'' + folderPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + '\', true)">Criar categorias</button>' +
        '</div>' +
      '</div>' +
    '</div>';
}

function applyFolderChange(folderPath, autoCategories) {
  closeModal();
  if (state.showSettings) toggleSettings();
  if (metricsState.visible) toggleMetrics();
  state.customFolder = folderPath;
  state.autoCategories = autoCategories;
  state.categories = state.categories.filter(function(c) { return c.system; });
  state.fileCategories = {};
  state.deletedCategoryIds = [];
  state.activeCategory = "all";
  saveState();
  ensureStockFolder();
  thumbLookupCache = {};
  FFmpegManager.clearCaches();
  refreshFiles();
  showToast("Pasta alterada: " + folderPath);
}

function _doResetStockFolder() {
  if (state.showSettings) toggleSettings();
  if (metricsState.visible) toggleMetrics();
  state.customFolder = null;
  state.categories = state.categories.filter(function(c) { return c.system; });
  state.fileCategories = {};
  state.deletedCategoryIds = [];
  state.activeCategory = "all";
  saveState();
  ensureStockFolder();
  thumbLookupCache = {};
  FFmpegManager.clearCaches();
  refreshFiles();
  showToast("Pasta restaurada para padrao: " + getDefaultStockFolder());
}

function resetStockFolder() {
  if (!state.customFolder) {
    showToast("Ja esta usando a pasta padrao");
    return;
  }
  showConfirmModal({
    title: "Restaurar pasta padrao?",
    message: "Voltamos para <b>" + getDefaultStockFolder() + "</b> e suas categorias customizadas serao removidas. " +
             "Os arquivos da sua pasta atual nao sao apagados.",
    confirmLabel: "Restaurar",
    cancelLabel: "Cancelar",
    danger: true,
    onConfirm: _doResetStockFolder
  });
}
