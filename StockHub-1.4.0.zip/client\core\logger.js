// =============================================================================
// core/logger.js — Logging estruturado do StockHub
// =============================================================================

var Logger = (function() {
  var _logs = [];
  var MAX_MEMORY = 500;

  function _entry(level, mod, msg, data) {
    var entry = {
      t: new Date().toISOString(),
      l: level,
      m: mod,
      msg: msg
    };
    if (data !== undefined) entry.d = data;
    _logs.push(entry);
    if (_logs.length > MAX_MEMORY) _logs.shift();

    var prefix = "[" + level + "][" + mod + "]";
    if (level === "error") console.error(prefix, msg, data || "");
    else if (level === "warn") console.warn(prefix, msg, data || "");
    else console.log(prefix, msg, data || "");
  }

  return {
    info:  function(mod, msg, d) { _entry("info", mod, msg, d); },
    warn:  function(mod, msg, d) { _entry("warn", mod, msg, d); },
    error: function(mod, msg, d) { _entry("error", mod, msg, d); },
    dump:  function() { return _logs.slice(); },
    clear: function() { _logs.length = 0; }
  };
})();

if (typeof module !== "undefined") {
  module.exports = { Logger: Logger };
}
