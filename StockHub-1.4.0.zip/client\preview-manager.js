// =============================================================================
// preview-manager.js — Modulo de preview de video/audio do StockHub
//
// Responsabilidades:
//   - Hover preview de video com scrubbing
//   - Hover preview de audio com indicador animado
//   - Geracao de proxy via FFmpeg para formatos pesados
//   - Cleanup de previews ativos
//
// Dependencias externas (recebidas via init):
//   - state, toFileURL, stageFileIfNeeded
//   - FFmpegManager (proxyCache, findFFmpeg, generateProxyFFmpeg, killActiveProxyProc)
// =============================================================================

// IIFE — encapsula estado privado (so roda no browser)
if (typeof window !== "undefined") (function() {

  // Dependencias injetadas via init()
  var _state            = null;
  var _toFileURL        = null;
  var _stageFileIfNeeded = null;

  // Estado interno
  var activePreview = null;
  var hoverTimer = null;

  // -------------------------------------------------------------------------
  // Preview handlers
  // -------------------------------------------------------------------------

  function onMouseEnter(el, fileIndex) {
    if (_state.previewHoverEnabled === false) return;
    var file = _state.files[fileIndex];
    if (!file || (file.type !== "video" && file.type !== "audio")) return;
    if (file.cloudOnly) {
      // Pre-stage async em background — quando user clicar pra importar,
      // ja vai estar pronto no cache. Sem trava de UI.
      setTimeout(function() {
        if (typeof window.stageFileAsync === "function") window.stageFileAsync(file, function() {});
        else _stageFileIfNeeded(file);
      }, 0);
      return;
    }

    clearTimeout(hoverTimer);
    hoverTimer = setTimeout(function() {
      if (!el.matches(":hover")) return;

      if (file.type === "audio") {
        createPreviewAudio(el, _toFileURL(file.path));
        return;
      }

      var ext = file.ext.toLowerCase();
      var needsProxy = (ext === "mov" || ext === "mxf" || ext === "avi" || ext === "mkv");

      if (needsProxy) {
        if (FFmpegManager.proxyCache[file.path]) {
          createPreviewVideo(el, FFmpegManager.proxyCache[file.path]);
        } else if (FFmpegManager.findFFmpeg()) {
          FFmpegManager.generateProxyFFmpeg(file.path, function(proxyUrl) {
            if (proxyUrl && el.matches(":hover")) {
              createPreviewVideo(el, proxyUrl);
            }
          });
        }
      } else {
        createPreviewVideo(el, _toFileURL(file.path));
      }
    }, 150);
  }

  function createPreviewVideo(el, src) {
    cleanupPreview();
    // Insere o video DENTRO do .grid-item-thumb (que tem position relative
    // e o aspect-ratio do thumb). Sem isso, o video flui no .grid-item
    // (flex-column) e empurra a meta-line + nome para baixo.
    var thumb = el.querySelector(".grid-item-thumb") || el;
    var video = document.createElement("video");
    video.className = "video-preview";
    video.style.opacity = "0";
    video.preload = "auto";
    video.muted = true;
    video.playsInline = true;
    video.onerror = function() { video.remove(); activePreview = null; };
    thumb.appendChild(video);

    var bar = document.createElement("div");
    bar.className = "scrub-bar";
    var fill = document.createElement("div");
    fill.className = "scrub-bar-fill";
    bar.appendChild(fill);
    thumb.appendChild(bar);

    activePreview = { el: el, thumb: thumb, video: video, bar: bar, fill: fill, onMove: null };

    function onMove(ev) {
      if (!video.duration || isNaN(video.duration)) return;
      var rect = thumb.getBoundingClientRect();
      var x = ev.clientX - rect.left;
      var ratio = Math.max(0, Math.min(1, x / rect.width));
      try { video.currentTime = ratio * video.duration; } catch (e) { Logger.warn("preview", "seek failed", e.message); }
      fill.style.width = (ratio * 100) + "%";
    }
    activePreview.onMove = onMove;

    video.onloadedmetadata = function() {
      video.onloadedmetadata = null;
      if (!el.matches(":hover")) { cleanupPreview(); return; }
      video.style.opacity = "1";
      thumb.addEventListener("mousemove", onMove);
      try { video.currentTime = video.duration / 2; } catch (e) { Logger.warn("preview", "initial seek failed", e.message); }
      fill.style.width = "50%";
    };

    video.src = src;
  }

  function createPreviewAudio(el, src) {
    cleanupPreview();
    var thumb = el.querySelector(".grid-item-thumb") || el;
    var audio = document.createElement("audio");
    audio.preload = "auto";
    audio.loop = true;
    audio.onerror = function() { audio.remove(); activePreview = null; };
    activePreview = { el: el, thumb: thumb, audio: audio };

    var indicator = document.createElement("div");
    indicator.className = "audio-playing-indicator";
    indicator.innerHTML =
      '<div class="audio-bar"></div>' +
      '<div class="audio-bar"></div>' +
      '<div class="audio-bar"></div>' +
      '<div class="audio-bar"></div>';
    thumb.appendChild(indicator);
    activePreview.indicator = indicator;

    audio.oncanplay = function() {
      audio.oncanplay = null;
      if (!el.matches(":hover")) { cleanupPreview(); return; }
      audio.play().catch(function() {});
    };
    audio.src = src;
  }

  function onMouseLeave(el) {
    clearTimeout(hoverTimer);
    cleanupPreview();
    FFmpegManager.killActiveProxyProc();
  }

  function cleanupPreview() {
    if (activePreview) {
      var media = activePreview.video || activePreview.audio;
      media.pause();
      media.removeAttribute("src");
      media.load();
      media.remove();
      if (activePreview.indicator) activePreview.indicator.remove();
      if (activePreview.bar) activePreview.bar.remove();
      if (activePreview.onMove) {
        var moveTarget = activePreview.thumb || activePreview.el;
        if (moveTarget) moveTarget.removeEventListener("mousemove", activePreview.onMove);
      }
      activePreview = null;
    }
  }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.PreviewManager = {
    init: function(stateRef, deps) {
      _state             = stateRef;
      _toFileURL         = deps.toFileURL;
      _stageFileIfNeeded = deps.stageFileIfNeeded;
    },
    onMouseEnter:   onMouseEnter,
    onMouseLeave:   onMouseLeave,
    cleanupPreview: cleanupPreview
  };

  // Aliases globais para inline event attrs no renderGrid
  window.onMouseEnter   = onMouseEnter;
  window.onMouseLeave   = onMouseLeave;
  window.cleanupPreview = cleanupPreview;

})();
