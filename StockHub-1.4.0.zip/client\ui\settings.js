// =============================================================================
// ui/settings.js — Acoes de UI: filtros, settings panel, grid size
// =============================================================================

function setFormat(format, btn) {
  if (state.showSettings) toggleSettings();
  if (metricsState.visible) toggleMetrics();
  state.selectedFiles = {};
  state.activeFormat = format;

  // Atualiza estado visual do dropdown
  var items = document.querySelectorAll("#formatDropdownMenu .dropdown-item[data-format]");
  var label = "TODOS";
  for (var i = 0; i < items.length; i++) {
    var it = items[i];
    var isActive = it.getAttribute("data-format") === format;
    it.classList.toggle("active", isActive);
    if (isActive) label = (it.querySelector("span") ? it.querySelector("span").textContent : format).toUpperCase();
  }
  var lblEl = document.getElementById("formatDropdownLabel");
  if (lblEl) lblEl.textContent = label;

  // Suporta chamada legacy (sem btn) e nova (botão clicado é o btn)
  if (btn && btn.classList) btn.classList.add("active");

  renderGrid();
}

function setCategory(catId) {
  state.selectedFiles = {};
  state.activeCategory = catId;
  var cat = null;
  for (var i = 0; i < state.categories.length; i++) {
    if (state.categories[i].id === catId) { cat = state.categories[i]; break; }
  }
  if (cat && !cat.parent && !cat.system) {
    state.expandedCategories[catId] = true;
  } else if (cat && cat.parent) {
    state.expandedCategories[cat.parent] = true;
  }
  renderCategories();
  renderGrid();
}

var searchTimer = null;
function filterFiles() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(function() {
    state.selectedFiles = {};
    state.searchQuery = document.getElementById("searchInput").value;
    renderGrid();
  }, 200);
}

function _renderSettingsModalHTML() {
  var preview = state.previewHoverEnabled !== false;
  return '' +
    '<div class="modal-overlay" onclick="closeSettingsModal(event)">' +
      '<div class="modal modal-settings" onclick="event.stopPropagation()">' +
        '<div class="modal-header">' +
          '<div class="modal-header-title">' +
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
              '<circle cx="12" cy="12" r="3"/>' +
              '<path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/>' +
            '</svg>' +
            'Configurações' +
          '</div>' +
          '<button class="modal-close-btn" onclick="closeSettingsModal()" aria-label="Fechar">' +
            '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
              '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>' +
            '</svg>' +
          '</button>' +
        '</div>' +
        '<div class="modal-body">' +
          '<div class="settings-columns">' +
            // Pasta
            '<div class="settings-section settings-col">' +
              '<div class="settings-section-title">' +
                '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                  '<path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>' +
                '</svg>Pasta de Assets' +
              '</div>' +
              '<div class="settings-card" style="flex:1;">' +
                '<div id="stockFolderPath" class="folder-path-display"></div>' +
                '<div class="settings-row" style="gap:6px;">' +
                  '<button class="btn" id="changeStockFolderBtn" style="flex:1;">' +
                    '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                      '<path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>' +
                      '<path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>' +
                    '</svg>Alterar pasta' +
                  '</button>' +
                  '<button class="btn" id="openStockFolderBtn" style="flex:1;">' +
                    '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                      '<path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>' +
                      '<polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>' +
                    '</svg>Abrir no Explorer' +
                  '</button>' +
                '</div>' +
                '<button class="btn" id="resetStockFolderBtn" style="width:100%;margin-top:4px;">' +
                  '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                    '<polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/>' +
                  '</svg>Restaurar pasta padrao' +
                '</button>' +
                '<p class="settings-hint">Subpastas viram categorias automaticamente.</p>' +
              '</div>' +
            '</div>' +

            // Staging
            '<div class="settings-section settings-col">' +
              '<div class="settings-section-title">' +
                '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                  '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>' +
                '</svg>Staging Local' +
              '</div>' +
              '<div class="settings-card" style="flex:1;">' +
                '<div id="stagingFolderPath" class="folder-path-display"></div>' +
                '<button class="btn" id="changeStagingBtn" style="width:100%;">' +
                  '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                    '<path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>' +
                    '<path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>' +
                  '</svg>Alterar pasta de staging' +
                '</button>' +
                '<button class="btn" id="clearStagingBtn" style="width:100%;margin-top:4px;">' +
                  '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                    '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>' +
                  '</svg>Limpar staging (<span id="stagingSize">0 KB</span>)' +
                '</button>' +
                '<p class="settings-hint">Assets da nuvem sao copiados aqui antes de importar no Premiere.</p>' +
              '</div>' +
            '</div>' +
          '</div>' +

          '<div class="settings-columns" style="margin-top:14px;">' +
            // Preferencias
            '<div class="settings-section settings-col">' +
              '<div class="settings-section-title">' +
                '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                  '<circle cx="12" cy="12" r="3"/><path d="M12 1v6m0 10v6"/>' +
                '</svg>Preferências' +
              '</div>' +
              '<div class="settings-card" style="flex:1;">' +
                '<label class="settings-toggle">' +
                  '<span>' +
                    '<span class="settings-toggle-label">Preview ao passar o mouse</span>' +
                    '<span class="settings-toggle-hint">Reproduz video em loop quando voce passa o mouse no asset</span>' +
                  '</span>' +
                  '<input type="checkbox" id="previewHoverToggle"' + (preview ? ' checked' : '') + ' onchange="togglePreviewHover()" />' +
                  '<span class="settings-toggle-track"><span class="settings-toggle-thumb"></span></span>' +
                '</label>' +
              '</div>' +
            '</div>' +

            // Cache
            '<div class="settings-section settings-col">' +
              '<div class="settings-section-title">' +
                '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                  '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0018 0V5"/><path d="M3 12a9 3 0 0018 0"/>' +
                '</svg>Cache local' +
              '</div>' +
              '<div class="settings-card" style="flex:1;">' +
                '<div class="folder-path-display" id="cacheSizeDisplay">—</div>' +
                '<button class="btn" id="clearCacheBtn" onclick="clearCacheFolder()" style="width:100%;">' +
                  '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                    '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6"/>' +
                  '</svg>Limpar cache de thumbs/proxies' +
                '</button>' +
                '<p class="settings-hint">Thumbnails e previews sao regenerados sob demanda.</p>' +
              '</div>' +
            '</div>' +
          '</div>' +

          // Sobre
          '<div class="settings-section" style="margin-top:14px;">' +
            '<div class="settings-section-title">' +
              '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>' +
              '</svg>Sobre & Ajuda' +
            '</div>' +
            '<div class="settings-card">' +
              '<div class="settings-row" style="gap:6px;">' +
                '<button class="btn" onclick="closeSettingsModal();showVersionModal()" style="flex:1;">Sobre</button>' +
                '<button class="btn" onclick="closeSettingsModal();showChangelogModal()" style="flex:1;">Changelog</button>' +
                '<button class="btn" onclick="closeSettingsModal();showShortcutsModal()" style="flex:1;">Atalhos</button>' +
              '</div>' +
              '<p class="settings-hint">v<span id="settingsVersion"></span> — desenvolvido por Luis Sousa</p>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div class="modal-actions" style="margin-top:14px;">' +
          '<button class="btn btn-primary" onclick="saveSettings()" style="width:100%;justify-content:center;padding:8px;">' +
            '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
              '<polyline points="20 6 9 17 4 12"/>' +
            '</svg>Salvar e fechar' +
          '</button>' +
        '</div>' +
      '</div>' +
    '</div>';
}

function toggleSettings() {
  if (state.showSettings) {
    closeSettingsModal();
    return;
  }
  if (metricsState.visible) toggleMetrics();
  state.showSettings = true;

  var btn = document.getElementById("settingsBtn");
  if (btn) btn.classList.add("active");

  document.getElementById("modalContainer").innerHTML = _renderSettingsModalHTML();

  // Preencher campos dinamicos depois que o DOM existe
  var fp = document.getElementById("stockFolderPath");
  if (fp) fp.textContent = getStockFolder();
  var sfp = document.getElementById("stagingFolderPath");
  if (sfp) sfp.textContent = getStagingFolder();
  var ss = document.getElementById("stagingSize");
  if (ss) ss.textContent = getStagingSize();
  var cacheEl = document.getElementById("cacheSizeDisplay");
  if (cacheEl) cacheEl.textContent = getCacheSize();
  var verEl = document.getElementById("settingsVersion");
  if (verEl) verEl.textContent = APP_VERSION;

  // Wire dos botoes que tinham listeners no app.js (recriados a cada abertura)
  var bChange = document.getElementById("changeStockFolderBtn");
  if (bChange) bChange.onclick = function() { changeStockFolder(); };
  var bOpen = document.getElementById("openStockFolderBtn");
  if (bOpen) bOpen.onclick = function() { openStockFolder(); };
  var bReset = document.getElementById("resetStockFolderBtn");
  if (bReset) bReset.onclick = function() { resetStockFolder(); };
  var bStaging = document.getElementById("changeStagingBtn");
  if (bStaging) bStaging.onclick = function() { changeStagingFolder(); };
  var bClearStaging = document.getElementById("clearStagingBtn");
  if (bClearStaging) bClearStaging.onclick = function() { clearStagingFolder(); };
}

function closeSettingsModal(e) {
  if (e && e.target !== e.currentTarget) return;
  state.showSettings = false;
  var btn = document.getElementById("settingsBtn");
  if (btn) btn.classList.remove("active");
  document.getElementById("modalContainer").innerHTML = "";
}

// Tamanho total do .cache (thumbs + proxies)
function getCacheSize() {
  if (typeof FFmpegManager === "undefined" || !FFmpegManager.getCacheDir) return "—";
  var dir = FFmpegManager.getCacheDir();
  if (!fs.existsSync(dir)) return "0 KB";
  var total = 0;
  try {
    var items = fs.readdirSync(dir);
    for (var i = 0; i < items.length; i++) {
      try {
        var st = fs.statSync(path.join(dir, items[i]));
        if (st.isFile()) total += st.size;
      } catch (e) { /* arquivo inacessivel */ }
    }
  } catch (e) { return "—"; }
  if (total < 1024 * 1024) return (total / 1024).toFixed(1) + " KB";
  if (total < 1024 * 1024 * 1024) return (total / (1024 * 1024)).toFixed(1) + " MB";
  return (total / (1024 * 1024 * 1024)).toFixed(1) + " GB";
}

function _doClearCache() {
  if (typeof FFmpegManager === "undefined" || !FFmpegManager.getCacheDir) return;
  var dir = FFmpegManager.getCacheDir();
  try {
    fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true });
    FFmpegManager.clearCaches();
    thumbLookupCache = {};
    var el = document.getElementById("cacheSizeDisplay");
    if (el) el.textContent = "0 KB";
    showToast("Cache limpo");
    refreshFiles();
  } catch (e) {
    showToast("Erro ao limpar cache: " + e.message);
  }
}

function clearCacheFolder() {
  var size = getCacheSize();
  if (size === "0 KB" || size === "—") {
    showToast("Cache ja esta vazio");
    return;
  }
  showConfirmModal({
    title: "Limpar cache?",
    message: "Vamos remover <b>" + size + "</b> em thumbs e proxies de preview. " +
             "Eles serao regerados conforme voce reabrir os arquivos.",
    confirmLabel: "Limpar",
    cancelLabel: "Cancelar",
    danger: true,
    onConfirm: _doClearCache
  });
}

function togglePreviewHover() {
  var toggle = document.getElementById("previewHoverToggle");
  state.previewHoverEnabled = toggle ? toggle.checked : !state.previewHoverEnabled;
  saveState();
  showToast(state.previewHoverEnabled ? "Preview ativado" : "Preview desativado");
}

function forceUpdateCheck() {
  if (typeof UpdateManager !== "undefined" && UpdateManager.check) {
    showToast("Verificando atualizacao...");
    UpdateManager.check();
  }
}

function openFFmpegHelp() {
  if (typeof showFFmpegMissingModal === "function") showFFmpegMissingModal();
}

// Colapsa ou expande a sidebar e persiste no state.
function setSidebarCollapsed(collapsed) {
  state.sidebarCollapsed = !!collapsed;
  saveState();
  applySidebarCollapsed();
}

function applySidebarCollapsed() {
  var sidebar = document.getElementById("sidebar");
  var expandBtn = document.getElementById("sidebarExpandBtn");
  if (!sidebar) return;
  if (state.sidebarCollapsed) {
    sidebar.style.display = "none";
    if (expandBtn) expandBtn.style.display = "flex";
  } else {
    sidebar.style.display = "";
    if (expandBtn) expandBtn.style.display = "none";
  }
}

// Sincroniza estado visual do menu de ordenacao com state.sortBy / sortOrder
function syncSortMenuActive() {
  var items = document.querySelectorAll("#sortMenu .sort-menu-item[data-sort]");
  for (var i = 0; i < items.length; i++) {
    items[i].classList.toggle("active", items[i].getAttribute("data-sort") === state.sortBy);
  }
  var label = document.getElementById("sortOrderLabel");
  var icon = document.getElementById("sortOrderIcon");
  if (label) label.textContent = state.sortOrder === "desc" ? "Decrescente" : "Crescente";
  if (icon) icon.classList.toggle("flipped", state.sortOrder === "desc");
}

// Atualiza o indicador de cloud na status bar conforme a pasta atual.
function updateCloudIndicator(folder) {
  var el = document.getElementById("cloudIndicator");
  var txt = document.getElementById("cloudIndicatorText");
  if (!el) return;
  var info = (typeof detectCloudPath === "function") ? detectCloudPath(folder) : null;
  state.cloudFolderInfo = info;
  if (!info) { el.style.display = "none"; return; }
  el.style.display = "inline-flex";
  el.classList.remove("staging");
  var label = "DRIVE";
  if (info.provider === "google-drive") label = info.shared ? "DRIVE COMPARTILHADO" : "GOOGLE DRIVE";
  else if (info.provider === "onedrive") label = "ONEDRIVE";
  else if (info.provider === "dropbox") label = "DROPBOX";
  else if (info.provider === "box") label = "BOX";
  if (txt) txt.textContent = label;
  el.title = "Pasta de assets em " + label.toLowerCase() + " — staging local ativo automaticamente para evitar problemas de Collect/Export.";
}

// Sinaliza atividade de staging (chamado pelo staging.js)
function setCloudIndicatorBusy(busy) {
  var el = document.getElementById("cloudIndicator");
  if (!el || el.style.display === "none") return;
  el.classList.toggle("staging", !!busy);
  var txt = document.getElementById("cloudIndicatorText");
  if (txt && busy) txt.textContent = "COPIANDO...";
  else if (txt && state.cloudFolderInfo) {
    var info = state.cloudFolderInfo;
    if (info.provider === "google-drive") txt.textContent = info.shared ? "DRIVE COMPARTILHADO" : "GOOGLE DRIVE";
    else if (info.provider === "onedrive") txt.textContent = "ONEDRIVE";
    else if (info.provider === "dropbox") txt.textContent = "DROPBOX";
    else if (info.provider === "box") txt.textContent = "BOX";
  }
}

function saveSettings() {
  saveState();
  closeSettingsModal();
  refreshFiles();
}

function updateGridSize() {
  state.gridSize = parseInt(document.getElementById("gridSize").value);
  document.getElementById("fileGrid").style.gridTemplateColumns =
    "repeat(auto-fill, minmax(" + state.gridSize + "px, 1fr))";
  saveState();
}
