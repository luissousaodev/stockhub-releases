// =============================================================================
// core/platform.js — Deteccao de plataforma e requires Node.js
// =============================================================================

var fs = require("fs");
var path = require("path");
var child = require("child_process");
var os = require("os");
var https = require("https");
var isWindows = process.platform === "win32";
var isMac = process.platform === "darwin";
