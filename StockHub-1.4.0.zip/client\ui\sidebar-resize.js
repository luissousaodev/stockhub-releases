// =============================================================================
// ui/sidebar-resize.js — Redimensionamento da sidebar
// =============================================================================

function initSidebarResize() {
  var handle = document.getElementById("sidebarResizeHandle");
  var sidebar = document.getElementById("sidebar");
  if (!handle || !sidebar) return;

  var dragging = false;
  var startX, startWidth;

  handle.addEventListener("mousedown", function(e) {
    e.preventDefault();
    dragging = true;
    startX = e.clientX;
    startWidth = sidebar.offsetWidth;
    handle.classList.add("dragging");
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
  });

  document.addEventListener("mousemove", function(e) {
    if (!dragging) return;
    var newWidth = startWidth + (e.clientX - startX);
    if (newWidth >= 100 && newWidth <= 280) {
      sidebar.style.width = newWidth + "px";
    }
  });

  document.addEventListener("mouseup", function() {
    if (!dragging) return;
    dragging = false;
    handle.classList.remove("dragging");
    document.body.style.cursor = "";
    document.body.style.userSelect = "";
    state.sidebarWidth = sidebar.offsetWidth;
    saveState();
  });
}
