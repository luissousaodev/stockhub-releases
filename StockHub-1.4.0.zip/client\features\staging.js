// =============================================================================
// features/staging.js — Staging local de assets cloud
// =============================================================================

function getDefaultStagingFolder() {
  var home = process.env.HOME || process.env.USERPROFILE || "";
  return path.join(home, "StockHub_staging");
}

function getStagingFolder() {
  return state.stagingFolder || getDefaultStagingFolder();
}

var _LARGE_COPY_THRESHOLD = 50 * 1024 * 1024; // 50 MB — toast so para copias grandes

// Versao SINCRONA — usada em paths que precisam retornar imediato (drag).
// Rapido se o arquivo ja esta cached; bloqueante na primeira copia.
// Para clicks/imports use stageFileAsync abaixo (nao trava UI).
function stageFileIfNeeded(file) {
  if (!file || !file.cloudOnly) return file.path;
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size === file.size && st.size > 0) return stagedPath;
    }
  } catch (e) { Logger.warn("staging", "Falha ao verificar staged file", e.message); }
  try {
    fs.mkdirSync(path.dirname(stagedPath), { recursive: true });
    if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(true);
    var isLarge = file.size && file.size > _LARGE_COPY_THRESHOLD;
    if (isLarge) showToast("Copiando para staging local...");
    fs.copyFileSync(file.path, stagedPath);
    if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(false);
    return stagedPath;
  } catch (e) {
    if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(false);
    Logger.error("staging", "Staging copy failed", e.message);
    showToast("Falha ao copiar para staging — Premiere usara o caminho original");
    return file.path;
  }
}

// Versao ASSINCRONA via stream — nao trava a UI durante a copia. Use em
// imports por click/duplo-click (batch ou single). callback(err, path).
function stageFileAsync(file, callback) {
  if (!file || !file.cloudOnly) { callback(null, file ? file.path : null); return; }
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  // Cache hit — retorna imediato (mesma logica do sync)
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size === file.size && st.size > 0) { callback(null, stagedPath); return; }
    }
  } catch (e) { Logger.warn("staging", "stageFileAsync stat", e.message); }
  // Cria diretorio destino
  try {
    fs.mkdirSync(path.dirname(stagedPath), { recursive: true });
  } catch (e) {
    Logger.error("staging", "stageFileAsync mkdir", e.message);
    callback(e, file.path);
    return;
  }
  // Copia via stream — nao bloqueia event loop como copyFileSync
  if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(true);
  var isLarge = file.size && file.size > _LARGE_COPY_THRESHOLD;
  if (isLarge) showToast("Copiando para staging local...");
  var rs = fs.createReadStream(file.path);
  var ws = fs.createWriteStream(stagedPath);
  var settled = false;
  function done(err, p) {
    if (settled) return;
    settled = true;
    if (typeof setCloudIndicatorBusy === "function") setCloudIndicatorBusy(false);
    callback(err, p);
  }
  rs.on("error", function(err) {
    Logger.error("staging", "stream read error", err.message);
    try { ws.destroy(); } catch (_) { /* ignora */ }
    done(err, file.path);
  });
  ws.on("error", function(err) {
    Logger.error("staging", "stream write error", err.message);
    try { rs.destroy(); } catch (_) { /* ignora */ }
    done(err, file.path);
  });
  ws.on("finish", function() { done(null, stagedPath); });
  rs.pipe(ws);
}

// Stage de varios arquivos em sequencia. callback(paths) recebe array de
// strings (mesmo tamanho do input; arquivos com erro mantem o path original).
function stageFilesAsync(files, callback) {
  var paths = new Array(files.length);
  var i = 0;
  function next() {
    if (i >= files.length) { callback(paths); return; }
    var f = files[i];
    if (!f) { paths[i] = null; i++; next(); return; }
    stageFileAsync(f, function(_err, p) {
      paths[i] = p;
      i++;
      next();
    });
  }
  next();
}

function getStagedPathIfExists(file) {
  if (!file || !file.cloudOnly) return null;
  var rel = toRelPath(file.path);
  var stagedPath = path.join(getStagingFolder(), rel);
  try {
    if (fs.existsSync(stagedPath)) {
      var st = fs.statSync(stagedPath);
      if (st.size > 0) return stagedPath;
    }
  } catch (e) { Logger.warn("staging", "Falha ao verificar staged path", e.message); }
  return null;
}

function changeStagingFolder() {
  var result = window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx
    ? window.cep.fs.showOpenDialogEx(false, true, "Escolha a pasta de staging", "")
    : null;
  if (result && result.data && result.data.length > 0) {
    state.stagingFolder = result.data[0];
    saveState();
    var el = document.getElementById("stagingFolderPath");
    if (el) el.textContent = state.stagingFolder;
    showToast("Pasta de staging alterada");
  }
}

function getStagingSize() {
  var folder = getStagingFolder();
  var total = 0;
  function walk(dir) {
    try {
      var items = fs.readdirSync(dir);
      for (var i = 0; i < items.length; i++) {
        var full = path.join(dir, items[i]);
        var st = fs.statSync(full);
        if (st.isDirectory()) walk(full);
        else total += st.size;
      }
    } catch (e) { /* pasta nao acessivel */ }
  }
  try { if (fs.existsSync(folder)) walk(folder); } catch (e) { /* sem folder */ }
  if (total < 1024 * 1024) return (total / 1024).toFixed(1) + " KB";
  if (total < 1024 * 1024 * 1024) return (total / (1024 * 1024)).toFixed(1) + " MB";
  return (total / (1024 * 1024 * 1024)).toFixed(1) + " GB";
}

function _doClearStagingFolder() {
  var folder = getStagingFolder();
  try {
    fs.rmSync(folder, { recursive: true, force: true });
    fs.mkdirSync(folder, { recursive: true });
    var el = document.getElementById("stagingSize");
    if (el) el.textContent = "0 KB";
    showToast("Staging limpo com sucesso");
  } catch (e) {
    showToast("Erro ao limpar staging: " + e.message);
  }
}

function clearStagingFolder() {
  var size = getStagingSize();
  if (size === "0.0 KB" || size === "0 KB") {
    showToast("Staging ja esta vazio");
    return;
  }
  showConfirmModal({
    title: "Limpar staging?",
    message: "Vamos liberar <b>" + size + "</b> em cache de assets da nuvem. " +
             "Se voce ainda nao fez Collect/Export do projeto, mantenha — sem isso o Premiere fica com midia offline.",
    confirmLabel: "Limpar",
    cancelLabel: "Cancelar",
    danger: true,
    onConfirm: _doClearStagingFolder
  });
}
