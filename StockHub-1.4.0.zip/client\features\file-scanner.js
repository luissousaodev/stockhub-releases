// =============================================================================
// features/file-scanner.js — Scan de pasta e watcher por polling
// =============================================================================

// --- File Scanning ---
function scanFolder(folderPath) {
  var files = [];

  try {
    if (!folderPath || !fs.existsSync(folderPath)) {
      Logger.error("scanner", "Pasta nao encontrada:", folderPath);
      return files;
    }

    // Detecta uma vez por scan: se a pasta-raiz aponta para nuvem, todos os
    // arquivos viram candidatos a staging defensivo (stat.blocks nao e
    // confiavel no Windows com Drive Stream / OneDrive Files-On-Demand).
    var rootCloud = (typeof detectCloudPath === "function") ? detectCloudPath(folderPath) : null;

    function walk(dir, category, depth, parentCatId) {
      var items;
      try {
        items = fs.readdirSync(dir);
      } catch (e) {
        return;
      }

      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var fullPath = path.join(dir, item);
        var stat;
        try {
          stat = fs.statSync(fullPath);
        } catch (e) {
          continue;
        }

        if (stat.isDirectory()) {
          // pula dot-dirs (.git, .cache, .DS_Store), pasta de dados e node_modules
          if (item.charAt(0) === "." || item === "stockhub-data" || item === "node_modules") continue;
          var catId = item.toLowerCase().replace(/[^a-z0-9]/g, "-");
          if (depth === 1 && parentCatId) catId = parentCatId + "/" + catId;
          if (depth <= 1 && state.autoCategories) {
            var exists = false;
            for (var j = 0; j < state.categories.length; j++) {
              if (state.categories[j].id === catId) { exists = true; break; }
            }
            if (!exists && state.deletedCategoryIds.indexOf(catId) === -1) {
              var catObj = { id: catId, name: item, color: getRandomColor() };
              if (depth === 1) catObj.parent = parentCatId;
              state.categories.push(catObj);
            }
          }
          var nextParent = (depth === 0) ? catId : parentCatId;
          walk(fullPath, catId, depth + 1, nextParent);
        } else {
          var ext = path.extname(item).toLowerCase();
          if (ALL_EXTENSIONS.indexOf(ext) >= 0) {
            var blocks = (typeof stat.blocks === "number") ? stat.blocks : -1;
            // Detecao por stat (preciso no macOS) + heuristica por path (rede de
            // seguranca para Windows + Drive Stream, onde stat.blocks e undefined).
            var cloudOnly = (blocks === 0) || (stat.size === 0) || !!rootCloud;
            files.push({
              name: item,
              path: fullPath,
              ext: ext.replace(".", ""),
              type: getFileType(ext),
              category: (state.fileCategories && state.fileCategories[toRelPath(fullPath)]) || category || "all",
              size: stat.size,
              modified: stat.mtime,
              cloudOnly: cloudOnly,
            });
          }
        }
      }
    }

    walk(folderPath, null, 0, null);
  } catch (e) {
    Logger.error("scanner", "Scan error", e.message);
  }
  return files;
}

// --- Filesystem watcher (polling) ---
// fs.watch recursivo nao funciona no macOS, e Drive Desktop tampouco emite
// eventos confiaveis. Substituido por polling: a cada 5s reconstroi um snapshot
// (relPath -> {mtimeMs, size}) e dispara re-scan se houver diff.
var _watchSnapshot = null;
var _watchTimer = null;
var _watchInterval = null;
var _watchedFolder = null;
// Antes era 5s, mas em pasta grande (Drive compartilhado com 5000+ arquivos)
// 5s significa rebuilds de snapshot quase em loop. 15s reduz a carga em 3x e
// ainda detecta mudancas em <30s. Combina com skip quando document.hidden.
var POLL_INTERVAL_MS = 15000;

function buildSnapshot(rootDir) {
  var snap = {};
  function walk(dir) {
    var items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (var i = 0; i < items.length; i++) {
      var d = items[i];
      var name = d.name;
      if (name.charAt(0) === "." || name === "stockhub-data" || name === "node_modules") continue;
      var full = path.join(dir, name);
      if (d.isDirectory()) {
        walk(full);
      } else {
        var ext = path.extname(name).toLowerCase();
        if (ALL_EXTENSIONS.indexOf(ext) < 0) continue;
        try {
          var st = fs.statSync(full);
          var rel = path.relative(rootDir, full).split(path.sep).join("/");
          snap[rel] = { m: st.mtimeMs, s: st.size };
        } catch (e) { Logger.warn("scanner", "Falha ao stat arquivo no snapshot", e.message); }
      }
    }
  }
  walk(rootDir);
  return snap;
}

function snapshotsDiffer(a, b) {
  if (!a || !b) return true;
  var ak = Object.keys(a), bk = Object.keys(b);
  if (ak.length !== bk.length) return true;
  for (var i = 0; i < ak.length; i++) {
    var k = ak[i];
    if (!b[k]) return true;
    if (a[k].m !== b[k].m || a[k].s !== b[k].s) return true;
  }
  return false;
}

function stopFolderWatcher() {
  if (_watchInterval) {
    clearInterval(_watchInterval);
    _watchInterval = null;
  }
  if (_watchTimer) {
    clearTimeout(_watchTimer);
    _watchTimer = null;
  }
  _watchSnapshot = null;
  _watchedFolder = null;
}

function startFolderWatcher(folder) {
  if (_watchedFolder === folder && _watchInterval) return;
  stopFolderWatcher();
  if (!folder || !fs.existsSync(folder)) return;
  _watchedFolder = folder;
  _watchSnapshot = buildSnapshot(folder);

  function pollOnce() {
    if (_watchedFolder !== folder) return;
    // Skip quando a janela esta oculta — pasta vai ser re-scaneada quando o
    // user voltar (vide visibilitychange handler abaixo).
    if (typeof document !== "undefined" && document.hidden) return;
    var next;
    try { next = buildSnapshot(folder); } catch (e) { return; }
    if (snapshotsDiffer(_watchSnapshot, next)) {
      _watchSnapshot = next;
      if (_watchTimer) clearTimeout(_watchTimer);
      _watchTimer = setTimeout(function() {
        _watchTimer = null;
        try {
          state.files = scanFolder(folder);
          renderAll();
          var statusEl = document.getElementById("statusText");
          if (statusEl) statusEl.textContent = "Atualizado automaticamente";
        } catch (e) {
          Logger.error("scanner", "Auto-refresh error", e.message);
        }
      }, 400);
    } else {
      _watchSnapshot = next;
    }
  }

  _watchInterval = setInterval(pollOnce, POLL_INTERVAL_MS);
}

// Para o watcher quando a janela e fechada/recarregada; e dispara um scan
// imediato quando a janela volta a ficar visivel apos estar oculta (assim o
// user nao espera ate 15s para ver mudancas de outros membros do time).
if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", function() { stopFolderWatcher(); });
  document.addEventListener("visibilitychange", function() {
    if (!document.hidden && _watchedFolder && _watchInterval) {
      try {
        var next = buildSnapshot(_watchedFolder);
        if (snapshotsDiffer(_watchSnapshot, next)) {
          _watchSnapshot = next;
          state.files = scanFolder(_watchedFolder);
          renderAll();
        }
      } catch (e) { Logger.warn("scanner", "Visibility refresh failed", e.message); }
    }
  });
}

// Exports para testes
if (typeof module !== "undefined") {
  module.exports = { buildSnapshot: buildSnapshot, snapshotsDiffer: snapshotsDiffer };
}
