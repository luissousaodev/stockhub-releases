// =============================================================================
// ui/render.js — Rendering do grid, categorias e filtering
// =============================================================================

if (!state.expandedCategories) state.expandedCategories = {};

// --- Empty States ---
// 4 variantes contextuais conforme o motivo da lista vazia.
var EMPTY_STATES = {
  noFolder: function(folder) {
    return {
      icon: '<path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>',
      title: "Nenhum arquivo na pasta",
      body: '<p>Coloque seus stocks na pasta:</p>' +
            '<p style="color:var(--green);font-size:10px;word-break:break-all;">' + folder + '</p>',
      cta: { label: "Abrir pasta", handler: "openStockFolder()" }
    };
  },
  noSearch: function(query) {
    return {
      icon: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
      title: 'Nada encontrado para "' + query + '"',
      body: '<p>Tente outro termo ou limpe a busca para ver todos.</p>',
      cta: { label: "Limpar busca", handler: "clearSearchQuery()" }
    };
  },
  noFormat: function(format) {
    var label = { video: "video", audio: "audio", image: "imagem", mogrt: "MOGRT" }[format] || format;
    return {
      icon: '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
      title: "Nenhum arquivo do tipo " + label,
      body: "<p>Mude o filtro no topo ou ajuste sua busca.</p>",
      cta: { label: "Ver todos", handler: "clearFormatFilter()" }
    };
  },
  noCategory: function(catName, isFavorites) {
    if (isFavorites) {
      return {
        icon: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
        title: "Sem favoritos ainda",
        body: "<p>Clique com o botao direito num asset e marque como favorito para acessar rapido aqui.</p>",
        cta: null
      };
    }
    return {
      icon: '<path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>',
      title: 'Categoria "' + catName + '" vazia',
      body: "<p>Arraste assets da grid para esta categoria, ou crie subpastas dentro da pasta de stock.</p>",
      cta: null
    };
  }
};

function pickEmptyState() {
  if (state.files.length === 0) {
    return EMPTY_STATES.noFolder(getStockFolder());
  }
  if (state.searchQuery) {
    return EMPTY_STATES.noSearch(state.searchQuery);
  }
  if (state.activeFormat && state.activeFormat !== "all") {
    return EMPTY_STATES.noFormat(state.activeFormat);
  }
  if (state.activeCategory === "__favorites") {
    return EMPTY_STATES.noCategory("Favoritos", true);
  }
  if (state.activeCategory && state.activeCategory !== "all") {
    var name = state.activeCategory;
    for (var i = 0; i < state.categories.length; i++) {
      if (state.categories[i].id === state.activeCategory) { name = state.categories[i].name; break; }
    }
    return EMPTY_STATES.noCategory(name, false);
  }
  // fallback
  return EMPTY_STATES.noSearch("");
}

function renderEmptyState(emptyEl) {
  var s = pickEmptyState();
  var ctaHTML = s.cta
    ? '<button class="btn btn-primary" onclick="' + s.cta.handler + '">' + s.cta.label + '</button>'
    : '';
  emptyEl.innerHTML =
    '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round">' +
      s.icon +
    '</svg>' +
    '<h3>' + s.title + '</h3>' +
    s.body +
    ctaHTML;
}

// Helpers para os CTAs dos empty states
function clearSearchQuery() {
  var inp = document.getElementById("searchInput");
  if (inp) { inp.value = ""; }
  state.searchQuery = "";
  renderGrid();
}

function clearFormatFilter() {
  state.activeFormat = "all";
  var items = document.querySelectorAll("#formatDropdownMenu .dropdown-item[data-format]");
  for (var i = 0; i < items.length; i++) {
    items[i].classList.toggle("active", items[i].getAttribute("data-format") === "all");
  }
  var lbl = document.getElementById("formatDropdownLabel");
  if (lbl) lbl.textContent = "TODOS";
  renderGrid();
}

// --- Filtering + Sorting ---
function getFilteredFiles() {
  var filtered = state.files.filter(function(f) {
    if (state.activeFormat !== "all" && f.type !== state.activeFormat) return false;
    if (state.activeCategory === "__favorites") {
      if (!state.favoriteFiles || !state.favoriteFiles[toRelPath(f.path)]) return false;
    } else if (state.activeCategory !== "all") {
      if (f.category !== state.activeCategory) {
        if (f.category && f.category.indexOf(state.activeCategory + "/") === 0) {
          // match — subcategoria do pai ativo
        } else {
          return false;
        }
      }
    }
    if (state.searchQuery) {
      var q = state.searchQuery.toLowerCase();
      if (f.name.toLowerCase().indexOf(q) >= 0) return true;
      var tags = state.fileTags && state.fileTags[toRelPath(f.path)];
      if (tags) {
        for (var t = 0; t < tags.length; t++) {
          if (tags[t].indexOf(q) >= 0) return true;
        }
      }
      return false;
    }
    return true;
  });

  return sortFiles(filtered);
}

function sortFiles(arr) {
  var by = state.sortBy || "name";
  var order = state.sortOrder === "desc" ? -1 : 1;
  arr.sort(function(a, b) {
    var av, bv;
    switch (by) {
      case "modified":
        av = a.modified ? new Date(a.modified).getTime() : 0;
        bv = b.modified ? new Date(b.modified).getTime() : 0;
        return (av - bv) * order;
      case "size":
        return ((a.size || 0) - (b.size || 0)) * order;
      case "type":
        av = (a.type || "") + "_" + (a.name || "").toLowerCase();
        bv = (b.type || "") + "_" + (b.name || "").toLowerCase();
        if (av < bv) return -1 * order;
        if (av > bv) return 1 * order;
        return 0;
      case "name":
      default:
        av = (a.name || "").toLowerCase();
        bv = (b.name || "").toLowerCase();
        if (av < bv) return -1 * order;
        if (av > bv) return 1 * order;
        return 0;
    }
  });
  return arr;
}

// --- Categories ---
function getCatFileCount(catId, isSystem) {
  if (isSystem) return state.files.length;
  return state.files.filter(function(f) {
    return f.category === catId || (f.category && f.category.indexOf(catId + "/") === 0);
  }).length;
}

function toggleCategoryExpand(catId, e) {
  e.stopPropagation();
  state.expandedCategories[catId] = !state.expandedCategories[catId];
  renderCategories();
}

function renderCatItem(cat, isSub, childrenMap) {
  var children = childrenMap[cat.id] || [];
  var hasChildren = children.length > 0;
  var isExpanded = state.expandedCategories[cat.id];
  var count = isSub
    ? state.files.filter(function(f) { return f.category === cat.id; }).length
    : getCatFileCount(cat.id, cat.system);

  var arrow = '';
  if (hasChildren && !cat.system) {
    arrow = '<span class="cat-arrow ' + (isExpanded ? "expanded" : "") + '" ' +
      'onclick="toggleCategoryExpand(\'' + cat.id + '\', event)">' +
      '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
        '<polyline points="9 18 15 12 9 6"/>' +
      '</svg></span>';
  }

  var ctxMenu = cat.system ? '' : 'oncontextmenu="showCatContextMenu(event, \'' + cat.id + '\')"';

  var isActive = state.activeCategory === cat.id;
  var isParentActive = !isActive && typeof state.activeCategory === "string" &&
    state.activeCategory.indexOf(cat.id + "/") === 0;
  var stateClass = isActive ? "active" : (isParentActive ? "parent-active" : "");
  var html = '<div class="cat-item ' + (isSub ? "cat-sub " : "") + stateClass + '" ' +
    'onclick="setCategory(\'' + cat.id + '\')" ' +
    ctxMenu + ' ' +
    'ondragover="onCatDragOver(event)" ' +
    'ondragleave="onCatDragLeave(event)" ' +
    'ondrop="onCatDrop(event, \'' + cat.id + '\')">' +
    '<span style="display:flex;align-items:center;gap:6px;overflow:hidden;">' +
      arrow +
      '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + cat.name + '</span>' +
    '</span>' +
    '<span class="cat-count">' + count + '</span>' +
  '</div>';

  if (hasChildren && isExpanded) {
    html += '<div class="cat-sub-group">';
    for (var c = 0; c < children.length; c++) {
      html += renderCatItem(children[c], true, childrenMap);
    }
    html += '</div>';
  }

  return html;
}

function getFavoriteCount() {
  if (!state.favoriteFiles) return 0;
  var count = 0;
  for (var i = 0; i < state.files.length; i++) {
    if (state.favoriteFiles[toRelPath(state.files[i].path)]) count++;
  }
  return count;
}

function renderCategories() {
  var list = document.getElementById("categoryList");

  // --- MAIN section sb-items: Favoritos / Todos ---
  var sbFav = document.getElementById("sbFavorites");
  var sbAll = document.getElementById("sbAll");
  if (sbFav) {
    sbFav.classList.toggle("active", state.activeCategory === "__favorites");
    sbFav.onclick = function() { setCategory("__favorites"); };
    sbFav.ondragover = function(e) { onCatDragOver(e); };
    sbFav.ondragleave = function(e) { onCatDragLeave(e); };
    sbFav.ondrop = function(e) { onFavoritesDrop(e); };
  }
  if (sbAll) {
    sbAll.classList.toggle("active", state.activeCategory === "all");
    sbAll.onclick = function() { setCategory("all"); };
  }

  // --- Categorias do usuário (não-system, não-parent) ---
  var html = "";
  var normalCats = [];
  var childrenMap = {};

  for (var i = 0; i < state.categories.length; i++) {
    var cat = state.categories[i];
    if (cat.parent) {
      if (!childrenMap[cat.parent]) childrenMap[cat.parent] = [];
      childrenMap[cat.parent].push(cat);
    } else if (!cat.system) {
      normalCats.push(cat);
    }
  }

  for (var n = 0; n < normalCats.length; n++) {
    html += renderCatItem(normalCats[n], false, childrenMap);
  }

  if (list) list.innerHTML = html;
}

function renderGrid() {
  var grid = document.getElementById("fileGrid");
  var files = getFilteredFiles();

  cleanupPreview();

  document.getElementById("fileCount").textContent = files.length + " arquivos";

  if (files.length === 0) {
    grid.innerHTML = "";
    var container = document.getElementById("gridContainer");
    var emptyEl = container.querySelector(".empty-state");
    if (!emptyEl) {
      emptyEl = document.createElement("div");
      emptyEl.className = "empty-state";
      container.appendChild(emptyEl);
    }

    renderEmptyState(emptyEl);
    emptyEl.style.display = "flex";
    return;
  }

  var emptyEl2 = document.getElementById("gridContainer").querySelector(".empty-state");
  if (emptyEl2) emptyEl2.style.display = "none";

  // Selection bar
  var selCount = Object.keys(state.selectedFiles).length;
  var selBar = document.getElementById("selectionBar");
  if (selCount > 0) {
    if (!selBar) {
      selBar = document.createElement("div");
      selBar.id = "selectionBar";
      selBar.className = "selection-bar";
      grid.parentNode.insertBefore(selBar, grid);
    }
    selBar.innerHTML =
      '<span>' + selCount + ' arquivo' + (selCount > 1 ? 's' : '') + ' selecionado' + (selCount > 1 ? 's' : '') + '</span>' +
      '<div class="selection-actions">' +
        '<button id="batchTimelineBtn">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
            '<polygon points="5 3 19 12 5 21 5 3"/>' +
          '</svg>' +
          'Timeline' +
        '</button>' +
        '<button id="batchImportBtn">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
            '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>' +
          '</svg>' +
          'Importar' +
        '</button>' +
        '<button id="clearSelectionBtn">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
            '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>' +
          '</svg>' +
          'Limpar' +
        '</button>' +
      '</div>';
    selBar.querySelector("#batchTimelineBtn").addEventListener("click", batchInsertToTimeline);
    selBar.querySelector("#batchImportBtn").addEventListener("click", batchImportSelected);
    selBar.querySelector("#clearSelectionBtn").addEventListener("click", clearSelection);
  } else if (selBar) {
    selBar.remove();
  }

  grid.style.gridTemplateColumns = "repeat(auto-fill, minmax(" + state.gridSize + "px, 1fr))";

  var fileIndexMap = {};
  for (var m = 0; m < state.files.length; m++) {
    fileIndexMap[state.files[m].path] = m;
  }

  grid.innerHTML = files.map(function(f) {
    var thumb = getThumbnail(f);
    var idx = fileIndexMap[f.path];
    var res = resolutionCache[f.path] || "";

    var thumbContent;
    if (thumb) {
      thumbContent = '<img class="thumbnail" src="' + thumb + '" loading="lazy" />';
    } else if (f.type === "video" && thumbCache[f.path]) {
      thumbContent = '<img class="thumbnail" src="' + thumbCache[f.path] + '" loading="lazy" />';
    } else if (f.type === "image") {
      thumbContent = '<img class="thumbnail" src="' + toFileURL(f.path) + '" loading="lazy" />';
    } else {
      var iconSvg;
      if (f.type === "audio") {
        iconSvg = '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>';
      } else {
        iconSvg = '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>';
      }
      thumbContent = '<div class="placeholder">' +
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
              iconSvg +
            '</svg>' +
            '<span style="font-size:9px;">' + f.ext.toUpperCase() + '</span>' +
          '</div>';
    }

    var cloudBadge = f.cloudOnly
      ? '<span class="cloud-badge" title="Arquivo na nuvem (nao baixado)">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M18 10h-1.26A8 8 0 109 20h9a5 5 0 000-10z"/>' +
          '</svg>' +
        '</span>'
      : '';

    // Meta-line abaixo do thumb: FORMATO | RESOLUCAO | DURACAO
    var dur = (f.type === "video" && typeof FFmpegManager !== "undefined" && FFmpegManager.durationCache)
      ? FFmpegManager.durationCache[f.path] : null;
    var metaParts = [f.ext.toUpperCase()];
    if (res) metaParts.push(res);
    if (dur && typeof formatDuration === "function") metaParts.push(formatDuration(dur));
    var metaLine = '<div class="grid-item-meta" data-meta>' +
      metaParts.map(function(p) { return '<span>' + p + '</span>'; }).join('<span class="grid-item-meta-sep">|</span>') +
    '</div>';

    var isSelected = state.selectedFiles[idx];
    var safeNameTitle = (f.name + (f.cloudOnly ? " (na nuvem)" : "")).replace(/"/g, '&quot;').replace(/</g, '&lt;');
    var safeName = f.name.replace(/\.[^.]+$/, "").replace(/</g, '&lt;');

    return '<div class="grid-item' + (f.cloudOnly ? ' cloud-only' : '') + (isSelected ? ' selected' : '') + '" ' +
      'data-filepath="' + f.path.replace(/"/g, '&quot;') + '" ' +
      'data-rel="' + toRelPath(f.path).replace(/"/g, '&quot;') + '" ' +
      'draggable="true" ' +
      'ondragstart="onFileDragStart(event, ' + idx + ')" ' +
      'ondragend="onFileDragEnd(event, ' + idx + ')" ' +
      'ondblclick="onDoubleClick(' + idx + ')" ' +
      'oncontextmenu="showContextMenu(event, ' + idx + ')" ' +
      'onmouseenter="onMouseEnter(this, ' + idx + ')" ' +
      'onmouseleave="onMouseLeave(this)">' +
      '<div class="grid-item-thumb">' +
        thumbContent +
        cloudBadge +
        '<button class="import-btn" onclick="event.stopPropagation(); importToProject(' + idx + ')" title="Importar no projeto">' +
          '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
            '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>' +
          '</svg>' +
        '</button>' +
      '</div>' +
      metaLine +
      '<span class="file-name" title="' + safeNameTitle + '">' + safeName + '</span>' +
      (function() {
        var tags = state.fileTags && state.fileTags[toRelPath(f.path)];
        if (!tags || tags.length === 0) return '';
        var tagsTitle = tags.join(', ').replace(/"/g, '&quot;').replace(/</g, '&lt;');
        return '<span class="tag-badge" title="' + tagsTitle + '">' +
          '<svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor" stroke="none">' +
            '<path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/>' +
          '</svg>' +
          tags.length +
        '</span>';
      })() +
    '</div>';
  }).join("");

  if (typeof setupViewportObserver === "function") setupViewportObserver();
}

// --- Multi-select ---
function toggleFileSelection(fileIndex, e) {
  if (e && e.ctrlKey) {
    if (state.selectedFiles[fileIndex]) {
      delete state.selectedFiles[fileIndex];
    } else {
      state.selectedFiles[fileIndex] = true;
    }
  } else if (e && e.shiftKey && state._lastSelectedIndex !== undefined) {
    var from = Math.min(state._lastSelectedIndex, fileIndex);
    var to = Math.max(state._lastSelectedIndex, fileIndex);
    var filtered = getFilteredFiles();
    var fileIndexMap = {};
    for (var m = 0; m < state.files.length; m++) fileIndexMap[state.files[m].path] = m;
    for (var i = 0; i < filtered.length; i++) {
      var idx = fileIndexMap[filtered[i].path];
      if (idx >= from && idx <= to) state.selectedFiles[idx] = true;
    }
  } else {
    state.selectedFiles = {};
    state.selectedFiles[fileIndex] = true;
  }
  state._lastSelectedIndex = fileIndex;
  renderGrid();
}

function clearSelection() {
  state.selectedFiles = {};
  renderGrid();
}

function batchImportSelected() {
  var indices = Object.keys(state.selectedFiles).map(Number);
  if (indices.length === 0) return;

  var total = indices.length;
  var done = 0;
  var errors = 0;
  var cancelled = false;

  showImportProgress(total);

  function importNext() {
    if (cancelled || done >= total) {
      hideImportProgress();
      var msg = cancelled
        ? "Importacao cancelada (" + done + "/" + total + ")"
        : "Batch import: " + (total - errors) + "/" + total + " importados";
      if (!cancelled && errors > 0) msg += " (" + errors + " erro" + (errors > 1 ? "s" : "") + ")";
      showToast(msg);
      state.selectedFiles = {};
      renderGrid();
      return;
    }
    var idx = indices[done];
    var file = state.files[idx];
    if (!file) { done++; errors++; updateImportProgress(done, total, ""); importNext(); return; }
    updateImportProgress(done, total, file.name);
    stageFileAsync(file, function(_err, importPath) {
      var escapedPath = importPath.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
      cs.evalScript("importFileToProject('" + escapedPath + "')", function(result) {
        done++;
        try {
          var res = JSON.parse(result);
          if (res.success && !res.alreadyExists) trackEvent(file, "import");
          if (!res.success) errors++;
        } catch (e) { errors++; }
        document.getElementById("statusText").textContent = "Importando... " + done + "/" + total;
        importNext();
      });
    });
  }

  // Botao Cancelar do overlay
  window._cancelBatchImport = function() { cancelled = true; };

  document.getElementById("statusText").textContent = "Importando... 0/" + total;
  importNext();
}

// --- Import progress overlay ---
function showImportProgress(total) {
  var existing = document.getElementById("importProgress");
  if (existing) existing.remove();
  var overlay = document.createElement("div");
  overlay.id = "importProgress";
  overlay.className = "import-progress";
  overlay.innerHTML =
    '<div class="import-progress-card">' +
      '<div class="import-progress-header">' +
        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="spin">' +
          '<line x1="12" y1="2" x2="12" y2="6"/>' +
          '<line x1="12" y1="18" x2="12" y2="22"/>' +
          '<line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/>' +
          '<line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/>' +
          '<line x1="2" y1="12" x2="6" y2="12"/>' +
          '<line x1="18" y1="12" x2="22" y2="12"/>' +
          '<line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/>' +
          '<line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/>' +
        '</svg>' +
        '<span>Importando 0/' + total + '</span>' +
      '</div>' +
      '<div class="import-progress-name">Preparando...</div>' +
      '<div class="import-progress-bar"><div class="import-progress-fill" style="width:0%"></div></div>' +
      '<button class="btn import-progress-cancel" onclick="window._cancelBatchImport && window._cancelBatchImport()">Cancelar</button>' +
    '</div>';
  document.body.appendChild(overlay);
}

function updateImportProgress(done, total, name) {
  var overlay = document.getElementById("importProgress");
  if (!overlay) return;
  var pct = Math.round((done / total) * 100);
  var header = overlay.querySelector(".import-progress-header span");
  var nameEl = overlay.querySelector(".import-progress-name");
  var fill = overlay.querySelector(".import-progress-fill");
  if (header) header.textContent = "Importando " + done + "/" + total;
  if (nameEl) nameEl.textContent = name || "";
  if (fill) fill.style.width = pct + "%";
}

function hideImportProgress() {
  var overlay = document.getElementById("importProgress");
  if (overlay) overlay.remove();
}

function renderAll() {
  renderCategories();
  renderGrid();
}
