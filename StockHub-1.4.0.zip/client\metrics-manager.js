// =============================================================================
// metrics-manager.js — Modulo de metricas e analytics do StockHub
//
// Responsabilidades:
//   - Rastreio de eventos (import, timeline) em JSONL
//   - Leitura e agregacao de eventos por periodo/filtros
//   - Painel de metricas com graficos e tabelas
//   - Exportacao CSV com dialogo nativo
//   - Date picker customizado (PT-BR)
//
// Dependencias externas (recebidas via init):
//   - state, getStockFolder, showToast, toggleSettings, cs
// =============================================================================

// Funcoes puras testáveis (fora da IIFE)
function _aggregateEvents(events) {
  var topAssets = {};
  var byUser = {};
  var byCategory = {};
  var byDay = {};
  var lastUse = {};

  for (var i = 0; i < events.length; i++) {
    var e = events[i];
    var key = e.assetName;
    topAssets[key] = (topAssets[key] || 0) + 1;
    byUser[e.userId] = (byUser[e.userId] || 0) + 1;
    byCategory[e.category] = (byCategory[e.category] || 0) + 1;
    var day = e.usedAt ? e.usedAt.slice(0, 10) : "unknown";
    byDay[day] = (byDay[day] || 0) + 1;
    if (!lastUse[key] || e.usedAt > lastUse[key]) {
      lastUse[key] = e.usedAt;
    }
  }

  var topList = Object.keys(topAssets).map(function(k) {
    return { name: k, count: topAssets[k], lastUse: lastUse[k] || "" };
  }).sort(function(a, b) { return b.count - a.count; });

  return {
    total: events.length,
    topAssets: topList,
    byUser: byUser,
    byCategory: byCategory,
    byDay: byDay
  };
}

function _formatDateBR(iso) {
  if (!iso) return "";
  var p = iso.split("-");
  return p[2] + "/" + p[1] + "/" + p[0];
}

// IIFE — encapsula estado privado (so roda no browser)
if (typeof window !== "undefined") (function() {
  var _fs    = require("fs");
  var _path  = require("path");
  var _os    = require("os");
  var _child = require("child_process");
  var _isWin = process.platform === "win32";

  // Dependencias injetadas via init()
  var _state           = null;
  var _getStockFolder  = null;
  var _showToast       = null;
  var _toggleSettings  = null;
  var _cs              = null;

  // Estado interno do modulo
  var metricsState = {
    visible: false,
    startDate: "",
    endDate: "",
    filterUserId: "",
    filterCategory: "",
    filterType: ""
  };

  // Date picker state
  var PT_MONTHS = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
  var PT_DAYS_SHORT = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
  var _dpState = { field: null, year: 0, month: 0 };

  // -------------------------------------------------------------------------
  // Event tracking (JSONL)
  // -------------------------------------------------------------------------

  function getEventsDir() {
    return _path.join(_getStockFolder(), "stockhub-data", "events");
  }

  function trackEvent(file, action) {
    if (!_state.userId) return;
    var now = new Date();
    var dateStr = now.toISOString().slice(0, 10);
    var dayDir = _path.join(getEventsDir(), dateStr);

    try {
      if (!_fs.existsSync(dayDir)) _fs.mkdirSync(dayDir, { recursive: true });
    } catch (e) {
      console.error("trackEvent mkdir:", e);
      return;
    }

    var event = {
      assetName: file.name,
      assetPath: file.path,
      category: file.category || "all",
      type: file.type || "unknown",
      userId: _state.userId,
      action: action,
      usedAt: now.toISOString()
    };

    var filePath = _path.join(dayDir, _state.userId + ".jsonl");
    try {
      _fs.appendFileSync(filePath, JSON.stringify(event) + "\n", "utf-8");
    } catch (e) {
      console.error("trackEvent write:", e);
    }
  }

  // -------------------------------------------------------------------------
  // Event reading
  // -------------------------------------------------------------------------

  function readEvents(startDate, endDate, filters) {
    var eventsDir = getEventsDir();
    var events = [];

    if (!_fs.existsSync(eventsDir)) return events;

    var dirs;
    try { dirs = _fs.readdirSync(eventsDir); } catch (e) { return events; }

    var start = startDate || "0000-00-00";
    var end = endDate || "9999-99-99";

    for (var d = 0; d < dirs.length; d++) {
      var dateDir = dirs[d];
      if (dateDir < start || dateDir > end) continue;
      var fullDir = _path.join(eventsDir, dateDir);
      var stat;
      try { stat = _fs.statSync(fullDir); } catch (e) { continue; }
      if (!stat.isDirectory()) continue;

      var files;
      try { files = _fs.readdirSync(fullDir); } catch (e) { continue; }

      for (var f = 0; f < files.length; f++) {
        if (!files[f].endsWith(".jsonl")) continue;

        if (filters && filters.userId) {
          var fileUserId = files[f].replace(".jsonl", "");
          if (fileUserId !== filters.userId) continue;
        }

        var content;
        try { content = _fs.readFileSync(_path.join(fullDir, files[f]), "utf-8"); } catch (e) { continue; }
        var lines = content.trim().split("\n");

        for (var l = 0; l < lines.length; l++) {
          if (!lines[l]) continue;
          try {
            var evt = JSON.parse(lines[l]);
            if (filters) {
              if (filters.category && evt.category !== filters.category) continue;
              if (filters.type && evt.type !== filters.type) continue;
            }
            events.push(evt);
          } catch (e) { continue; }
        }
      }
    }

    return events;
  }

  // -------------------------------------------------------------------------
  // CSV export
  // -------------------------------------------------------------------------

  function exportEventsCSV(events) {
    var header = "assetName,assetPath,category,type,userId,action,usedAt";
    var lines = [header];
    for (var i = 0; i < events.length; i++) {
      var e = events[i];
      lines.push([
        '"' + (e.assetName || "").replace(/"/g, '""') + '"',
        '"' + (e.assetPath || "").replace(/"/g, '""') + '"',
        e.category || "",
        e.type || "",
        e.userId || "",
        e.action || "",
        e.usedAt || ""
      ].join(","));
    }

    var csv = lines.join("\n");
    var defaultName = "stockhub-export-" + new Date().toISOString().slice(0, 10) + ".csv";

    if (_isWin) {
      var psFile = _path.join(_os.tmpdir(), "stockhub_save_csv.ps1");
      var psContent = [
        'Add-Type -AssemblyName System.Windows.Forms',
        '$form = New-Object System.Windows.Forms.Form',
        '$form.TopMost = $true',
        '$form.Width = 0',
        '$form.Height = 0',
        '$form.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual',
        '$form.Location = New-Object System.Drawing.Point(-1000,-1000)',
        '$form.Show()',
        '$dlg = New-Object System.Windows.Forms.SaveFileDialog',
        '$dlg.Title = "Salvar exportacao CSV"',
        '$dlg.Filter = "CSV (*.csv)|*.csv"',
        '$dlg.FileName = "' + defaultName + '"',
        '$dlg.DefaultExt = "csv"',
        '$dlg.InitialDirectory = [Environment]::GetFolderPath("Desktop")',
        'if ($dlg.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {',
        '  $dlg.FileName',
        '}',
        '$form.Close()',
      ].join("\n");
      _fs.writeFileSync(psFile, psContent, "utf-8");
      _child.exec('powershell -ExecutionPolicy Bypass -File "' + psFile + '"', function(err, stdout) {
        try { _fs.unlinkSync(psFile); } catch(ex) { Logger.warn("metrics", "cleanup ps1 temp failed", ex.message); }
        var exportPath = stdout ? stdout.trim() : "";
        if (!err && exportPath) {
          try {
            _fs.writeFileSync(exportPath, "\uFEFF" + csv, "utf-8");
            _showToast("Exportado: " + exportPath);
            _cs.evalScript('new File("' + exportPath.replace(/\\/g, "/") + '").execute()');
          } catch (ex) {
            _showToast("Erro ao exportar: " + ex.toString());
          }
        }
      });
    } else {
      var appleScript = "osascript -e 'tell application \"System Events\"' -e 'activate' " +
        "-e 'set savePath to POSIX path of (choose file name with prompt \"Salvar exportacao CSV\" default name \"" + defaultName + "\")' " +
        "-e 'end tell'";
      _child.exec(appleScript, function(err, stdout) {
        var exportPath = stdout ? stdout.trim() : "";
        if (!err && exportPath) {
          if (!exportPath.match(/\.csv$/i)) exportPath += ".csv";
          try {
            _fs.writeFileSync(exportPath, "\uFEFF" + csv, "utf-8");
            _showToast("Exportado: " + exportPath);
          } catch (ex) {
            _showToast("Erro ao exportar: " + ex.toString());
          }
        }
      });
    }
  }

  // -------------------------------------------------------------------------
  // Date picker (PT-BR)
  // -------------------------------------------------------------------------

  function _isoToday() {
    return new Date().toISOString().slice(0, 10);
  }

  function openDatePicker(field, currentIso) {
    _dpState.field = field;
    var d = currentIso ? new Date(currentIso + "T00:00:00") : new Date();
    _dpState.year  = d.getFullYear();
    _dpState.month = d.getMonth();

    var overlay = document.getElementById("dpOverlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "dpOverlay";
      overlay.className = "dp-overlay";
      overlay.innerHTML =
        '<div class="dp-modal" id="dpModal">' +
          '<div class="dp-header">' +
            '<button class="dp-nav" onclick="dpNavigate(-1)">&#8249;</button>' +
            '<span class="dp-title" id="dpTitle"></span>' +
            '<button class="dp-nav" onclick="dpNavigate(1)">&#8250;</button>' +
          '</div>' +
          '<div class="dp-weekdays" id="dpWeekdays"></div>' +
          '<div class="dp-grid" id="dpGrid"></div>' +
          '<div class="dp-footer">' +
            '<button class="dp-btn-cancel" onclick="closeDatePicker()">Cancelar</button>' +
            '<button class="dp-btn-today" onclick="dpSelectToday()">Hoje</button>' +
          '</div>' +
        '</div>';
      overlay.addEventListener("click", function(e) { if (e.target === overlay) closeDatePicker(); });
      document.body.appendChild(overlay);
    }

    _refreshDatePicker();
    overlay.style.display = "flex";
  }

  function dpNavigate(dir) {
    _dpState.month += dir;
    if (_dpState.month > 11) { _dpState.month = 0; _dpState.year++; }
    if (_dpState.month < 0)  { _dpState.month = 11; _dpState.year--; }
    _refreshDatePicker();
  }

  function _refreshDatePicker() {
    var y = _dpState.year, m = _dpState.month;
    document.getElementById("dpTitle").textContent = PT_MONTHS[m] + " " + y;

    document.getElementById("dpWeekdays").innerHTML = PT_DAYS_SHORT.map(function(d) {
      return '<span class="dp-weekday">' + d + '</span>';
    }).join("");

    var firstDay = new Date(y, m, 1).getDay();
    var daysInMonth = new Date(y, m + 1, 0).getDate();
    var todayIso = _isoToday();
    var currentIso = _dpState.field === "start" ? metricsState.startDate : metricsState.endDate;

    var cells = "";
    for (var i = 0; i < firstDay; i++) cells += '<span class="dp-cell dp-empty"></span>';
    for (var day = 1; day <= daysInMonth; day++) {
      var iso = y + "-" + (m < 9 ? "0" : "") + (m + 1) + "-" + (day < 10 ? "0" : "") + day;
      var cls = "dp-cell";
      if (iso === currentIso) cls += " dp-selected";
      else if (iso === todayIso) cls += " dp-today-mark";
      cells += '<span class="' + cls + '" onclick="dpSelectDay(\'' + iso + '\')">' + day + '</span>';
    }
    document.getElementById("dpGrid").innerHTML = cells;
  }

  function dpSelectDay(iso) {
    if (_dpState.field === "start") {
      metricsState.startDate = iso;
    } else {
      metricsState.endDate = iso;
    }
    closeDatePicker();
    renderMetrics();
  }

  function dpSelectToday() { dpSelectDay(_isoToday()); }

  function closeDatePicker() {
    var overlay = document.getElementById("dpOverlay");
    if (overlay) overlay.style.display = "none";
  }

  // -------------------------------------------------------------------------
  // Toggle & Render
  // -------------------------------------------------------------------------

  function _renderMetricsModalShell() {
    return '' +
      '<div class="modal-overlay" onclick="closeMetricsModal(event)">' +
        '<div class="modal modal-metrics" onclick="event.stopPropagation()">' +
          '<div class="modal-header">' +
            '<div class="modal-header-title">' +
              '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>' +
              '</svg>Métricas de uso' +
            '</div>' +
            '<button class="modal-close-btn" onclick="closeMetricsModal()" aria-label="Fechar">' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
                '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>' +
              '</svg>' +
            '</button>' +
          '</div>' +
          '<div class="modal-body" id="metricsContent"></div>' +
        '</div>' +
      '</div>';
  }

  function toggleMetrics() {
    if (metricsState.visible) {
      closeMetricsModal();
      return;
    }
    if (_state.showSettings && typeof window.closeSettingsModal === "function") {
      window.closeSettingsModal();
    }
    metricsState.visible = true;

    var btn = document.getElementById("metricsBtn");
    if (btn) btn.classList.add("active");

    if (!metricsState.endDate) {
      var today = new Date();
      metricsState.endDate = today.toISOString().slice(0, 10);
      var start = new Date(today);
      start.setDate(start.getDate() - 30);
      metricsState.startDate = start.toISOString().slice(0, 10);
    }

    document.getElementById("modalContainer").innerHTML = _renderMetricsModalShell();
    renderMetrics();
  }

  function closeMetricsModal(e) {
    if (e && e.target !== e.currentTarget) return;
    metricsState.visible = false;
    var btn = document.getElementById("metricsBtn");
    if (btn) btn.classList.remove("active");
    document.getElementById("modalContainer").innerHTML = "";
  }

  function renderMetrics() {
    var filters = {};
    if (metricsState.filterUserId) filters.userId = metricsState.filterUserId;
    if (metricsState.filterCategory) filters.category = metricsState.filterCategory;
    if (metricsState.filterType) filters.type = metricsState.filterType;

    var events = readEvents(metricsState.startDate, metricsState.endDate, filters);
    var agg = _aggregateEvents(events);

    var allEvents = readEvents(metricsState.startDate, metricsState.endDate, {});
    var uniqueUsers = {};
    for (var u = 0; u < allEvents.length; u++) uniqueUsers[allEvents[u].userId] = true;
    var userList = Object.keys(uniqueUsers).sort();

    var catOptions = _state.categories.filter(function(c) { return !c.system; }).map(function(c) {
      return '<option value="' + c.id + '"' + (metricsState.filterCategory === c.id ? " selected" : "") + '>' + c.name + '</option>';
    }).join("");

    var userOptions = userList.map(function(uid) {
      return '<option value="' + uid + '"' + (metricsState.filterUserId === uid ? " selected" : "") + '>' + uid + '</option>';
    }).join("");

    var panel = document.getElementById("metricsContent");

    var filtersHtml =
      '<div class="metrics-filters">' +
        '<div class="metrics-filter-row">' +
          '<label>De:</label>' +
          '<button class="date-picker-btn" onclick="openDatePicker(\'start\', metricsState.startDate)">' + (metricsState.startDate ? _formatDateBR(metricsState.startDate) : "DD/MM/AAAA") + '</button>' +
          '<label>Ate:</label>' +
          '<button class="date-picker-btn" onclick="openDatePicker(\'end\', metricsState.endDate)">' + (metricsState.endDate ? _formatDateBR(metricsState.endDate) : "DD/MM/AAAA") + '</button>' +
        '</div>' +
        '<div class="metrics-filter-row">' +
          '<label>Usuario:</label>' +
          '<select onchange="metricsState.filterUserId=this.value;renderMetrics()"><option value="">Todos</option>' + userOptions + '</select>' +
          '<label>Categoria:</label>' +
          '<select onchange="metricsState.filterCategory=this.value;renderMetrics()"><option value="">Todas</option>' + catOptions + '</select>' +
          '<label>Tipo:</label>' +
          '<select onchange="metricsState.filterType=this.value;renderMetrics()">' +
            '<option value="">Todos</option>' +
            '<option value="video"' + (metricsState.filterType === "video" ? " selected" : "") + '>Video</option>' +
            '<option value="audio"' + (metricsState.filterType === "audio" ? " selected" : "") + '>Audio</option>' +
            '<option value="image"' + (metricsState.filterType === "image" ? " selected" : "") + '>Imagem</option>' +
            '<option value="mogrt"' + (metricsState.filterType === "mogrt" ? " selected" : "") + '>MOGRT</option>' +
          '</select>' +
        '</div>' +
      '</div>';

    var summaryHtml =
      '<div class="metrics-summary">' +
        '<div class="metrics-card">' +
          '<div class="metrics-card-value">' + agg.total + '</div>' +
          '<div class="metrics-card-label">Total de usos</div>' +
        '</div>' +
        '<div class="metrics-card">' +
          '<div class="metrics-card-value">' + agg.topAssets.length + '</div>' +
          '<div class="metrics-card-label">Assets unicos</div>' +
        '</div>' +
        '<div class="metrics-card">' +
          '<div class="metrics-card-value">' + Object.keys(agg.byUser).length + '</div>' +
          '<div class="metrics-card-label">Usuarios ativos</div>' +
        '</div>' +
        '<div class="metrics-card">' +
          '<div class="metrics-card-value">' + Object.keys(agg.byDay).length + '</div>' +
          '<div class="metrics-card-label">Dias com uso</div>' +
        '</div>' +
      '</div>';

    var topN = agg.topAssets.slice(0, 20);
    var topHtml =
      '<div class="metrics-section">' +
        '<div class="metrics-section-title">Top Assets</div>' +
        '<div class="metrics-table-wrap">' +
          '<table class="metrics-table">' +
            '<thead><tr><th>#</th><th>Asset</th><th>Usos</th><th>Ultimo uso</th></tr></thead>' +
            '<tbody>' +
            topN.map(function(a, i) {
              var lastDate = a.lastUse ? _formatDateBR(a.lastUse.slice(0, 10)) : "-";
              return '<tr><td>' + (i + 1) + '</td><td title="' + a.name + '">' + a.name + '</td><td>' + a.count + '</td><td>' + lastDate + '</td></tr>';
            }).join("") +
            (topN.length === 0 ? '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);">Nenhum evento encontrado</td></tr>' : '') +
            '</tbody>' +
          '</table>' +
        '</div>' +
      '</div>';

    var userEntries = Object.keys(agg.byUser).map(function(k) { return { name: k, count: agg.byUser[k] }; })
      .sort(function(a, b) { return b.count - a.count; });
    var maxUserCount = userEntries.length > 0 ? userEntries[0].count : 1;

    var userHtml =
      '<div class="metrics-section">' +
        '<div class="metrics-section-title">Uso por usuario</div>' +
        '<div class="metrics-bars">' +
        userEntries.map(function(u) {
          var pct = Math.round((u.count / maxUserCount) * 100);
          return '<div class="metrics-bar-row">' +
            '<span class="metrics-bar-label">' + u.name + '</span>' +
            '<div class="metrics-bar-track"><div class="metrics-bar-fill" style="width:' + pct + '%"></div></div>' +
            '<span class="metrics-bar-value">' + u.count + '</span>' +
          '</div>';
        }).join("") +
        (userEntries.length === 0 ? '<div style="color:var(--text-muted);font-size:11px;padding:8px;">Nenhum dado</div>' : '') +
        '</div>' +
      '</div>';

    var catEntries = Object.keys(agg.byCategory).map(function(k) {
      var catName = k;
      for (var c = 0; c < _state.categories.length; c++) {
        if (_state.categories[c].id === k) { catName = _state.categories[c].name; break; }
      }
      return { id: k, name: catName, count: agg.byCategory[k] };
    }).sort(function(a, b) { return b.count - a.count; });
    var maxCatCount = catEntries.length > 0 ? catEntries[0].count : 1;

    var catHtml =
      '<div class="metrics-section">' +
        '<div class="metrics-section-title">Uso por categoria</div>' +
        '<div class="metrics-bars">' +
        catEntries.map(function(c) {
          var pct = Math.round((c.count / maxCatCount) * 100);
          var color = "var(--accent)";
          for (var i = 0; i < _state.categories.length; i++) {
            if (_state.categories[i].id === c.id) { color = _state.categories[i].color; break; }
          }
          return '<div class="metrics-bar-row">' +
            '<span class="metrics-bar-label">' + c.name + '</span>' +
            '<div class="metrics-bar-track"><div class="metrics-bar-fill" style="width:' + pct + '%;background:' + color + '"></div></div>' +
            '<span class="metrics-bar-value">' + c.count + '</span>' +
          '</div>';
        }).join("") +
        (catEntries.length === 0 ? '<div style="color:var(--text-muted);font-size:11px;padding:8px;">Nenhum dado</div>' : '') +
        '</div>' +
      '</div>';

    var dayKeys = Object.keys(agg.byDay).sort();
    var maxDayCount = 1;
    for (var dk = 0; dk < dayKeys.length; dk++) {
      if (agg.byDay[dayKeys[dk]] > maxDayCount) maxDayCount = agg.byDay[dayKeys[dk]];
    }

    var dayHtml =
      '<div class="metrics-section">' +
        '<div class="metrics-section-title">Volume por dia</div>' +
        '<div class="metrics-day-chart">' +
        dayKeys.map(function(day) {
          var count = agg.byDay[day];
          var h = Math.max(4, Math.round((count / maxDayCount) * 60));
          return '<div class="metrics-day-bar" title="' + _formatDateBR(day) + ': ' + count + ' usos">' +
            '<div class="metrics-day-bar-fill" style="height:' + h + 'px"></div>' +
            '<div class="metrics-day-label">' + day.slice(8) + '/' + day.slice(5, 7) + '</div>' +
          '</div>';
        }).join("") +
        (dayKeys.length === 0 ? '<div style="color:var(--text-muted);font-size:11px;padding:8px;">Nenhum dado</div>' : '') +
        '</div>' +
      '</div>';

    var exportHtml =
      '<div style="margin-top:8px;">' +
        '<button class="btn" onclick="exportEventsCSV(readEvents(metricsState.startDate,metricsState.endDate,{' +
          (metricsState.filterUserId ? 'userId:\'' + metricsState.filterUserId + '\',' : '') +
          (metricsState.filterCategory ? 'category:\'' + metricsState.filterCategory + '\',' : '') +
          (metricsState.filterType ? 'type:\'' + metricsState.filterType + '\'' : '') +
        '}))" style="width:100%;">' +
          '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>' +
          '</svg>' +
          'Exportar CSV' +
        '</button>' +
      '</div>';

    panel.innerHTML = filtersHtml + summaryHtml +
      '<div class="metrics-columns">' + topHtml + '<div>' + userHtml + catHtml + '</div></div>' +
      dayHtml + exportHtml;
  }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.MetricsManager = {
    init: function(stateRef, deps) {
      _state          = stateRef;
      _getStockFolder = deps.getStockFolder;
      _showToast      = deps.showToast;
      _toggleSettings = deps.toggleSettings;
      _cs             = deps.cs;
    },
    trackEvent:      trackEvent,
    readEvents:      readEvents,
    aggregateEvents: _aggregateEvents,
    exportEventsCSV: exportEventsCSV,
    toggleMetrics:   toggleMetrics,
    renderMetrics:   renderMetrics,
    formatDateBR:    _formatDateBR,
    metricsState:    metricsState
  };

  // Aliases globais para onclick no HTML
  window.trackEvent       = trackEvent;
  window.readEvents       = readEvents;
  window.aggregateEvents  = _aggregateEvents;
  window.exportEventsCSV  = exportEventsCSV;
  window.toggleMetrics    = toggleMetrics;
  window.closeMetricsModal = closeMetricsModal;
  window.renderMetrics    = renderMetrics;
  window.formatDateBR     = _formatDateBR;
  window.metricsState     = metricsState;
  window.openDatePicker   = openDatePicker;
  window.dpNavigate       = dpNavigate;
  window.dpSelectDay      = dpSelectDay;
  window.dpSelectToday    = dpSelectToday;
  window.closeDatePicker  = closeDatePicker;

})();

// Node.js exports para testes
if (typeof module !== "undefined") {
  module.exports = {
    _aggregateEvents: _aggregateEvents,
    _formatDateBR: _formatDateBR
  };
}
