// =============================================================================
// features/thumbnails.js — Geracao de thumbnails, worker pool e viewport observer
// =============================================================================

// Cache de thumbnails locais (sem hit no filesystem a cada re-render)
var thumbLookupCache = {};

// Formata duracao em segundos para "1:24" / "0:35"
function formatDuration(sec) {
  if (!sec || sec < 0) return "";
  var s = Math.round(sec);
  var m = Math.floor(s / 60);
  var rem = s % 60;
  return m + ":" + (rem < 10 ? "0" : "") + rem;
}

function getThumbnail(file) {
  if (thumbLookupCache[file.path] !== undefined) return thumbLookupCache[file.path];
  try {
    // 1) Sidecar: <dir>/<base>.png ou <dir>/thumbs/<base>.png
    var dir = path.dirname(file.path);
    var base = path.basename(file.path, path.extname(file.path));
    var thumbExts = [".png", ".jpg", ".jpeg", ".gif"];
    for (var i = 0; i < thumbExts.length; i++) {
      var thumbPath = path.join(dir, base + thumbExts[i]);
      if (fs.existsSync(thumbPath)) {
        var url = toFileURL(thumbPath);
        thumbLookupCache[file.path] = url;
        return url;
      }
      var thumbPath2 = path.join(dir, "thumbs", base + thumbExts[i]);
      if (fs.existsSync(thumbPath2)) {
        var url2 = toFileURL(thumbPath2);
        thumbLookupCache[file.path] = url2;
        return url2;
      }
    }
    // 2) Cache em disco gerado pelo FFmpeg em <stockFolder>/.cache/<hash>_thumb.jpg
    if (typeof FFmpegManager !== "undefined" && FFmpegManager.hashPath && FFmpegManager.getCacheDir) {
      var cacheThumb = path.join(FFmpegManager.getCacheDir(), FFmpegManager.hashPath(file.path) + "_thumb.jpg");
      if (fs.existsSync(cacheThumb)) {
        var url3 = toFileURL(cacheThumb);
        thumbLookupCache[file.path] = url3;
        thumbCache[file.path] = url3;  // sincroniza memoria com disco
        return url3;
      }
    }
  } catch (e) { Logger.warn("thumbnails", "Falha ao buscar thumb local", e.message); }
  thumbLookupCache[file.path] = null;
  return null;
}

// --- Worker pool de thumbs ---
var THUMB_CONCURRENCY = 2;
var thumbPoolActive = 0;

function pumpThumbPool() {
  if (!state.thumbQueueVisible) return;
  while (
    !thumbQueuePaused &&
    thumbPoolActive < THUMB_CONCURRENCY &&
    (state.thumbQueueVisible.length + state.thumbQueueRest.length > 0)
  ) {
    var f = state.thumbQueueVisible.length > 0
      ? state.thumbQueueVisible.shift()
      : state.thumbQueueRest.shift();
    if (!f) break;
    thumbPoolActive++;
    (function(file) {
      generateThumbFFmpeg(file.path, function(url) {
        thumbPoolActive--;
        state._thumbDone = (state._thumbDone || 0) + 1;
        if (url) {
          var el = document.querySelector('[data-filepath="' + CSS.escape(file.path) + '"] .thumbnail, [data-filepath="' + CSS.escape(file.path) + '"] .placeholder');
          if (el) {
            var img = document.createElement("img");
            img.className = "thumbnail";
            img.src = url;
            img.loading = "lazy";
            el.replaceWith(img);
          }
        }
        var statusEl = document.getElementById("statusText");
        var pending = state.thumbQueueVisible.length + state.thumbQueueRest.length + thumbPoolActive;
        if (statusEl) {
          statusEl.textContent = pending > 0
            ? "Gerando thumbs... " + state._thumbDone + "/" + state._thumbTotal
            : "Pronto";
        }
        pumpThumbPool();
      });
    })(f);
  }
  if (thumbQueuePaused && (state.thumbQueueVisible.length + state.thumbQueueRest.length > 0)) {
    var statusEl2 = document.getElementById("statusText");
    if (statusEl2) statusEl2.textContent = "Pausado (drag em andamento)";
  }
}

// IntersectionObserver: promove cards visiveis na viewport para a fila
// prioritaria, fazendo as primeiras telas se popularem antes do resto.
//
// Bug que corrigimos: antes procurava `document.getElementById("grid")`,
// mas o ID real do grid e `fileGrid` e o container scrollable e `gridContainer`.
// Resultado: o IO nunca observava nada e todos os assets caiam na fila normal
// sem priorizacao. Em pasta com 2000+ assets isso significa que a tela
// inicial demorava muito para popular thumbnails.
var _thumbIO = null;
function setupViewportObserver() {
  if (_thumbIO) { try { _thumbIO.disconnect(); } catch (e) { Logger.warn("thumbnails", "IO disconnect failed", e.message); } _thumbIO = null; }
  if (typeof IntersectionObserver === "undefined") return;
  var grid = document.getElementById("fileGrid");
  var container = document.getElementById("gridContainer");
  if (!grid) return;
  _thumbIO = new IntersectionObserver(function(entries) {
    var promoted = false;
    for (var i = 0; i < entries.length; i++) {
      if (!entries[i].isIntersecting) continue;
      var rel = entries[i].target.getAttribute("data-rel");
      if (!rel) continue;
      for (var j = 0; j < state.thumbQueueRest.length; j++) {
        if (toRelPath(state.thumbQueueRest[j].path) === rel) {
          state.thumbQueueVisible.unshift(state.thumbQueueRest.splice(j, 1)[0]);
          promoted = true;
          break;
        }
      }
    }
    if (promoted) pumpThumbPool();
  }, { root: container || null, rootMargin: "200px" });
  var items = grid.querySelectorAll(".grid-item");
  for (var k = 0; k < items.length; k++) _thumbIO.observe(items[k]);
}

// --- refreshFiles: scan + kick off thumb/resolution queues ---
function refreshFiles() {
  var folder = getStockFolder();
  if (state.customFolder && !fs.existsSync(state.customFolder)) {
    var invalidFolder = state.customFolder;
    state.customFolder = null;
    saveState();
    folder = getStockFolder();
    var fp = document.getElementById("stockFolderPath");
    if (fp) fp.textContent = folder;
    showToast("Pasta \"" + invalidFolder + "\" nao encontrada. Revertendo para pasta padrao.");
  }
  state.files = scanFolder(folder);
  renderAll();
  updateCloudIndicator(folder);
  showToast(state.files.length + " arquivos encontrados");
  document.getElementById("statusText").textContent = "Atualizado";
  startFolderWatcher(folder);

  // Pre-generate ffmpeg thumbnails + detect resolutions in background
  if (findFFmpeg()) {
    var queue = [];
    var resQueue = [];
    for (var i = 0; i < state.files.length; i++) {
      var f = state.files[i];
      if (f.cloudOnly) continue;
      if (f.type === "video") {
        if (!thumbCache[f.path]) queue.push(f);
        if (!resolutionCache[f.path]) resQueue.push(f);
      } else if (f.type === "image" && !resolutionCache[f.path]) {
        resQueue.push(f);
      }
    }

    function processResQueue(idx) {
      if (idx >= resQueue.length) return;
      var rf = resQueue[idx];
      if (rf.type === "image") {
        var img = new Image();
        img.onload = function() {
          resolutionCache[rf.path] = img.naturalWidth + "x" + img.naturalHeight;
          updateResBadge(rf.path, resolutionCache[rf.path]);
          processResQueue(idx + 1);
        };
        img.onerror = function() { processResQueue(idx + 1); };
        img.src = toFileURL(rf.path);
      } else {
        getVideoResolution(rf.path, function(res) {
          if (res) updateResBadge(rf.path, res);
          // Pega duracao em sequencia (mesmo ffprobe ja foi achado)
          if (typeof FFmpegManager !== "undefined" && FFmpegManager.durationCache[rf.path] === undefined) {
            FFmpegManager.getVideoDuration(rf.path, function(dur) {
              if (dur) updateDurationBadge(rf.path, dur);
              processResQueue(idx + 1);
            });
          } else {
            processResQueue(idx + 1);
          }
        });
      }
    }

    function updateResBadge(filePath, _res) {
      rebuildMetaLine(filePath);
    }

    function updateDurationBadge(filePath, _durSec) {
      rebuildMetaLine(filePath);
    }

    // Reconstroi a meta-line (FORMATO | RESOLUCAO | DURACAO) usando o
    // estado atual dos caches. Chamado quando resolucao ou duracao chega.
    function rebuildMetaLine(filePath) {
      var card = document.querySelector('[data-filepath="' + CSS.escape(filePath) + '"]');
      if (!card) return;
      var meta = card.querySelector("[data-meta]");
      if (!meta) return;
      var f = null;
      for (var i = 0; i < state.files.length; i++) {
        if (state.files[i].path === filePath) { f = state.files[i]; break; }
      }
      if (!f) return;
      var parts = [f.ext.toUpperCase()];
      var r = resolutionCache[filePath];
      if (r) parts.push(r);
      var d = (typeof FFmpegManager !== "undefined" && FFmpegManager.durationCache)
        ? FFmpegManager.durationCache[filePath] : null;
      if (d) parts.push(formatDuration(d));
      meta.innerHTML = parts.map(function(p) { return '<span>' + p + '</span>'; })
        .join('<span class="grid-item-meta-sep">|</span>');
    }

    state.thumbQueueVisible = [];
    state.thumbQueueRest = queue.slice();
    state._thumbTotal = queue.length;
    state._thumbDone = 0;
    pumpThumbPool();
    setupViewportObserver();
    processResQueue(0);
  }
}
