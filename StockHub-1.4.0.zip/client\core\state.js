// =============================================================================
// core/state.js — Estado global e persistencia do StockHub
// =============================================================================

var state = {
  files: [],
  categories: DEFAULT_CATEGORIES.slice(),
  activeCategory: "all",
  activeFormat: "all",
  searchQuery: "",
  gridSize: 110,
  showSettings: false,
  fileCategories: {},
  customFolder: null,
  autoCategories: true,
  deletedCategoryIds: [],
  favoriteFiles: {},
  userId: null,
  stagingFolder: null,
  lastSeenVersion: null,
  lastUpdateDismissedAt: null,
  updateDismissedVersion: null,
  welcomed: false,
  selectedFiles: {},
  fileTags: {},
  ffmpegPath: null,
  ffmpegNoticed: false,
  previewHoverEnabled: true,
  sortBy: "name",
  sortOrder: "asc",
  sidebarCollapsed: false,
};

function loadState() {
  try {
    var filePath = getStoragePath();
    if (fs.existsSync(filePath)) {
      var data = JSON.parse(fs.readFileSync(filePath, "utf-8"));
      if (data.categories) state.categories = data.categories;
      if (data.gridSize) state.gridSize = data.gridSize;
      if (data.fileCategories) state.fileCategories = data.fileCategories;
      if (data.customFolder) {
        if (fs.existsSync(data.customFolder)) {
          state.customFolder = data.customFolder;
        } else {
          Logger.warn("state", "Pasta personalizada nao encontrada, revertendo para padrao: " + data.customFolder);
          state.customFolder = null;
        }
      }
      if (data.autoCategories !== undefined) state.autoCategories = data.autoCategories;
      if (data.deletedCategoryIds) state.deletedCategoryIds = data.deletedCategoryIds;
      if (data.userId) state.userId = data.userId;
      if (data.sidebarWidth) state.sidebarWidth = data.sidebarWidth;
      if (data.favoriteFiles) state.favoriteFiles = data.favoriteFiles;
      if (data.stagingFolder) state.stagingFolder = data.stagingFolder;
      if (data.lastSeenVersion) state.lastSeenVersion = data.lastSeenVersion;
      if (data.lastUpdateDismissedAt) state.lastUpdateDismissedAt = data.lastUpdateDismissedAt;
      if (data.updateDismissedVersion) state.updateDismissedVersion = data.updateDismissedVersion;
      if (data.welcomed) state.welcomed = data.welcomed;
      if (data.fileTags) state.fileTags = data.fileTags;
      if (data.ffmpegPath) state.ffmpegPath = data.ffmpegPath;
      if (data.ffmpegNoticed) state.ffmpegNoticed = data.ffmpegNoticed;
      if (data.previewHoverEnabled !== undefined) state.previewHoverEnabled = data.previewHoverEnabled;
      if (data.sortBy) state.sortBy = data.sortBy;
      if (data.sortOrder) state.sortOrder = data.sortOrder;
      if (data.sidebarCollapsed) state.sidebarCollapsed = data.sidebarCollapsed;
      state.dataSchemaVersion = data.dataSchemaVersion || 1;

      // Migracao one-shot: chaves absolutas -> chaves relativas a pasta de stock.
      if (state.dataSchemaVersion < 2) {
        var stockFolder = getStockFolder();
        state.fileCategories = migrateAbsoluteKeysToRelative(state.fileCategories, stockFolder);
        state.favoriteFiles = migrateAbsoluteKeysToRelative(state.favoriteFiles, stockFolder);
        state.dataSchemaVersion = 2;
        try { saveState(); } catch (e) { Logger.warn("state", "Falha ao salvar migracao", e.message); }
        Logger.info("state", "Migrado stockhub-data.json para schema v2 (paths relativos)");
      }
    }
  } catch (e) {
    Logger.warn("state", "Falha ao carregar state", e.message);
  }
}

// _saveStateImmediate — escreve no disco imediatamente (sem debounce). Usado
// internamente pelo wrapper debounced e pelo flush em beforeunload.
function _saveStateImmediate() {
  try {
    var filePath = getStoragePath();
    var dataDir = path.dirname(filePath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(filePath, JSON.stringify({
      dataSchemaVersion: 2,
      categories: state.categories,
      gridSize: state.gridSize,
      fileCategories: state.fileCategories,
      customFolder: state.customFolder,
      autoCategories: state.autoCategories,
      deletedCategoryIds: state.deletedCategoryIds,
      favoriteFiles: state.favoriteFiles,
      userId: state.userId,
      sidebarWidth: state.sidebarWidth,
      stagingFolder: state.stagingFolder,
      lastSeenVersion: state.lastSeenVersion,
      lastUpdateDismissedAt: state.lastUpdateDismissedAt,
      updateDismissedVersion: state.updateDismissedVersion,
      welcomed: state.welcomed,
      fileTags: state.fileTags,
      ffmpegPath: state.ffmpegPath,
      ffmpegNoticed: state.ffmpegNoticed,
      previewHoverEnabled: state.previewHoverEnabled,
      sortBy: state.sortBy,
      sortOrder: state.sortOrder,
      sidebarCollapsed: state.sidebarCollapsed,
    }), "utf-8");
  } catch (e) {
    Logger.error("state", "Falha ao salvar state", e.message);
  }
}

// saveState — wrapper com debounce de 500ms. Em uso real (drag, favorito,
// trocar categoria) o usuario faz dezenas de operacoes seguidas; sem debounce
// estamos gravando 1-2 MB no disco a cada uma. Com debounce, agrupa em uma
// unica escrita 500ms apos a ultima alteracao.
var _saveStateTimer = null;
function saveState() {
  if (_saveStateTimer) clearTimeout(_saveStateTimer);
  _saveStateTimer = setTimeout(function() {
    _saveStateTimer = null;
    _saveStateImmediate();
  }, 500);
}

// flushSaveState — forca escrita imediata se houver pendente. Chamado em
// beforeunload para garantir que nada se perca quando o painel fecha.
function flushSaveState() {
  if (_saveStateTimer) {
    clearTimeout(_saveStateTimer);
    _saveStateTimer = null;
    _saveStateImmediate();
  }
}

// Garantia em fecha-painel: o listener em features/file-scanner.js para o
// watcher; aqui adicionamos o flush.
if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", function() { flushSaveState(); });
}
