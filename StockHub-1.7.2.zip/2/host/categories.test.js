// =============================================================================
// categories.test.js — Testes para core/categories.js (toCategoryId)
// Roda com: node host/categories.test.js
// =============================================================================

var assert = require("assert");
var toCategoryId = require("../client/core/categories.js").toCategoryId;

var passed = 0;
var failed = 0;

function test(name, fn) {
  try { fn(); passed++; console.log("  PASS: " + name); }
  catch (e) { failed++; console.error("  FAIL: " + name + " — " + e.message); }
}

console.log("\n=== core/categories tests ===\n");

test("toCategoryId: converte para lowercase slug", function() {
  assert.strictEqual(toCategoryId("Music"), "music");
});

test("toCategoryId: substitui espacos por hifens", function() {
  assert.strictEqual(toCategoryId("Sound Effects"), "sound-effects");
});

test("toCategoryId: remove caracteres especiais", function() {
  assert.strictEqual(toCategoryId("My Cat!@#"), "my-cat---");
});

test("toCategoryId: preserva numeros", function() {
  assert.strictEqual(toCategoryId("Pack 2024"), "pack-2024");
});

test("toCategoryId: vazio para input vazio/null/undefined", function() {
  assert.strictEqual(toCategoryId(""), "");
  assert.strictEqual(toCategoryId(null), "");
  assert.strictEqual(toCategoryId(undefined), "");
});

test("toCategoryId: input ja em lowercase permanece igual", function() {
  assert.strictEqual(toCategoryId("sfx"), "sfx");
});

test("toCategoryId: hifens existentes sao preservados", function() {
  assert.strictEqual(toCategoryId("my-category"), "my-category");
});

test("toCategoryId: aceita Number como entrada", function() {
  assert.strictEqual(toCategoryId(2024), "2024");
});

console.log("\nTotal: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
if (failed > 0) process.exit(1);
