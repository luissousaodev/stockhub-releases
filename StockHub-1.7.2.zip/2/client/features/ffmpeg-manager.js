// =============================================================================
// features/ffmpeg-manager.js — Modulo de FFmpeg do StockHub
//
// Responsabilidades:
//   - Localizar binarios ffmpeg/ffprobe (estrategias em ordem; sync ou async)
//   - Gerar thumbnails estaticos (JPG, 1 frame) e frame-strip (sprite Nx1)
//   - Obter duracao e resolucao via ffprobe (1 chamada combinada)
//   - Cachear (LRU) em memoria + cache permanente em disco
//   - Logar todos os pontos de falha em Logger.warn
//
// Dependencias externas (recebidas via init):
//   - getStockFolder, toRelPath, toFileURL
// =============================================================================

// --- Pure helpers (testaveis fora da IIFE) -----------------------------------

function _hashDjb2(str) {
  if (!str) return "0";
  var h = 5381;
  for (var i = 0; i < str.length; i++) {
    h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  }
  var base = String(str).replace(/[^a-zA-Z0-9]/g, "_");
  var tail = base.substring(Math.max(0, base.length - 60));
  return tail + "_" + (h >>> 0).toString(16);
}

function _pickFrameCount(duration) {
  switch (true) {
    case (!duration || duration < 1): return 3;
    case (duration <= 5):  return 3;
    case (duration <= 15): return 5;
    case (duration <= 60): return 8;
    default:               return 12;
  }
}

// Valida shape do sidecar de metadata { v, duration, width?, height? }.
// Retorna objeto sanitizado (sem campos extras) ou null. width/height sao
// opcionais mas em par — ou ambos validos, ou nenhum dos dois.
function _validateMeta(obj) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return null;
  if (obj.v !== 1) return null;
  if (typeof obj.duration !== "number" || isNaN(obj.duration) || obj.duration <= 0) return null;

  var out = { v: 1, duration: obj.duration };

  var hasW = obj.width !== undefined;
  var hasH = obj.height !== undefined;
  if (hasW !== hasH) return null;
  if (hasW) {
    if (typeof obj.width  !== "number" || isNaN(obj.width)  || obj.width  <= 0) return null;
    if (typeof obj.height !== "number" || isNaN(obj.height) || obj.height <= 0) return null;
    out.width = obj.width;
    out.height = obj.height;
  }
  return out;
}

// LRU bounded em memoria. Cache em disco eh a fonte da verdade — esta camada
// so acelera repeticao na sessao. API: get/has/set/del. .set retorna evicted.
function _makeLRU(limit) {
  var map = {}, keys = [];
  return {
    get: function(k) { return map[k]; },
    has: function(k) { return Object.prototype.hasOwnProperty.call(map, k); },
    set: function(k, v) {
      if (Object.prototype.hasOwnProperty.call(map, k)) {
        // refresh ordem
        var idx = keys.indexOf(k);
        if (idx >= 0) keys.splice(idx, 1);
      }
      map[k] = v;
      keys.push(k);
      if (keys.length > limit) {
        var ev = keys.shift();
        delete map[ev];
      }
    },
    del: function(k) { delete map[k]; var i = keys.indexOf(k); if (i >= 0) keys.splice(i, 1); },
    size: function() { return keys.length; },
    clear: function() { map = {}; keys = []; }
  };
}

// --- IIFE — runtime browser/CEP ---------------------------------------------

if (typeof window !== "undefined") (function() {
  var _fs    = require("fs");
  var _path  = require("path");
  var _child = require("child_process");
  var _isWin = process.platform === "win32";

  var _getStockFolder = null;
  var _toRelPath      = null;
  var _toFileURL      = null;

  // Caches LRU. Limites cobrem uso comum sem cresc imento infinito.
  var thumbCache      = _makeLRU(2000);
  var spriteCache     = _makeLRU(500);
  var resolutionCache = _makeLRU(5000);
  var durationCache   = _makeLRU(5000);

  // failedPreviews: { [filePath + ":" + kind]: timestamp } — evita retry agressivo
  // de assets que falharam recentemente (5min de cooldown).
  var failedPreviews = {};
  var FAIL_COOLDOWN_MS = 5 * 60 * 1000;

  var ffmpegPath  = null;
  var ffprobePath = null;
  var activeThumbChildren = [];

  // -------------------------------------------------------------------------
  // Cache em disco
  // -------------------------------------------------------------------------

  function _getSourceCacheKey() {
    return (typeof getStockFolderCacheKey === "function")
      ? getStockFolderCacheKey(_getStockFolder())
      : _hashDjb2(_getStockFolder());
  }

  function getCacheDir() {
    var root = (typeof getAppCacheRoot === "function")
      ? getAppCacheRoot()
      : _path.join(_getStockFolder(), ".cache");
    return _path.join(root, "previews", _getSourceCacheKey());
  }

  function ensureCacheDir() {
    var dir = getCacheDir();
    try { if (!_fs.existsSync(dir)) _fs.mkdirSync(dir, { recursive: true }); }
    catch (e) { Logger.warn("ffmpeg", "ensureCacheDir falhou", e.message); }
    return dir;
  }

  function hashPath(absPath) {
    return _hashDjb2(_getSourceCacheKey() + "__" + _toRelPath(absPath));
  }

  // -------------------------------------------------------------------------
  // Localizar FFmpeg — estrategias em ordem (sync: existsSync; async: which)
  // -------------------------------------------------------------------------

  function _setFFmpegPath(p) {
    ffmpegPath = p;
    var ffprobeBin = _isWin ? "ffprobe.exe" : "ffprobe";
    var probe = _path.join(_path.dirname(p), ffprobeBin);
    ffprobePath = _fs.existsSync(probe) ? probe : null;
    if (!ffprobePath) Logger.warn("ffmpeg", "ffprobe nao encontrado ao lado de " + p);
  }

  function _findBundled() {
    var p = _path.join(__dirname, "..", "..", "ffmpeg", _isWin ? "ffmpeg.exe" : "ffmpeg");
    return _fs.existsSync(p) ? p : null;
  }

  function _findUserPath() {
    var p = window.state && window.state.ffmpegPath;
    return (p && _fs.existsSync(p)) ? p : null;
  }

  function _findCommonLocations() {
    var locs;
    if (_isWin) {
      var localAppData = process.env.LOCALAPPDATA || "";
      var userProfile = process.env.USERPROFILE || "";
      locs = [
        "C:\\ffmpeg\\bin\\ffmpeg.exe",
        "C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe",
        "C:\\Program Files (x86)\\ffmpeg\\bin\\ffmpeg.exe",
        _path.join(localAppData, "ffmpeg", "bin", "ffmpeg.exe"),
        _path.join(userProfile, "ffmpeg", "bin", "ffmpeg.exe"),
        _path.join(userProfile, "scoop", "shims", "ffmpeg.exe")
      ];
      try {
        var wingetPkgs = _path.join(localAppData, "Microsoft", "WinGet", "Packages");
        if (_fs.existsSync(wingetPkgs)) {
          var pkgs = _fs.readdirSync(wingetPkgs);
          for (var w = 0; w < pkgs.length; w++) {
            if (pkgs[w].toLowerCase().indexOf("ffmpeg") < 0) continue;
            var subs = _fs.readdirSync(_path.join(wingetPkgs, pkgs[w]));
            for (var s = 0; s < subs.length; s++) {
              locs.unshift(_path.join(wingetPkgs, pkgs[w], subs[s], "bin", "ffmpeg.exe"));
            }
          }
        }
      } catch (e) { Logger.warn("ffmpeg", "WinGet scan failed", e.message); }
    } else {
      locs = ["/usr/local/bin/ffmpeg", "/opt/homebrew/bin/ffmpeg", "/usr/bin/ffmpeg", "/opt/local/bin/ffmpeg"];
    }
    for (var i = 0; i < locs.length; i++) {
      if (locs[i] && _fs.existsSync(locs[i])) return locs[i];
    }
    return null;
  }

  // findFFmpeg sync — usado por callers que ja estao em contexto async (callbacks
  // de hover/thumb). NAO usado no boot, pra evitar execSync bloquear.
  function findFFmpeg() {
    if (ffmpegPath) return ffmpegPath;
    var p = _findBundled() || _findUserPath() || _findCommonLocations();
    if (p) { _setFFmpegPath(p); Logger.info("ffmpeg", "Resolvido em " + ffmpegPath); return ffmpegPath; }
    return null;
  }

  // findFFmpegAsync — usado no boot. Tenta as 3 estrategias sync rapidas; se
  // nada bate, faz `which ffmpeg` async (sem bloquear UI).
  function findFFmpegAsync(callback) {
    if (ffmpegPath) return callback(ffmpegPath);
    var p = _findBundled() || _findUserPath() || _findCommonLocations();
    if (p) { _setFFmpegPath(p); Logger.info("ffmpeg", "Resolvido em " + ffmpegPath); return callback(ffmpegPath); }
    var cmd = _isWin ? "where ffmpeg" : "which ffmpeg";
    _child.exec(cmd, { timeout: 5000 }, function(err, stdout) {
      if (!err && stdout) {
        var first = stdout.trim().split("\n")[0];
        if (first && _fs.existsSync(first)) {
          _setFFmpegPath(first);
          Logger.info("ffmpeg", "Resolvido via PATH em " + ffmpegPath);
          return callback(ffmpegPath);
        }
      }
      Logger.warn("ffmpeg", "FFmpeg nao encontrado em nenhuma estrategia");
      callback(null);
    });
  }

  // -------------------------------------------------------------------------
  // Timeout adaptativo + cooldown de falha
  // -------------------------------------------------------------------------

  // Pasta cloud (Drive/OneDrive) tem latencia de I/O alta — timeout maior.
  function _previewTimeout(file, kind) {
    var isCloud = !!(file && file.cloudOnly);
    if (isCloud) return kind === "thumb" ? 45000 : 60000;
    return kind === "thumb" ? 15000 : 30000;
  }

  function _markFailed(filePath, kind) {
    failedPreviews[filePath + ":" + kind] = Date.now();
  }

  function _isInCooldown(filePath, kind) {
    var t = failedPreviews[filePath + ":" + kind];
    if (!t) return false;
    if (Date.now() - t > FAIL_COOLDOWN_MS) { delete failedPreviews[filePath + ":" + kind]; return false; }
    return true;
  }

  // Limpa cooldowns ao apertar "Atualizar" — user explicitamente quer retry.
  function clearFailedPreviews() { failedPreviews = {}; }

  // -------------------------------------------------------------------------
  // Metadata sidecar: <cacheDir>/<hash>_meta.json
  // Lifecycle independente do _strip.json — meta sobrevive enquanto o
  // arquivo existir; sprite depende de duration (entao depende de meta),
  // mas o reverso nao se aplica.
  // -------------------------------------------------------------------------

  function _readMetaSidecar(filePath) {
    try {
      var metaFile = _path.join(getCacheDir(), hashPath(filePath) + "_meta.json");
      if (!_fs.existsSync(metaFile)) return null;  // silencioso — boot 1 cai aqui
      try {
        var raw = _fs.readFileSync(metaFile, "utf-8");
        var validated = _validateMeta(JSON.parse(raw));
        if (!validated) {
          Logger.warn("ffmpeg", "meta sidecar invalido — vai regerar", filePath);
          return null;
        }
        return validated;
      } catch (e) {
        Logger.warn("ffmpeg", "meta sidecar parse falhou — vai regerar", e.message + " | " + filePath);
        return null;
      }
    } catch (eOuter) {
      Logger.warn("ffmpeg", "_readMetaSidecar guard", eOuter.message + " | " + String(filePath));
      return null;
    }
  }

  // Fire-and-forget. Nao bloqueia callback de getVideoMeta. Nao throws.
  // mkdirSync defensivo cobre disco read-only, pasta apagada externamente,
  // race com clearCache, etc.
  function _writeMetaSidecar(filePath, meta) {
    try {
      var dir = getCacheDir();
      _fs.mkdirSync(dir, { recursive: true });
      var metaFile = _path.join(dir, hashPath(filePath) + "_meta.json");
      _fs.writeFile(metaFile, JSON.stringify(meta), function(err) {
        if (err) Logger.warn("ffmpeg", "writeMetaSidecar falhou", err.message + " | " + filePath);
      });
    } catch (e) {
      Logger.warn("ffmpeg", "writeMetaSidecar throw", e.message + " | " + filePath);
    }
  }

  // -------------------------------------------------------------------------
  // Metadata (1 ffprobe combinado, L1 LRU → L2 sidecar disco → L3 ffprobe)
  // -------------------------------------------------------------------------

  function getVideoMeta(filePath, callback) {
    // L1: cache em memoria
    if (durationCache.has(filePath) && resolutionCache.has(filePath)) {
      return callback(null, {
        duration:   durationCache.get(filePath),
        resolution: resolutionCache.get(filePath)
      });
    }

    // L2: sidecar em disco
    var disk = _readMetaSidecar(filePath);
    if (disk) {
      durationCache.set(filePath, disk.duration);
      if (disk.width && disk.height) {
        // Sidecar completo — early-return sem rodar ffprobe
        var resStr = disk.width + "x" + disk.height;
        resolutionCache.set(filePath, resStr);
        return callback(null, { duration: disk.duration, resolution: resStr });
      }
      // Sidecar parcial: durationCache populado, cai pro ffprobe pra
      // tentar dimensions. Se ffprobe agora conseguir, reescreve completo;
      // se nao (audio puro com .mp4 wrapper), mantem parcial e re-spawn
      // na proxima — trade-off aceitavel pra esses arquivos borderline.
    }

    // L3: ffprobe
    if (!ffprobePath) {
      Logger.warn("ffmpeg", "getVideoMeta sem ffprobe", filePath);
      return callback(null, { duration: null, resolution: null });
    }
    _child.execFile(ffprobePath, [
      "-v", "error",
      "-select_streams", "v:0",
      "-show_entries", "format=duration:stream=width,height",
      "-of", "json",
      filePath
    ], { timeout: 10000 }, function(err, stdout) {
      if (err) {
        Logger.warn("ffmpeg", "ffprobe falhou", err.message + " | " + filePath);
        return callback(null, { duration: null, resolution: null });
      }
      try {
        var data = JSON.parse(stdout);
        var dur = parseFloat(data.format && data.format.duration);
        var s = data.streams && data.streams[0];
        var width  = (s && s.width)  || null;
        var height = (s && s.height) || null;
        var durVal = (!isNaN(dur) && dur > 0) ? dur : null;
        var resolution = (width && height) ? (width + "x" + height) : null;

        durationCache.set(filePath, durVal);
        resolutionCache.set(filePath, resolution);

        // Persiste sidecar so se temos duration valida. Dimensions opcionais.
        // Failures totais (dur null) nao escrevem — cooldown trata retry.
        if (durVal !== null) {
          var sidecarObj = { v: 1, duration: durVal };
          if (width && height) {
            sidecarObj.width = width;
            sidecarObj.height = height;
          }
          _writeMetaSidecar(filePath, sidecarObj);
        }

        callback(null, { duration: durVal, resolution: resolution });
      } catch (e) {
        Logger.warn("ffmpeg", "ffprobe parse falhou", e.message + " | " + filePath);
        callback(null, { duration: null, resolution: null });
      }
    });
  }

  function getVideoDuration(filePath, callback) {
    if (durationCache.has(filePath)) return callback(durationCache.get(filePath));
    getVideoMeta(filePath, function(_e, m) { callback(m ? m.duration : null); });
  }

  function getVideoResolution(filePath, callback) {
    if (resolutionCache.has(filePath)) return callback(resolutionCache.get(filePath));
    getVideoMeta(filePath, function(_e, m) { callback(m ? m.resolution : null); });
  }

  // -------------------------------------------------------------------------
  // Thumbnail estatico (1 frame)
  // -------------------------------------------------------------------------

  function generateThumbFFmpeg(filePath, callback) {
    var ffmpeg = findFFmpeg();
    if (!ffmpeg) { callback(null); return; }
    if (_isInCooldown(filePath, "thumb")) { callback(null); return; }

    var cacheDir = ensureCacheDir();
    var hash = hashPath(filePath);
    var thumbFile = _path.join(cacheDir, hash + "_thumb.jpg");

    if (_fs.existsSync(thumbFile)) {
      var url = _toFileURL(thumbFile);
      thumbCache.set(filePath, url);
      callback(url);
      return;
    }

    // Pega meta primeiro (1 ffprobe; 0 cost se ja cacheado) pra escolher seekTime
    getVideoMeta(filePath, function(_err, meta) {
      var duration = meta && meta.duration;
      var seekTime = duration ? Math.min(3, duration * 0.3) : 0;
      var hwAccel = _isWin ? [] : ["-hwaccel", "auto"];
      var args = ["-ss", String(seekTime)].concat(hwAccel).concat([
        "-i", filePath,
        "-vframes", "1",
        "-q:v", "4",
        "-vf", "scale=240:-1",
        "-y", thumbFile
      ]);
      var fileObj = { path: filePath, cloudOnly: window.state && _isCloudOnly(filePath) };
      var timeout = _previewTimeout(fileObj, "thumb");
      var proc = _child.execFile(ffmpeg, args, { timeout: timeout }, function(err) {
        var idx = activeThumbChildren.indexOf(proc);
        if (idx >= 0) activeThumbChildren.splice(idx, 1);
        if (err || !_fs.existsSync(thumbFile)) {
          var msg = err ? err.message : "arquivo nao gerado";
          Logger.warn("ffmpeg", "thumb falhou (" + msg + ")", filePath);
          _markFailed(filePath, "thumb");
          callback(null);
          return;
        }
        var url2 = _toFileURL(thumbFile);
        thumbCache.set(filePath, url2);
        if (typeof window.updateThumbHashSet === "function") window.updateThumbHashSet(hash, thumbFile);
        callback(url2);
      });
      activeThumbChildren.push(proc);
    });
  }

  // Helper interno: descobre cloudOnly via state.files (lookup) — usado quando
  // generateThumbFFmpeg eh chamado fora do contexto da fila de thumbnails.
  function _isCloudOnly(filePath) {
    var files = (window.state && window.state.files) || [];
    for (var i = 0; i < files.length; i++) {
      if (files[i].path === filePath) return !!files[i].cloudOnly;
    }
    return false;
  }

  // -------------------------------------------------------------------------
  // Frame-strip (sprite Nx1) — preview animado em hover
  // -------------------------------------------------------------------------

  function generateFrameStripFFmpeg(filePath, callback) {
    if (spriteCache.has(filePath)) { callback(spriteCache.get(filePath)); return; }
    var ffmpeg = findFFmpeg();
    if (!ffmpeg) { callback(null); return; }
    if (_isInCooldown(filePath, "sprite")) { callback(null); return; }

    var cacheDir = ensureCacheDir();
    var hash = hashPath(filePath);
    var stripFile = _path.join(cacheDir, hash + "_strip.jpg");
    var metaFile  = _path.join(cacheDir, hash + "_strip.json");

    if (_fs.existsSync(stripFile) && _fs.existsSync(metaFile)) {
      try {
        var meta = JSON.parse(_fs.readFileSync(metaFile, "utf-8"));
        var sprite = {
          url: _toFileURL(stripFile),
          frames: meta.frames, frameWidth: meta.frameWidth, frameHeight: meta.frameHeight
        };
        spriteCache.set(filePath, sprite);
        callback(sprite);
        return;
      } catch (e) { Logger.warn("ffmpeg", "sprite meta corrompido — regerando", filePath); }
    }

    getVideoMeta(filePath, function(_err, vm) {
      var duration = (vm && vm.duration) || 0;
      var n = _pickFrameCount(duration);
      var fpsExpr = (duration > 0)
        ? "fps=" + n + "/" + duration.toFixed(3)
        : "select='not(mod(n\\," + Math.max(1, Math.floor(30 / n)) + "))'";
      var vf = fpsExpr + ",scale=320:-2,tile=" + n + "x1";
      var args = ["-i", filePath, "-vf", vf, "-frames:v", "1", "-q:v", "5", "-y", stripFile];
      var fileObj = { path: filePath, cloudOnly: _isCloudOnly(filePath) };
      var timeout = _previewTimeout(fileObj, "sprite");
      var proc = _child.execFile(ffmpeg, args, { timeout: timeout }, function(err) {
        var idx = activeThumbChildren.indexOf(proc);
        if (idx >= 0) activeThumbChildren.splice(idx, 1);
        if (err || !_fs.existsSync(stripFile)) {
          var msg = err ? err.message : "arquivo nao gerado";
          Logger.warn("ffmpeg", "sprite falhou (" + msg + ")", filePath);
          _markFailed(filePath, "sprite");
          callback(null);
          return;
        }
        var sprite = { url: _toFileURL(stripFile), frames: n, frameWidth: 320, frameHeight: 0 };
        spriteCache.set(filePath, sprite);
        try { _fs.writeFileSync(metaFile, JSON.stringify({ frames: n, frameWidth: 320, frameHeight: 0 })); }
        catch (e) { Logger.warn("ffmpeg", "writeFileSync sprite meta falhou", e.message); }
        callback(sprite);
      });
      activeThumbChildren.push(proc);
    });
  }

  // -------------------------------------------------------------------------
  // Process management + cache disk lookup
  // -------------------------------------------------------------------------

  function killActiveThumbChildren() {
    for (var i = 0; i < activeThumbChildren.length; i++) {
      try { activeThumbChildren[i].kill("SIGKILL"); } catch (e) { Logger.warn("ffmpeg", "kill thumb child failed", e.message); }
    }
    activeThumbChildren = [];
  }

  function clearCaches() {
    thumbCache.clear();
    spriteCache.clear();
    resolutionCache.clear();
    durationCache.clear();
    failedPreviews = {};
  }

  function buildThumbHashSet() {
    var cacheDir = getCacheDir();
    var set = {};
    try {
      if (_fs.existsSync(cacheDir)) {
        var files = _fs.readdirSync(cacheDir);
        for (var i = 0; i < files.length; i++) {
          if (files[i].endsWith("_thumb.jpg")) {
            set[files[i].replace("_thumb.jpg", "")] = _path.join(cacheDir, files[i]);
          }
        }
      }
    } catch (e) { Logger.warn("ffmpeg", "buildThumbHashSet falhou", e.message); }
    return set;
  }

  function resetFFmpegLookup() { ffmpegPath = null; ffprobePath = null; }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.FFmpegManager = {
    init: function(deps) {
      _getStockFolder = deps.getStockFolder;
      _toRelPath      = deps.toRelPath;
      _toFileURL      = deps.toFileURL;
    },
    findFFmpeg:               findFFmpeg,
    findFFmpegAsync:          findFFmpegAsync,
    getVideoDuration:         getVideoDuration,
    getVideoResolution:       getVideoResolution,
    generateThumbFFmpeg:      generateThumbFFmpeg,
    generateFrameStripFFmpeg: generateFrameStripFFmpeg,
    killActiveThumbChildren:  killActiveThumbChildren,
    getCacheDir:              getCacheDir,
    ensureCacheDir:           ensureCacheDir,
    hashPath:                 hashPath,
    clearCaches:              clearCaches,
    clearFailedPreviews:      clearFailedPreviews,
    buildThumbHashSet:        buildThumbHashSet,
    resetFFmpegLookup:        resetFFmpegLookup,
    thumbCache:               thumbCache,
    spriteCache:              spriteCache,
    resolutionCache:          resolutionCache,
    durationCache:            durationCache,
    _makeLRU:                 _makeLRU
  };

  // Aliases globais — preservados para callers existentes
  window.findFFmpeg               = findFFmpeg;
  window.findFFmpegAsync          = findFFmpegAsync;
  window.getVideoDuration         = getVideoDuration;
  window.getVideoResolution       = getVideoResolution;
  window.generateThumbFFmpeg      = generateThumbFFmpeg;
  window.generateFrameStripFFmpeg = generateFrameStripFFmpeg;
  window.killActiveThumbChildren  = killActiveThumbChildren;
  window.getCacheDir              = getCacheDir;
  window.ensureCacheDir           = ensureCacheDir;
  window.hashPath                 = hashPath;
  window.resetFFmpegLookup        = resetFFmpegLookup;
  window.thumbCache               = thumbCache;
  window.resolutionCache          = resolutionCache;
  window.durationCache            = durationCache;

})();

// Node.js exports para testes
if (typeof module !== "undefined") {
  module.exports = {
    _hashDjb2: _hashDjb2,
    _pickFrameCount: _pickFrameCount,
    _makeLRU: _makeLRU,
    _validateMeta: _validateMeta
  };
}
