// =============================================================================
// features/project-assets.js - Copia assets usados para a pasta do projeto
// =============================================================================

var PROJECT_ASSETS_FOLDER_NAME = "StockHub Assets";

function _sanitizeProjectAssetPart(s) {
  var cleaned = String(s || "Uncategorized")
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
    .replace(/\s+/g, " ")
    .trim();
  return cleaned || "Uncategorized";
}

function _getProjectAssetCategoryFolder(file) {
  var catId = file && file.category;
  if (!catId || catId === "all") return "Uncategorized";
  if (typeof state !== "undefined" && state.categories) {
    for (var i = 0; i < state.categories.length; i++) {
      if (state.categories[i].id === catId && state.categories[i].name) {
        return _sanitizeProjectAssetPart(state.categories[i].name);
      }
    }
  }
  return _sanitizeProjectAssetPart(catId);
}

function _stableFileSuffix(filePath) {
  if (typeof _makeStablePathKey === "function") {
    var key = _makeStablePathKey(filePath);
    return key.substring(Math.max(0, key.length - 8));
  }
  return String(Date.now());
}

function getProjectAssetsFolder(callback) {
  try {
    if (typeof cs === "undefined" || !cs || !cs.evalScript) {
      callback(new Error("Premiere indisponivel"), null);
      return;
    }
    cs.evalScript("getProjectPath()", function(projectPath) {
      projectPath = String(projectPath || "").replace(/^"|"$/g, "");
      if (!projectPath) {
        callback(new Error("Salve o projeto do Premiere antes de usar assets do StockHub."), null);
        return;
      }
      callback(null, path.join(projectPath, PROJECT_ASSETS_FOLDER_NAME));
    });
  } catch (e) {
    callback(e, null);
  }
}

function _pickDestinationPath(root, file) {
  var name = _sanitizeProjectAssetPart(file && file.name ? file.name : path.basename(file.path));
  var ext = path.extname(name);
  var base = name.substring(0, name.length - ext.length) || "asset";
  var dir = path.join(root, _getProjectAssetCategoryFolder(file));
  var primary = path.join(dir, name);
  try {
    if (!fs.existsSync(primary)) return primary;
    var st = fs.statSync(primary);
    if (st.isFile() && st.size === file.size && st.size > 0) return primary;
  } catch (e) { /* tenta nome com sufixo abaixo */ }
  return path.join(dir, base + "__" + _stableFileSuffix(file.path) + ext);
}

function materializeFileForProjectAsync(file, callback) {
  if (!file || !file.path) {
    callback(new Error("Arquivo invalido"), null);
    return;
  }
  getProjectAssetsFolder(function(folderErr, root) {
    if (folderErr) {
      callback(folderErr, null);
      return;
    }
    var dest = _pickDestinationPath(root, file);
    try {
      if (path.normalize(file.path).toLowerCase() === path.normalize(dest).toLowerCase()) {
        callback(null, dest);
        return;
      }
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      if (fs.existsSync(dest)) {
        var existing = fs.statSync(dest);
        if (existing.isFile() && existing.size === file.size && existing.size > 0) {
          callback(null, dest);
          return;
        }
      }
    } catch (e) {
      callback(e, null);
      return;
    }

    var tmp = dest + ".tmp-" + process.pid + "-" + Date.now();
    var settled = false;
    function done(err, p) {
      if (settled) return;
      settled = true;
      if (err) {
        try { if (fs.existsSync(tmp)) fs.unlinkSync(tmp); } catch (_) { /* ignore */ }
      }
      callback(err, p);
    }
    var rs = fs.createReadStream(file.path);
    var ws = fs.createWriteStream(tmp);
    rs.on("error", function(err) {
      try { ws.destroy(); } catch (_) { /* ignore */ }
      done(err, null);
    });
    ws.on("error", function(err) {
      try { rs.destroy(); } catch (_) { /* ignore */ }
      done(err, null);
    });
    ws.on("finish", function() {
      try {
        fs.renameSync(tmp, dest);
        done(null, dest);
      } catch (e) {
        done(e, null);
      }
    });
    rs.pipe(ws);
  });
}

function materializeFilesForProjectAsync(files, onProgressOrComplete, onCompleteMaybe) {
  var onProgress = typeof onCompleteMaybe === "function" ? onProgressOrComplete : null;
  var onComplete = typeof onCompleteMaybe === "function" ? onCompleteMaybe : onProgressOrComplete;
  var paths = new Array(files.length);
  var errors = new Array(files.length);
  if (!files.length) {
    onComplete(paths, errors);
    return;
  }
  var POOL = 4;
  var doneCount = 0, active = 0, next = 0;
  function pump() {
    while (active < POOL && next < files.length) {
      var idx = next++;
      var file = files[idx];
      active++;
      (function(i, f) {
        materializeFileForProjectAsync(f, function(err, p) {
          paths[i] = p || null;
          errors[i] = err || null;
          active--;
          doneCount++;
          if (onProgress) {
            try { onProgress(doneCount, files.length, f, err); } catch (_) { /* ignore */ }
          }
          if (doneCount === files.length) onComplete(paths, errors);
          else pump();
        });
      })(idx, file);
    }
  }
  pump();
}

function _isManagedStagingPath(folderPath) {
  if (!folderPath) return false;
  var normalized = path.normalize(folderPath);
  var base = path.basename(normalized).toLowerCase();
  if (base === "stockhub_staging") return true;
  try {
    var cacheRoot = (typeof getAppCacheRoot === "function") ? path.normalize(getAppCacheRoot()) : "";
    if (cacheRoot) {
      var rel = path.relative(cacheRoot, normalized);
      return rel && rel.indexOf("..") !== 0 && rel.indexOf("staging") === 0;
    }
  } catch (e) { /* ignore */ }
  return false;
}

function cleanupLegacyStaging() {
  var candidates = [];
  var home = process.env.HOME || process.env.USERPROFILE || "";
  if (home) candidates.push(path.join(home, "StockHub_staging"));
  if (typeof getAppCacheRoot === "function") candidates.push(path.join(getAppCacheRoot(), "staging"));
  if (typeof state !== "undefined" && state.stagingFolder) candidates.push(state.stagingFolder);

  var seen = {};
  for (var i = 0; i < candidates.length; i++) {
    var p = candidates[i];
    if (!p || seen[p] || !_isManagedStagingPath(p)) continue;
    seen[p] = true;
    try {
      if (fs.existsSync(p)) fs.rmSync(p, { recursive: true, force: true });
    } catch (e) {
      if (typeof Logger !== "undefined") Logger.warn("project-assets", "cleanup staging falhou", e.message);
    }
  }
  if (typeof state !== "undefined" && state.stagingFolder) {
    state.stagingFolder = null;
    if (typeof saveState === "function") saveState();
  }
}

if (typeof window !== "undefined") {
  window.getProjectAssetsFolder = getProjectAssetsFolder;
  window.materializeFileForProjectAsync = materializeFileForProjectAsync;
  window.materializeFilesForProjectAsync = materializeFilesForProjectAsync;
  window.cleanupLegacyStaging = cleanupLegacyStaging;
}
