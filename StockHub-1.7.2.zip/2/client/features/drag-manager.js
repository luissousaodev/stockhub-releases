// =============================================================================
// drag-manager.js - Drag, import e timeline do StockHub
// =============================================================================

if (typeof window !== "undefined") (function() {

  var _state = null;
  var _saveState = null;
  var _showToast = null;
  var _toRelPath = null;
  var _toFileURL = null;
  var _materializeFileForProjectAsync = null;
  var _materializeFilesForProjectAsync = null;
  var _cs = null;
  var _trackEvent = null;
  var _pumpThumbPool = null;
  var _renderAll = null;

  var _dragPrep = {};
  var _activeDrag = null;

  function _escapeEvalPath(p) {
    return String(p || "").replace(/\\/g, "\\\\").replace(/'/g, "\\'");
  }

  function _escapeEvalJSON(paths) {
    return JSON.stringify(paths).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
  }

  function _getSelectedIndices(includeIndex) {
    var indices = Object.keys(_state.selectedFiles).map(Number);
    if (includeIndex !== undefined && indices.indexOf(includeIndex) === -1) indices.push(includeIndex);
    indices.sort(function(a, b) { return a - b; });
    return indices;
  }

  function _indicesForAction(fileIndex) {
    var selCount = Object.keys(_state.selectedFiles).length;
    return (selCount > 1 && _state.selectedFiles[fileIndex]) ? _getSelectedIndices() : [fileIndex];
  }

  function _filesFromIndices(indices) {
    var files = [];
    for (var i = 0; i < indices.length; i++) {
      var f = _state.files[indices[i]];
      if (f) files.push(f);
    }
    return files;
  }

  function _prepKey(indices) {
    return indices.join("|");
  }

  function _originalPathsForIndices(indices) {
    var paths = [];
    for (var i = 0; i < indices.length; i++) {
      var f = _state.files[indices[i]];
      if (f && f.path) paths.push(f.path);
    }
    return paths;
  }

  function _setDragTransferData(e, indices, paths) {
    e.dataTransfer.setData("text/plain", JSON.stringify(indices));
    e.dataTransfer.effectAllowed = "copyMove";
    for (var d = 0; d < paths.length; d++) {
      try { e.dataTransfer.setData("com.adobe.cep.dnd.file." + d, paths[d]); }
      catch (err) { Logger.warn("drag", "setData cep.dnd." + d + " failed", err.message); }
    }
    if (paths[0]) {
      try {
        e.dataTransfer.setData("text/uri-list", _toFileURL(paths[0]).replace(/ /g, "%20"));
      } catch (err2) { Logger.warn("drag", "setData uri-list failed", err2.message); }
    }
  }

  function _onPrepReady(key, callback) {
    var prep = _dragPrep[key];
    if (!prep) return;
    if (prep.status === "ready") {
      callback(prep.paths);
      return;
    }
    if (prep.status === "pending") {
      prep.callbacks = prep.callbacks || [];
      prep.callbacks.push(callback);
    }
  }

  function _materializeOne(file, action, onReady) {
    _materializeFileForProjectAsync(file, function(err, p) {
      if (err || !p) {
        _showToast(err ? err.message : "Falha ao copiar asset para o projeto");
        return;
      }
      onReady(p);
    });
  }

  function _materializeMany(files, onProgress, onReady) {
    _materializeFilesForProjectAsync(files, onProgress, function(paths, errors) {
      var okPaths = [];
      var okFiles = [];
      var failed = 0;
      for (var i = 0; i < paths.length; i++) {
        if (paths[i] && !(errors && errors[i])) {
          okPaths.push(paths[i]);
          okFiles.push(files[i]);
        } else {
          failed++;
        }
      }
      onReady(okPaths, okFiles, failed);
    });
  }

  function prepareDragAssets(evt, fileIndexMaybe) {
    var fileIndex = (typeof fileIndexMaybe === "number") ? fileIndexMaybe : evt;
    if (evt && typeof evt === "object") {
      if (evt.button !== undefined && evt.button !== 0) return;
      prepareDragAssets(fileIndex);
      return;
    }

    var indices = _indicesForAction(fileIndex);
    var key = _prepKey(indices);
    var existing = _dragPrep[key];
    if (existing && (existing.status === "ready" || existing.status === "pending")) return;

    var files = _filesFromIndices(indices);
    if (!files.length) return;
    _dragPrep[key] = { status: "pending", paths: null, callbacks: [] };
    _materializeMany(files, null, function(paths, _okFiles, failed) {
      var callbacks = (_dragPrep[key] && _dragPrep[key].callbacks) || [];
      if (failed > 0 || paths.length !== files.length) {
        _dragPrep[key] = { status: "error", paths: null, callbacks: [] };
        var statusErr = document.getElementById("statusText");
        if (statusErr) statusErr.textContent = "Falha ao preparar asset";
        return;
      }
      _dragPrep[key] = { status: "ready", paths: paths, callbacks: [] };
      var statusReady = document.getElementById("statusText");
      if (statusReady && statusReady.textContent === "Preparando asset para o projeto...") {
        statusReady.textContent = "Pronto";
      }
      for (var c = 0; c < callbacks.length; c++) {
        try { callbacks[c](paths); } catch (e) { Logger.warn("drag", "prep callback failed", e.message); }
      }
    });
  }

  function importToProject(fileIndex) {
    var file = _state.files[fileIndex];
    if (!file) return;
    _materializeOne(file, "import", function(importPath) {
      _cs.evalScript("importFileToProject('" + _escapeEvalPath(importPath) + "')", function(result) {
        try {
          var res = JSON.parse(result);
          if (res.success && !res.alreadyExists) _trackEvent(file, "import");
          _showToast(res.success ? (res.alreadyExists ? "Ja no projeto: " + file.name : "Importado: " + file.name) : (res.error || "Erro ao importar"));
        } catch (e) {
          _showToast("Erro ao importar");
        }
      });
    });
  }

  function onFileDragStart(e, fileIndex) {
    var indices = _indicesForAction(fileIndex);
    var key = _prepKey(indices);
    var prep = _dragPrep[key];
    var paths;
    var bridged = false;

    if (prep && prep.status === "ready" && prep.paths) {
      paths = prep.paths;
    } else {
      if (!prep || prep.status !== "pending") prepareDragAssets(fileIndex);
      paths = _originalPathsForIndices(indices);
      bridged = true;
    }

    window.isDragging = true;
    window.thumbQueuePaused = true;
    FFmpegManager.killActiveThumbChildren();
    PreviewManager.cleanupPreview();

    _setDragTransferData(e, indices, paths);
    _activeDrag = {
      key: key,
      indices: indices,
      originalPaths: _originalPathsForIndices(indices),
      dragPaths: paths,
      bridged: bridged
    };

    var item = e.target.closest && e.target.closest(".grid-item");
    if (item) item.classList.add("dragging");

    try {
      if (e.dataTransfer.setDragImage) {
        if (!window.__emptyDragImage) {
          var img = new Image();
          img.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
          window.__emptyDragImage = img;
        }
        e.dataTransfer.setDragImage(window.__emptyDragImage, 0, 0);
      }
    } catch (errImg) { Logger.warn("drag", "setDragImage failed", errImg.message); }
    return true;
  }

  function onFileDragEnd(e, fileIndex) {
    var el = e.target.closest(".grid-item");
    if (el) el.classList.remove("dragging");
    var cats = document.querySelectorAll(".cat-item");
    for (var i = 0; i < cats.length; i++) cats[i].classList.remove("drag-over");

    var dragInfo = _activeDrag;
    _activeDrag = null;
    if (dragInfo && dragInfo.bridged) {
      _onPrepReady(dragInfo.key, function(materializedPaths) {
        for (var rp = 0; rp < materializedPaths.length; rp++) {
          var oldEsc = _escapeEvalPath(dragInfo.originalPaths[rp]);
          var newEsc = _escapeEvalPath(materializedPaths[rp]);
          setTimeout(function(o, n) {
            _cs.evalScript("relinkAndMoveStockHubItem('" + o + "','" + n + "')");
          }, 500, oldEsc, newEsc);
        }
      });
    } else if (dragInfo && dragInfo.dragPaths) {
      for (var p = 0; p < dragInfo.dragPaths.length; p++) {
        var escaped = _escapeEvalPath(dragInfo.dragPaths[p]);
        setTimeout(function(pathEsc) {
          _cs.evalScript("moveFileToStockHubBin('" + pathEsc + "')");
        }, 500, escaped);
      }
    }

    window.isDragging = false;
    setTimeout(function() {
      window.thumbQueuePaused = false;
      _pumpThumbPool();
    }, 800);
  }

  function onCatDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    e.currentTarget.classList.add("drag-over");
  }

  function onCatDragLeave(e) {
    e.currentTarget.classList.remove("drag-over");
  }

  function _parseDragIndices(dataStr) {
    try {
      var parsed = JSON.parse(dataStr);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) { /* fallback para indice simples abaixo */ }
    var num = parseInt(dataStr);
    return isNaN(num) ? [] : [num];
  }

  function onCatDrop(e, catId) {
    e.preventDefault();
    e.currentTarget.classList.remove("drag-over");
    var indices = _parseDragIndices(e.dataTransfer.getData("text/plain"));
    if (!_state.fileCategories) _state.fileCategories = {};
    var count = 0;
    for (var i = 0; i < indices.length; i++) {
      var file = _state.files[indices[i]];
      if (!file) continue;
      file.category = catId;
      _state.fileCategories[_toRelPath(file.path)] = catId;
      count++;
    }
    if (count === 0) return;
    _saveState();
    if (typeof window.bumpFilesVersion === "function") window.bumpFilesVersion();
    _renderAll();
    var catName = "";
    for (var j = 0; j < _state.categories.length; j++) {
      if (_state.categories[j].id === catId) { catName = _state.categories[j].name; break; }
    }
    _showToast(count > 1 ? count + " arquivos movidos para: " + catName : "Movido para: " + catName);
  }

  function onFavoritesDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove("drag-over");
    var indices = _parseDragIndices(e.dataTransfer.getData("text/plain"));
    if (!_state.favoriteFiles) _state.favoriteFiles = {};
    var count = 0;
    for (var i = 0; i < indices.length; i++) {
      var file = _state.files[indices[i]];
      if (!file) continue;
      _state.favoriteFiles[_toRelPath(file.path)] = true;
      count++;
    }
    if (count === 0) return;
    _saveState();
    if (typeof window.bumpFilesVersion === "function") window.bumpFilesVersion();
    _renderAll();
    _showToast(count > 1 ? count + " arquivos adicionados aos favoritos" : "Adicionado aos favoritos: " + _state.files[indices[0]].name);
  }

  function onDoubleClick(fileIndex) {
    var selCount = Object.keys(_state.selectedFiles).length;
    var indices = (selCount > 1 && _state.selectedFiles[fileIndex]) ? _getSelectedIndices() : [fileIndex];
    var files = _filesFromIndices(indices);
    if (!files.length) return;

    _materializeMany(files, null, function(paths, okFiles, failed) {
      if (!paths.length) {
        _showToast("Nenhum arquivo pode ser copiado para o projeto");
        return;
      }
      _cs.evalScript("importFilesToTimeline('" + _escapeEvalJSON(paths) + "')", function(result) {
        try {
          var res = JSON.parse(result);
          if (res.success) {
            for (var i = 0; i < okFiles.length; i++) _trackEvent(okFiles[i], "timeline");
          }
          var msg = res.success
            ? res.inserted + "/" + (res.total + failed) + " inseridos na timeline"
            : (res.error || "Erro ao inserir");
          if (failed > 0 || res.errors > 0) msg += " (" + (failed + res.errors) + " erro" + ((failed + res.errors) > 1 ? "s" : "") + ")";
          _showToast(msg);
        } catch (e) {
          _showToast("Erro ao inserir na timeline");
        }
      });
    });
  }

  function batchInsertToTimeline() {
    var indices = Object.keys(_state.selectedFiles).map(Number);
    if (indices.length === 0) return;
    indices.sort(function(a, b) { return a - b; });
    var files = _filesFromIndices(indices);
    if (!files.length) return;

    document.getElementById("statusText").textContent = "Copiando para o projeto...";
    _materializeMany(files, function(done, total) {
      document.getElementById("statusText").textContent = "Copiando para o projeto... " + done + "/" + total;
    }, function(paths, okFiles, failed) {
      if (!paths.length) {
        _showToast("Nenhum arquivo pode ser copiado para o projeto");
        document.getElementById("statusText").textContent = "";
        return;
      }
      _cs.evalScript("importFilesToTimeline('" + _escapeEvalJSON(paths) + "')", function(result) {
        try {
          var res = JSON.parse(result);
          if (res.success) {
            for (var i = 0; i < okFiles.length; i++) _trackEvent(okFiles[i], "timeline");
          }
          var msg = res.success
            ? res.inserted + "/" + (res.total + failed) + " inseridos na timeline"
            : (res.error || "Erro ao inserir");
          if (failed > 0 || res.errors > 0) msg += " (" + (failed + res.errors) + " erro" + ((failed + res.errors) > 1 ? "s" : "") + ")";
          _showToast(msg);
        } catch (e) {
          _showToast("Erro ao inserir na timeline");
        }
        document.getElementById("statusText").textContent = "";
        _state.selectedFiles = {};
        renderGrid();
      });
    });
  }

  window.DragManager = {
    init: function(stateRef, deps) {
      _state = stateRef;
      _saveState = deps.saveState;
      _showToast = deps.showToast;
      _toRelPath = deps.toRelPath;
      _toFileURL = deps.toFileURL;
      _materializeFileForProjectAsync = deps.materializeFileForProjectAsync;
      _materializeFilesForProjectAsync = deps.materializeFilesForProjectAsync;
      _cs = deps.cs;
      _trackEvent = deps.trackEvent;
      _pumpThumbPool = deps.pumpThumbPool;
      _renderAll = deps.renderAll;
    },
    importToProject: importToProject,
    prepareDragAssets: prepareDragAssets,
    onFileDragStart: onFileDragStart,
    onFileDragEnd: onFileDragEnd,
    onCatDragOver: onCatDragOver,
    onCatDragLeave: onCatDragLeave,
    onCatDrop: onCatDrop,
    onFavoritesDrop: onFavoritesDrop,
    onDoubleClick: onDoubleClick,
    batchInsertToTimeline: batchInsertToTimeline
  };

  window.importToProject = importToProject;
  window.prepareDragAssets = prepareDragAssets;
  window.onFileDragStart = onFileDragStart;
  window.onFileDragEnd = onFileDragEnd;
  window.onCatDragOver = onCatDragOver;
  window.onCatDragLeave = onCatDragLeave;
  window.onCatDrop = onCatDrop;
  window.onFavoritesDrop = onFavoritesDrop;
  window.onDoubleClick = onDoubleClick;
  window.batchInsertToTimeline = batchInsertToTimeline;

})();
