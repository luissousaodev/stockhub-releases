// =============================================================================
// features/thumbnails.js — Filas independentes de thumb + sprite + viewport observer
// =============================================================================

// Cache local em memoria (sidecar/cache em disco) — evita existsSync por re-render.
// LRU bounded (5000) pra nao crescer indefinido em sessao muito longa com
// 1 pasta de assets gigante. Pattern reusa _makeLRU exposto via FFmpegManager.
var thumbLookupCache = FFmpegManager._makeLRU(5000);

// Hash set pre-aquecido do .cache em disco — lookup O(1) no render inicial
var _thumbHashSet = null;

// Sibling thumb set pre-aquecido: mapa "<dir>:<basename>" -> ".ext" pra
// thumbs irmaos do asset (foo.mp4 + foo.jpg ao lado, ou em thumbs/foo.jpg).
// Substitui 8-9 existsSync por arquivo no getThumbnail (4 ext x 2 locais)
// por 1 readdirSync por dir unico no refreshFiles.
var _siblingThumbSet = null;
var _THUMB_EXTS = [".png", ".jpg", ".jpeg", ".gif"];

function prewarmThumbLookup() {
  if (typeof FFmpegManager === "undefined" || !FFmpegManager.buildThumbHashSet) return;
  _thumbHashSet = FFmpegManager.buildThumbHashSet();
}

function updateThumbHashSet(hash, filePath) {
  if (_thumbHashSet) _thumbHashSet[hash] = filePath;
}

// Pre-warm sibling thumbs: pra cada dir unico em state.files (e seu
// "<dir>/thumbs"), faz 1 readdirSync e indexa arquivos com ext em
// _THUMB_EXTS. Custo: ~50-200 ms em pasta com 50-200 dirs unicos;
// economiza ate 8x existsSync por arquivo no render. Try/catch silencioso
// por dir (dir nao existe / sem permissao).
function prewarmSiblingThumbs(files) {
  _siblingThumbSet = {};
  if (!files || !files.length) return;
  var dirs = {};
  for (var i = 0; i < files.length; i++) {
    var d = path.dirname(files[i].path);
    dirs[d] = true;
  }
  var dirList = Object.keys(dirs);
  for (var j = 0; j < dirList.length; j++) {
    var dir = dirList[j];
    _scanDirForThumbs(dir, dir);
    _scanDirForThumbs(path.join(dir, "thumbs"), path.join(dir, "thumbs"));
  }
}

function _scanDirForThumbs(dir, keyDir) {
  try {
    var items = fs.readdirSync(dir);
    for (var k = 0; k < items.length; k++) {
      var name = items[k];
      var ext = path.extname(name).toLowerCase();
      if (_THUMB_EXTS.indexOf(ext) < 0) continue;
      var base = name.substring(0, name.length - ext.length);
      _siblingThumbSet[keyDir + ":" + base] = ext;
    }
  } catch (e) { /* silencioso — dir nao existe ou sem permissao */ }
}

function formatDuration(sec) {
  if (!sec || sec < 0) return "";
  var s = Math.round(sec);
  var m = Math.floor(s / 60);
  var rem = s % 60;
  return m + ":" + (rem < 10 ? "0" : "") + rem;
}

function getThumbnail(file) {
  if (thumbLookupCache.has(file.path)) return thumbLookupCache.get(file.path);
  try {
    var dir = path.dirname(file.path);
    var base = path.basename(file.path, path.extname(file.path));

    // L1: sibling set pre-warmed (zero existsSync se populado)
    if (_siblingThumbSet) {
      var ext1 = _siblingThumbSet[dir + ":" + base];
      if (ext1) {
        var u1 = toFileURL(path.join(dir, base + ext1));
        thumbLookupCache.set(file.path, u1);
        return u1;
      }
      var thumbDir = path.join(dir, "thumbs");
      var ext2 = _siblingThumbSet[thumbDir + ":" + base];
      if (ext2) {
        var u2 = toFileURL(path.join(thumbDir, base + ext2));
        thumbLookupCache.set(file.path, u2);
        return u2;
      }
    } else {
      // Fallback (sibling set nao populado: chamado fora do fluxo de
      // refreshFiles, ex. preview hover de cloud-only). Mantem comportamento
      // historico: 4 ext x 2 locais = ate 8 existsSync.
      for (var i = 0; i < _THUMB_EXTS.length; i++) {
        var thumbPath = path.join(dir, base + _THUMB_EXTS[i]);
        if (fs.existsSync(thumbPath)) { var uA = toFileURL(thumbPath); thumbLookupCache.set(file.path, uA); return uA; }
        var thumbPath2 = path.join(dir, "thumbs", base + _THUMB_EXTS[i]);
        if (fs.existsSync(thumbPath2)) { var uB = toFileURL(thumbPath2); thumbLookupCache.set(file.path, uB); return uB; }
      }
    }

    // L2: hash set do .cache em disco
    if (typeof FFmpegManager !== "undefined" && FFmpegManager.hashPath) {
      var hash = FFmpegManager.hashPath(file.path);
      var cacheThumb = _thumbHashSet
        ? (_thumbHashSet[hash] || null)
        : (FFmpegManager.getCacheDir
            ? (fs.existsSync(path.join(FFmpegManager.getCacheDir(), hash + "_thumb.jpg"))
                ? path.join(FFmpegManager.getCacheDir(), hash + "_thumb.jpg")
                : null)
            : null);
      if (cacheThumb) {
        var u3 = toFileURL(cacheThumb);
        thumbLookupCache.set(file.path, u3);
        if (FFmpegManager.thumbCache && FFmpegManager.thumbCache.set) FFmpegManager.thumbCache.set(file.path, u3);
        return u3;
      }
    }
  } catch (e) { Logger.warn("thumbnails", "Falha ao buscar thumb local", e.message); }
  thumbLookupCache.set(file.path, null);
  return null;
}

// Substitui o placeholder/thumbnail antigo pela nova URL no card. Usado tanto
// pelo pumpThumbPool quanto pelo preview-manager (gen sob demanda no hover).
// Usa state._pathToCardEl pra lookup O(1); fallback pra querySelector quando
// chamado antes do mapa ter sido populado (1o chunk em progresso, race com
// renderGrid, etc).
function _updateCardThumb(filePath, url) {
  var card = state._pathToCardEl && state._pathToCardEl[filePath];
  var el = card
    ? card.querySelector(".thumbnail, .placeholder")
    : document.querySelector('[data-filepath="' + CSS.escape(filePath) + '"] .thumbnail, [data-filepath="' + CSS.escape(filePath) + '"] .placeholder');
  if (!el) return;
  var img = document.createElement("img");
  img.className = "thumbnail";
  img.src = url;
  img.loading = "lazy";
  el.replaceWith(img);
}

// --- Concurrency adaptativa ---
// Pasta cloud (Drive/OneDrive) lida mal com paralelismo agressivo — limita a 2.
// Local: CPU moderna aguenta 4 facil em ambas as plataformas.
function _getThumbConcurrency() {
  var folder = (typeof getStockFolder === "function") ? getStockFolder() : "";
  var isCloud = (typeof detectCloudPath === "function") && detectCloudPath(folder);
  return isCloud ? 2 : 4;
}

// --- Worker pools (thumb e sprite sao independentes) ---
var thumbPoolActive = 0;
var spritePoolActive = 0;
var SPRITE_CONCURRENCY = 1;  // sprite usa filtro complexo — 1 por vez basta

function pumpThumbPool() {
  if (!state.thumbQueueVisible) return;
  var concurrency = _getThumbConcurrency();
  while (
    !thumbQueuePaused &&
    thumbPoolActive < concurrency &&
    (state.thumbQueueVisible.length + state.thumbQueueRest.length > 0)
  ) {
    var f = state.thumbQueueVisible.length > 0
      ? state.thumbQueueVisible.shift()
      : state.thumbQueueRest.shift();
    if (!f) break;
    thumbPoolActive++;
    (function(file) {
      generateThumbFFmpeg(file.path, function(url) {
        thumbPoolActive--;
        state._thumbDone = (state._thumbDone || 0) + 1;
        if (url) _updateCardThumb(file.path, url);
        // Decoupling: sprite eh enfileirado SEMPRE (sucesso ou falha do thumb),
        // pra que falha de thumb nao impeca o preview animado.
        if (file.type === "video" && state.spriteQueueRest && !FFmpegManager.spriteCache.has(file.path)) {
          state.spriteQueueRest.push(file);
          pumpSpritePool();
        }
        var statusEl = document.getElementById("statusText");
        var pending = state.thumbQueueVisible.length + state.thumbQueueRest.length + thumbPoolActive;
        if (statusEl) {
          statusEl.textContent = pending > 0
            ? "Gerando thumbs... " + state._thumbDone + "/" + state._thumbTotal
            : "Pronto";
        }
        pumpThumbPool();
      });
    })(f);
  }
  if (thumbQueuePaused && (state.thumbQueueVisible.length + state.thumbQueueRest.length > 0)) {
    var statusEl2 = document.getElementById("statusText");
    if (statusEl2) statusEl2.textContent = "Pausado (drag em andamento)";
  }
}

// Fila independente — sprites geram em background sem competir com thumbs.
// Concurrency 1 deixa CPU livre pra thumbs no boot inicial.
function pumpSpritePool() {
  if (!state.spriteQueueRest) return;
  while (!thumbQueuePaused && spritePoolActive < SPRITE_CONCURRENCY && state.spriteQueueRest.length > 0) {
    var f = state.spriteQueueRest.shift();
    if (!f) break;
    spritePoolActive++;
    (function(file) {
      generateFrameStripFFmpeg(file.path, function() {
        spritePoolActive--;
        pumpSpritePool();
      });
    })(f);
  }
}

// IntersectionObserver: promove cards visiveis para a fila prioritaria
var _thumbIO = null;
function setupViewportObserver() {
  if (_thumbIO) { try { _thumbIO.disconnect(); } catch (e) { Logger.warn("thumbnails", "IO disconnect failed", e.message); } _thumbIO = null; }
  if (typeof IntersectionObserver === "undefined") return;
  var grid = document.getElementById("fileGrid");
  var container = document.getElementById("gridContainer");
  if (!grid) return;
  _thumbIO = new IntersectionObserver(function(entries) {
    var promoted = false;
    for (var i = 0; i < entries.length; i++) {
      if (!entries[i].isIntersecting) continue;
      var rel = entries[i].target.getAttribute("data-rel");
      if (!rel) continue;
      for (var j = 0; j < state.thumbQueueRest.length; j++) {
        if (toRelPath(state.thumbQueueRest[j].path) === rel) {
          state.thumbQueueVisible.unshift(state.thumbQueueRest.splice(j, 1)[0]);
          promoted = true;
          break;
        }
      }
    }
    if (promoted) pumpThumbPool();
  }, { root: container || null, rootMargin: "200px" });
  var items = grid.querySelectorAll(".grid-item");
  for (var k = 0; k < items.length; k++) _thumbIO.observe(items[k]);
}

// --- refreshFiles: scan + kick off thumb/sprite/resolution queues ---
function refreshFiles() {
  var folder = getStockFolder();
  if (state.customFolder && !fs.existsSync(state.customFolder)) {
    var invalidFolder = state.customFolder;
    state.customFolder = null;
    saveState();
    folder = getStockFolder();
    var fp = document.getElementById("stockFolderPath");
    if (fp) fp.textContent = folder;
    showToast("Pasta \"" + invalidFolder + "\" nao encontrada. Revertendo para pasta padrao.");
  }
  state.files = scanFolder(folder);
  if (typeof bumpFilesVersion === "function") bumpFilesVersion();
  // Pre-warm sibling thumb set ANTES do render — getThumbnail consulta o
  // mapa direto em vez de fazer 8 existsSync por arquivo no _buildCardHTML.
  prewarmSiblingThumbs(state.files);
  renderAll();
  updateCloudIndicator(folder);
  showToast(state.files.length + " arquivos encontrados");
  document.getElementById("statusText").textContent = "Atualizado";
  startFolderWatcher(folder);

  // Cooldown de falhas eh resetado a cada refresh — user explicitamente pediu retry
  if (FFmpegManager.clearFailedPreviews) FFmpegManager.clearFailedPreviews();

  if (findFFmpeg()) {
    var queue = [];
    var resQueue = [];
    var thumbCache = FFmpegManager.thumbCache;
    var resolutionCache = FFmpegManager.resolutionCache;
    for (var i = 0; i < state.files.length; i++) {
      var f = state.files[i];
      if (f.cloudOnly) continue;  // cloud-only gera sob demanda no hover (preview-manager)
      if (f.type === "video") {
        if (!thumbCache.has(f.path)) queue.push(f);
        if (!resolutionCache.has(f.path)) resQueue.push(f);
      } else if (f.type === "image" && !resolutionCache.has(f.path)) {
        resQueue.push(f);
      }
    }

    // Pool META_POOL=4: paraleliza o drain do resQueue. Antes era recursao
    // sequencial — em pasta com 5K videos e sidecar _meta.json cacheado
    // (boot 2+), cada L2 hit custa ~5ms mas rodava 1 por vez = ~25s.
    // Com pool=4 alinhado ao thumb pool, drain cai pra ~6s. Ordem de
    // conclusao deixa de ser deterministica — cards atualizam conforme
    // chegam (melhor UX percebida: preenche distribuido em vez de
    // esquerda-pra-direita).
    var META_POOL = 4;
    var metaActive = 0;
    var metaNext = 0;
    function pumpMeta() {
      while (metaActive < META_POOL && metaNext < resQueue.length) {
        var rf = resQueue[metaNext++];
        metaActive++;
        processOneMeta(rf);
      }
    }
    function processOneMeta(rf) {
      function done() { metaActive--; pumpMeta(); }
      if (rf.type === "image") {
        var img = new Image();
        img.onload = function() {
          resolutionCache.set(rf.path, img.naturalWidth + "x" + img.naturalHeight);
          rebuildMetaLine(rf.path);
          done();
        };
        img.onerror = done;
        img.src = toFileURL(rf.path);
      } else {
        getVideoResolution(rf.path, function(res) {
          if (res) rebuildMetaLine(rf.path);
          if (!FFmpegManager.durationCache.has(rf.path)) {
            FFmpegManager.getVideoDuration(rf.path, function() {
              rebuildMetaLine(rf.path);
              done();
            });
          } else {
            done();
          }
        });
      }
    }

    function rebuildMetaLine(filePath) {
      // Lookup O(1) via state._pathToCardEl (populado no fim do renderGrid);
      // fallback pra querySelector se mapa nao existir ainda (chunked render
      // ainda nao terminou, ou racing com nova renderGrid).
      var card = (state._pathToCardEl && state._pathToCardEl[filePath]) ||
        document.querySelector('[data-filepath="' + CSS.escape(filePath) + '"]');
      if (!card) return;
      var meta = card.querySelector("[data-meta]");
      if (!meta) return;
      var f = null;
      for (var i = 0; i < state.files.length; i++) {
        if (state.files[i].path === filePath) { f = state.files[i]; break; }
      }
      if (!f) return;
      var parts = [f.ext.toUpperCase()];
      var r = resolutionCache.get(filePath);
      if (r) parts.push(r);
      var d = FFmpegManager.durationCache.get(filePath);
      if (d) parts.push(formatDuration(d));
      meta.innerHTML = parts.map(function(p) { return '<span>' + p + '</span>'; })
        .join('<span class="grid-item-meta-sep">|</span>');
    }

    state.thumbQueueVisible = [];
    state.thumbQueueRest = queue.slice();
    state.spriteQueueRest = [];   // sprite eh enfileirado conforme thumbs concluem
    state._thumbTotal = queue.length;
    state._thumbDone = 0;
    pumpThumbPool();
    setupViewportObserver();
    pumpMeta();
  }
}

// Globais para uso em app.js, preview-manager.js, ffmpeg-manager.js
window.prewarmThumbLookup = prewarmThumbLookup;
window.updateThumbHashSet = updateThumbHashSet;
window._updateCardThumb   = _updateCardThumb;
