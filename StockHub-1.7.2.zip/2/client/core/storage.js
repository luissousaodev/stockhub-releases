// =============================================================================
// core/storage.js — Utilitarios de path e storage
// =============================================================================

// Garante acesso a 'path' tanto no browser (global via platform.js) como no Node (testes)
if (typeof path === "undefined" && typeof require === "function") {
  var path = require("path");
}

// Funcoes puras testaveis
function _toFileURL(p) {
  if (!p) return p;
  var normalized = String(p).replace(/\\/g, "/");
  if (normalized.charAt(0) === "/") {
    return "file://" + normalized;
  }
  return "file:///" + normalized;
}

/**
 * Detecta se um caminho aponta para um provedor de nuvem (Google Drive,
 * OneDrive, Dropbox, Box). Retorna { provider, shared } ou null.
 *
 * Por que: stat.blocks e' undefined no Windows, entao a deteccao por bloco
 * falha em Drive Stream / OneDrive Files-On-Demand. A heuristica de caminho
 * funciona como rede de seguranca para tratar assets cloud com cuidado.
 */
function _detectCloudPath(p) {
  if (!p) return null;
  var s = String(p).replace(/\\/g, "/");

  // Google Drive (macOS modern: ~/Library/CloudStorage/GoogleDrive-...)
  if (s.indexOf("/CloudStorage/GoogleDrive-") >= 0) {
    return { provider: "google-drive", shared: s.indexOf("/Shared drives/") >= 0 };
  }
  // Google Drive Desktop (legado e Windows)
  if (/(^|\/)Google ?Drive([ ]File ?Stream)?\//i.test(s) ||
      s.indexOf("/.shortcut-targets-by-id/") >= 0) {
    return { provider: "google-drive", shared: s.indexOf("/Shared drives/") >= 0 };
  }
  // Drive Stream raiz por letra de drive (Windows): "G:/Shared drives/..."
  if (/^[A-Z]:\/Shared drives\//i.test(s)) {
    return { provider: "google-drive", shared: true };
  }
  // macOS volume montado pelo Drive File Stream
  if (/^\/Volumes\/GoogleDrive(\b|\/)/i.test(s)) {
    return { provider: "google-drive", shared: s.indexOf("/Shared drives/") >= 0 };
  }
  // OneDrive (pessoal e business)
  if (/(^|\/)OneDrive([- ][^/]+)?\//i.test(s)) {
    return { provider: "onedrive", shared: false };
  }
  // Dropbox
  if (/(^|\/)Dropbox([ ][^/]+)?\//i.test(s)) {
    return { provider: "dropbox", shared: false };
  }
  // Box
  if (/(^|\/)Box(\b|\/)/i.test(s) && s.indexOf("/Box ") >= 0 || /(^|\/)Box Sync\//i.test(s)) {
    return { provider: "box", shared: false };
  }
  return null;
}

function _normalizePathForKey(p) {
  if (!p) return "";
  return String(p).replace(/\\/g, "/").toLowerCase();
}

function _makeStablePathKey(p) {
  var s = _normalizePathForKey(p);
  if (!s) return "default_0";
  var h = 5381;
  for (var i = 0; i < s.length; i++) {
    h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  }
  var base = s.replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  var tail = base.substring(Math.max(0, base.length - 48)) || "default";
  return tail + "_" + (h >>> 0).toString(16);
}

function _migrateAbsoluteKeysToRelative(dict, stockFolder) {
  if (!dict) return dict;
  var out = {};
  var keys = Object.keys(dict);
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    var isAbs = (k.length > 2 && k.charAt(1) === ":") || k.charAt(0) === "/" || k.charAt(0) === "\\";
    if (!isAbs) {
      out[k] = dict[k];
      continue;
    }
    try {
      var rel = path.relative(stockFolder, k);
      if (!rel || rel.indexOf("..") === 0) continue;
      out[rel.split(path.sep).join("/")] = dict[k];
    } catch (e) { /* path fora da pasta — descarta */ }
  }
  return out;
}

// Node.js exports para testes
if (typeof module !== "undefined") {
  module.exports = {
    _toFileURL: _toFileURL,
    _migrateAbsoluteKeysToRelative: _migrateAbsoluteKeysToRelative,
    _detectCloudPath: _detectCloudPath,
    _makeStablePathKey: _makeStablePathKey,
    _normalizePathForKey: _normalizePathForKey
  };
}

// Browser globals
if (typeof window !== "undefined") {
  // toFileURL — alias global (usado por todos os modulos)
  window.toFileURL = _toFileURL;

  // detectCloudPath — alias global
  window.detectCloudPath = _detectCloudPath;

  // migrateAbsoluteKeysToRelative — usado apenas por state.js
  window.migrateAbsoluteKeysToRelative = _migrateAbsoluteKeysToRelative;

  // getStoragePath — retorna caminho do stockhub-data.json
  window.getStoragePath = function() {
    var dataDir = cs.getSystemPath(SystemPath.USER_DATA);
    return path.join(dataDir, "stockhub-data.json");
  };

  // getDocumentsPath — Documents/My Documents do usuario.
  window.getDocumentsPath = function() {
    try {
      if (typeof cs !== "undefined" && cs.getSystemPath &&
          typeof SystemPath !== "undefined" && SystemPath.MY_DOCUMENTS) {
        var docs = cs.getSystemPath(SystemPath.MY_DOCUMENTS);
        if (docs) return docs;
      }
    } catch (e) { /* fallback abaixo */ }
    var home = process.env.HOME || process.env.USERPROFILE || "";
    return path.join(home, "Documents");
  };

  // Raiz local unica para caches do app (thumbs, metadata, index).
  window.getAppCacheRoot = function() {
    return path.join(getDocumentsPath(), "StockHub Cache");
  };

  // Namespace estavel por pasta escaneada — evita colisao entre bibliotecas.
  window.getStockFolderCacheKey = function(folderPath) {
    return _makeStablePathKey(folderPath || (typeof getStockFolder === "function" ? getStockFolder() : ""));
  };

  // toRelPath — converte path absoluto para relativo a pasta de stock
  window.toRelPath = function(absPath) {
    if (!absPath) return absPath;
    try {
      var rel = path.relative(getStockFolder(), absPath);
      if (!rel || rel.indexOf("..") === 0) return absPath;
      return rel.split(path.sep).join("/");
    } catch (e) {
      return absPath;
    }
  };
}
