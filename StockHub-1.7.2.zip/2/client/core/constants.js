// =============================================================================
// core/constants.js — Constantes globais do StockHub
// =============================================================================

var FORMAT_GROUPS = {
  video: [".mp4",".mov",".avi",".mxf",".m4v",".wmv",".mkv",".flv",".mpg",".mpeg",".m2v",".m2t",".m2ts",".mts",".ts",".vob",".webm",".3gp",".f4v",".r3d",".braw"],
  audio: [".mp3",".wav",".aac",".aif",".aiff",".ogg",".wma",".flac",".m4a"],
  image: [".jpg",".jpeg",".png",".bmp",".tif",".tiff",".psd",".gif",".dpx",".exr",".tga",".ai",".eps",".svg"]
};

var ALL_EXTENSIONS = [].concat(FORMAT_GROUPS.video, FORMAT_GROUPS.audio, FORMAT_GROUPS.image);

var DEFAULT_CATEGORIES = [
  { id: "all", name: "Todos", color: "#0078d4", system: true },
  { id: "overlays", name: "Overlays", color: "#f44747" },
  { id: "transitions", name: "Transicoes", color: "#4ec9b0" },
  { id: "backgrounds", name: "Backgrounds", color: "#ce9178" },
  { id: "lower-thirds", name: "Lower Thirds", color: "#dcdcaa" },
  { id: "icons", name: "Icones", color: "#c586c0" },
  { id: "sfx", name: "SFX/Audio", color: "#569cd6" },
];

function getFileType(ext) {
  if (FORMAT_GROUPS.video.indexOf(ext) >= 0) return "video";
  if (FORMAT_GROUPS.audio.indexOf(ext) >= 0) return "audio";
  if (FORMAT_GROUPS.image.indexOf(ext) >= 0) return "image";
  return null;
}

// Node.js exports para testes
if (typeof module !== "undefined") {
  module.exports = {
    FORMAT_GROUPS: FORMAT_GROUPS,
    ALL_EXTENSIONS: ALL_EXTENSIONS,
    DEFAULT_CATEGORIES: DEFAULT_CATEGORIES,
    getFileType: getFileType
  };
}
