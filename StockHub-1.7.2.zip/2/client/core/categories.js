// =============================================================================
// core/categories.js — Helper compartilhado para gerar IDs de categoria
// =============================================================================

function toCategoryId(name) {
  if (!name) return "";
  return String(name).toLowerCase().replace(/[^a-z0-9]/g, "-");
}

if (typeof module !== "undefined") {
  module.exports = { toCategoryId: toCategoryId };
}
