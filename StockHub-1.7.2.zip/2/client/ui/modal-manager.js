// =============================================================================
// modal-manager.js — Modulo de modais do StockHub
//
// Responsabilidades:
//   - Modal "Ultima atualizacao" (versionLabel.click + pos-update)
//   - Modal de boas-vindas (primeira execucao, 6 slides)
//   - Modal de identificacao de usuario (necessario pra metricas)
//   - Modal FFmpeg ausente (com link de download)
//   - Modal de confirmacao generico (reutilizavel)
//
// Dependencias externas (recebidas via init):
//   - state, saveState, showToast, APP_VERSION
// =============================================================================

// IIFE — encapsula estado privado (so roda no browser)
if (typeof window !== "undefined") (function() {
  var _fs   = require("fs");
  var _path = require("path");

  // Dependencias injetadas via init()
  var _state     = null;
  var _saveState = null;
  var _showToast = null;

  var welcomeSlides = [
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
      title: 'Bem-vindo ao StockHub!',
      text: 'Centralize seus assets de stock — videos, imagens, audios e MOGRTs — em um unico painel dentro do Premiere Pro.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>',
      title: 'Configure sua pasta',
      text: 'Abra as configuracoes (icone de engrenagem) e escolha a pasta onde ficam seus stocks. Subpastas viram categorias automaticamente — sem precisar organizar nada manualmente.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>',
      title: 'Arraste para a timeline',
      text: 'Arraste qualquer asset direto para a timeline do Premiere. Duplo clique insere na posicao do playhead. Use o botao de import para adicionar ao projeto sem inserir na timeline.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#e8a634" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
      title: 'Favoritos e Tags',
      text: 'Clique com o botao direito em qualquer asset para adicionar aos favoritos ou criar tags. As tags aparecem na busca — digite o nome da tag para encontrar assets relacionados.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#c586c0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>',
      title: 'Selecao multipla',
      text: 'Segure Ctrl e clique para selecionar varios assets. Use Shift+clique para selecionar um intervalo. Importe todos de uma vez com o botao "Importar" na barra de selecao.'
    },
    {
      icon: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#4ec9b0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
      title: 'Tudo pronto!',
      text: 'Voce esta pronto para usar o StockHub. Acesse as configuracoes a qualquer momento pelo icone de engrenagem. Use Ctrl+Shift+R para recarregar o painel.'
    }
  ];

  // -------------------------------------------------------------------------
  // Modais
  // -------------------------------------------------------------------------

  function closeModal(e) {
    if (e && e.target !== e.currentTarget) return;
    document.getElementById("modalContainer").innerHTML = "";
  }

  // showLastUpdateModal — modal unificado usado em 2 lugares:
  //   1) Click no versionLabel (rodape da sidebar)
  //   2) Boot pos-update (lastSeenVersion < APP_VERSION) — app.js
  // Mostra versao atual + notes do version.json + botao Fechar.
  // Sem efeito colateral — caller pos-update eh quem seta lastSeenVersion.
  function showLastUpdateModal() {
    var notes = "";
    try {
      var vf = _path.join(__dirname, "..", "version.json");
      var vd = JSON.parse(_fs.readFileSync(vf, "utf-8"));
      notes = vd.notes || "";
    } catch (e) { /* sem version.json — segue sem notes */ }

    var contentHTML = notes
      ? '<p style="font-size:12px;color:var(--text-primary);line-height:1.7;margin:0 0 14px;white-space:pre-line;">' + notes + '</p>'
      : '<p style="font-size:12px;color:var(--text-secondary);line-height:1.7;margin:0 0 14px;">Correcao de bugs e melhorias de desempenho.</p>';

    var container = document.getElementById("modalContainer");
    container.innerHTML =
      '<div class="modal-overlay" onclick="closeModal(event)">' +
        '<div class="modal update-modal" onclick="event.stopPropagation()">' +
          '<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">' +
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>' +
            '</svg>' +
            '<h3 style="margin:0;font-size:14px;">Ultima atualizacao</h3>' +
          '</div>' +
          '<p style="color:var(--accent);font-size:12px;font-weight:600;margin:0 0 12px;">v' + window.APP_VERSION + '</p>' +
          contentHTML +
          '<div class="modal-actions">' +
            '<button class="btn btn-primary" onclick="closeModal()" style="width:100%;">Fechar</button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  function showWelcomeModal(step) {
    if (step < 0) step = 0;
    if (step >= welcomeSlides.length) { closeWelcomeModal(); return; }
    var container = document.getElementById("modalContainer");
    var existing = container.querySelector(".welcome-modal");

    // Primeira abertura: cria o esqueleto fixo (overlay + modal + dots + botoes).
    // Trocas seguintes: so atualiza conteudo do slide + estado de dots/botoes.
    if (!existing) {
      var dotsHTML = '';
      for (var d = 0; d < welcomeSlides.length; d++) {
        dotsHTML += '<span class="welcome-dot"></span>';
      }
      container.innerHTML =
        '<div class="modal-overlay">' +
          '<div class="modal welcome-modal" onclick="event.stopPropagation()" style="max-width:360px;text-align:center;position:relative;">' +
            '<button class="welcome-close" title="Pular tour" onclick="closeWelcomeModal()" aria-label="Fechar tour">' +
              '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
                '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>' +
              '</svg>' +
            '</button>' +
            '<div class="welcome-slide" id="welcomeSlideContent"></div>' +
            '<div class="welcome-dots">' + dotsHTML + '</div>' +
            '<div class="modal-actions" style="justify-content:center;gap:8px;margin-top:16px;">' +
              '<button class="btn" id="welcomePrevBtn">Anterior</button>' +
              '<button class="btn btn-primary" id="welcomeNextBtn">Proximo</button>' +
            '</div>' +
          '</div>' +
        '</div>';

      _renderWelcomeStep(step);
      return;
    }

    // Modal ja existe: faz fade-out, troca conteudo, fade-in
    var slideEl = document.getElementById("welcomeSlideContent");
    if (slideEl) {
      slideEl.classList.add("fading");
      setTimeout(function() {
        _renderWelcomeStep(step);
        slideEl.classList.remove("fading");
      }, 120);
    } else {
      _renderWelcomeStep(step);
    }
  }

  function _renderWelcomeStep(step) {
    var s = welcomeSlides[step];
    var slideEl = document.getElementById("welcomeSlideContent");
    if (slideEl) {
      slideEl.innerHTML =
        '<div style="margin-bottom:16px;">' + s.icon + '</div>' +
        '<h3 style="margin:0 0 8px;">' + s.title + '</h3>' +
        '<p style="font-size:11px;color:var(--text-secondary);margin:0 0 20px;line-height:1.5;">' + s.text + '</p>';
    }
    // Dots
    var dots = document.querySelectorAll(".welcome-dot");
    for (var d = 0; d < dots.length; d++) {
      dots[d].classList.toggle("active", d === step);
    }
    // Prev btn
    var prev = document.getElementById("welcomePrevBtn");
    if (prev) {
      prev.style.visibility = step > 0 ? "visible" : "hidden";
      prev.onclick = function() { showWelcomeModal(step - 1); };
    }
    // Next btn (vira "Comecar" no ultimo slide)
    var next = document.getElementById("welcomeNextBtn");
    if (next) {
      var isLast = step >= welcomeSlides.length - 1;
      next.textContent = isLast ? "Comecar" : "Proximo";
      next.onclick = isLast
        ? function() { closeWelcomeModal(); }
        : function() { showWelcomeModal(step + 1); };
    }
  }

  function closeWelcomeModal() {
    _state.welcomed = true;
    _saveState();
    document.getElementById("modalContainer").innerHTML = "";
  }

  // -------------------------------------------------------------------------
  // FFmpeg discovery — exibido na primeira execucao se ffmpeg nao for achado
  // -------------------------------------------------------------------------

  var _isWinPlatform = process.platform === "win32";
  var _ffmpegDownloadUrl = _isWinPlatform
    ? "https://github.com/BtbN/FFmpeg-Builds/releases/latest"
    : "https://evermeet.cx/ffmpeg/";

  function showFFmpegMissingModal() {
    var container = document.getElementById("modalContainer");
    var hint = _isWinPlatform
      ? "No Windows, recomendamos baixar o build estatico do BtbN e extrair em <code>C:\\ffmpeg</code>."
      : "No macOS, instale via Homebrew (<code>brew install ffmpeg</code>) ou baixe em evermeet.cx.";
    container.innerHTML =
      '<div class="modal-overlay">' +
        '<div class="modal" onclick="event.stopPropagation()" style="width:380px;text-align:center;">' +
          '<div style="margin-bottom:14px;">' +
            '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
              '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>' +
            '</svg>' +
          '</div>' +
          '<h3 style="margin:0 0 8px;">FFmpeg nao encontrado</h3>' +
          '<p style="font-size:11px;color:var(--text-secondary);line-height:1.6;margin:0 0 12px;">' +
            'O StockHub usa o FFmpeg para gerar previews e miniaturas. Sem ele, os videos aparecem sem thumb.' +
          '</p>' +
          '<p style="font-size:10.5px;color:var(--text-muted);line-height:1.6;margin:0 0 18px;">' + hint + '</p>' +
          '<div style="display:flex;flex-direction:column;gap:8px;">' +
            '<button class="btn btn-primary" onclick="openFFmpegDownloadPage()" style="width:100%;justify-content:center;">' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>' +
              'Abrir pagina de download' +
            '</button>' +
            '<button class="btn" onclick="locateFFmpegManually()" style="width:100%;justify-content:center;">' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>' +
              'Ja tenho instalado — apontar' +
            '</button>' +
            '<button class="btn" onclick="dismissFFmpegNotice()" style="width:100%;justify-content:center;color:var(--text-muted);">' +
              'Pular por enquanto' +
            '</button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  function openFFmpegDownloadPage() {
    try {
      var url = _ffmpegDownloadUrl;
      if (_isWinPlatform) {
        // start "" abre o browser padrao e o traz para frente
        child.exec('cmd /c start "" "' + url + '"');
      } else {
        // open no macOS ativa o browser e o traz para frente
        child.exec('open "' + url + '"');
      }
    } catch (e) {
      _showToast("Falha ao abrir navegador: " + _ffmpegDownloadUrl);
    }
  }

  function locateFFmpegManually() {
    var result = window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx
      ? window.cep.fs.showOpenDialogEx(false, false, "Selecione o executavel do FFmpeg", "",
          _isWinPlatform ? ["exe"] : null)
      : null;
    if (!result || !result.data || !result.data.length) return;
    var picked = result.data[0];
    if (!_fs.existsSync(picked)) { _showToast("Arquivo nao encontrado"); return; }
    var name = _path.basename(picked).toLowerCase();
    if (name.indexOf("ffmpeg") < 0) {
      _showToast("Selecione o binario ffmpeg(.exe)");
      return;
    }
    _state.ffmpegPath = picked;
    _state.ffmpegNoticed = true;
    _saveState();
    if (window.resetFFmpegLookup) window.resetFFmpegLookup();
    document.getElementById("modalContainer").innerHTML = "";
    _showToast("FFmpeg configurado");
    if (typeof refreshFiles === "function") refreshFiles();
  }

  function dismissFFmpegNotice() {
    _state.ffmpegNoticed = true;
    _saveState();
    document.getElementById("modalContainer").innerHTML = "";
  }

  // -------------------------------------------------------------------------
  // Confirm modal — generico, reutilizavel para acoes destrutivas
  // -------------------------------------------------------------------------

  // Slot para callback do confirm (limpado ao fechar)
  var _pendingConfirm = null;

  function showConfirmModal(opts) {
    var title = opts.title || "Confirmar";
    var message = opts.message || "";
    var confirmLabel = opts.confirmLabel || "Confirmar";
    var cancelLabel = opts.cancelLabel || "Cancelar";
    var danger = !!opts.danger;
    var iconSvg = danger
      ? '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>'
      : '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>';
    var iconColor = danger ? "var(--red)" : "var(--accent)";
    var btnClass = danger ? "btn danger" : "btn btn-primary";

    _pendingConfirm = opts.onConfirm || null;

    var container = document.getElementById("modalContainer");
    container.innerHTML =
      '<div class="modal-overlay" onclick="closeConfirmModal(event)">' +
        '<div class="modal" onclick="event.stopPropagation()" style="width:340px;text-align:center;">' +
          '<div style="margin-bottom:14px;">' +
            '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="' + iconColor + '" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' + iconSvg + '</svg>' +
          '</div>' +
          '<h3 style="margin:0 0 8px;">' + title + '</h3>' +
          '<p style="font-size:11.5px;color:var(--text-secondary);line-height:1.6;margin:0 0 18px;">' + message + '</p>' +
          '<div class="modal-actions" style="justify-content:center;gap:8px;">' +
            '<button class="btn" onclick="closeConfirmModal()">' + cancelLabel + '</button>' +
            '<button class="' + btnClass + '" onclick="resolveConfirmModal()">' + confirmLabel + '</button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  function closeConfirmModal(e) {
    if (e && e.target !== e.currentTarget) return;
    _pendingConfirm = null;
    document.getElementById("modalContainer").innerHTML = "";
  }

  function resolveConfirmModal() {
    var cb = _pendingConfirm;
    _pendingConfirm = null;
    document.getElementById("modalContainer").innerHTML = "";
    if (typeof cb === "function") cb();
  }

  // -------------------------------------------------------------------------
  // User ID modal — pedido em primeira execucao (necessario para metricas)
  // -------------------------------------------------------------------------

  function showUserIdModal() {
    var container = document.getElementById("modalContainer");
    var defaultName = (process.env.USERNAME || process.env.USER || "").replace(/[^a-zA-Z0-9_-]/g, "");
    container.innerHTML =
      '<div class="modal-overlay">' +
        '<div class="modal" onclick="event.stopPropagation()">' +
          '<h3>Bem-vindo ao StockHub</h3>' +
          '<p style="font-size:11px;color:var(--text-secondary);margin:0 0 12px;">Informe seu nome para rastrear o uso de assets pela equipe.</p>' +
          '<input type="text" id="userIdInput" placeholder="Seu nome (ex: joao, maria)" value="' + defaultName + '" onkeydown="if(event.key===\'Enter\')confirmUserId()">' +
          '<div class="modal-actions">' +
            '<button class="btn btn-primary" onclick="confirmUserId()">Confirmar</button>' +
          '</div>' +
        '</div>' +
      '</div>';
    setTimeout(function() {
      var inp = document.getElementById("userIdInput");
      if (inp) { inp.focus(); inp.select(); }
    }, 100);
  }

  function confirmUserId() {
    var input = document.getElementById("userIdInput");
    var name = input ? input.value.trim() : "";
    if (!name) { _showToast("Informe seu nome"); return; }
    _state.userId = name.toLowerCase().replace(/[^a-z0-9_-]/g, "-");
    _saveState();
    closeModal();
    _showToast("Usuario definido: " + _state.userId);
  }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.ModalManager = {
    init: function(stateRef, deps) {
      _state     = stateRef;
      _saveState = deps.saveState;
      _showToast = deps.showToast;
    },
    closeModal:             closeModal,
    showLastUpdateModal:    showLastUpdateModal,
    showWelcomeModal:       showWelcomeModal,
    closeWelcomeModal:      closeWelcomeModal,
    showUserIdModal:        showUserIdModal,
    confirmUserId:          confirmUserId,
    showFFmpegMissingModal: showFFmpegMissingModal,
    openFFmpegDownloadPage: openFFmpegDownloadPage,
    locateFFmpegManually:   locateFFmpegManually,
    dismissFFmpegNotice:    dismissFFmpegNotice,
    showConfirmModal:       showConfirmModal,
    closeConfirmModal:      closeConfirmModal,
    resolveConfirmModal:    resolveConfirmModal
  };

  // Aliases globais para onclick no HTML
  window.closeModal             = closeModal;
  window.showLastUpdateModal    = showLastUpdateModal;
  window.showWelcomeModal       = showWelcomeModal;
  window.closeWelcomeModal      = closeWelcomeModal;
  window.showUserIdModal        = showUserIdModal;
  window.confirmUserId          = confirmUserId;
  window.showFFmpegMissingModal = showFFmpegMissingModal;
  window.openFFmpegDownloadPage = openFFmpegDownloadPage;
  window.locateFFmpegManually   = locateFFmpegManually;
  window.dismissFFmpegNotice    = dismissFFmpegNotice;
  window.showConfirmModal       = showConfirmModal;
  window.closeConfirmModal      = closeConfirmModal;
  window.resolveConfirmModal    = resolveConfirmModal;

})();
