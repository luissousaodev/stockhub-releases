// =============================================================================
// app.js — Init + wiring do StockHub (CEP Extension for Premiere Pro)
// =============================================================================
// Modulos carregados via script tags (ver index.html):
//   core/     — constants, platform, logger, storage, state
//   features/ — file-scanner, thumbnails, folder-manager, project-assets
//   ui/       — render, settings, toast, sidebar-resize
//   Managers  — ffmpeg, modal, preview, drag, category, metrics, update

var APP_VERSION = (function () {
  try {
    var vf = require("path").join(__dirname, "..", "version.json");
    return JSON.parse(require("fs").readFileSync(vf, "utf-8")).version || "0.0.0";
  } catch (e) { return "0.0.0"; }
})();
var cs = new CSInterface();

// Estado global de drag — usado para pausar trabalho pesado de ffmpeg
var isDragging = false;
// Sinalizador para pausar a fila de geracao de thumbs em background
var thumbQueuePaused = false;

function _isMacPlatform() {
  return process.platform === "darwin";
}

function _hasPrimaryShortcutModifier(e) {
  return _isMacPlatform() ? (e.metaKey || e.ctrlKey) : e.ctrlKey;
}

// --- Bind static events (substitui onclick inline do HTML) ---
function bindStaticEvents() {
  // Sidebar bottom actions
  document.getElementById("refreshBtn").addEventListener("click", refreshFiles);
  document.getElementById("metricsBtn").addEventListener("click", toggleMetrics);
  document.getElementById("settingsBtn").addEventListener("click", toggleSettings);

  // Search input
  document.getElementById("searchInput").addEventListener("input", filterFiles);

  // Format dropdown — toggle e selecao
  var formatBtn = document.getElementById("formatDropdownBtn");
  var formatMenu = document.getElementById("formatDropdownMenu");
  var sortMenu = document.getElementById("sortMenu");

  if (formatBtn && formatMenu) {
    formatBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      var open = formatMenu.style.display !== "none";
      formatMenu.style.display = open ? "none" : "block";
      formatBtn.classList.toggle("open", !open);
      if (sortMenu) sortMenu.style.display = "none";
    });
    formatMenu.addEventListener("click", function(e) {
      var item = e.target.closest(".dropdown-item[data-format]");
      if (item) {
        e.stopPropagation();
        var format = item.getAttribute("data-format");
        setFormat(format, item);
        formatMenu.style.display = "none";
        formatBtn.classList.remove("open");
        return;
      }
      // "Ordenar..." dentro do dropdown
      var sortItem = e.target.closest("#sortBtn");
      if (sortItem && sortMenu) {
        e.stopPropagation();
        formatMenu.style.display = "none";
        formatBtn.classList.remove("open");
        sortMenu.style.display = "block";
        syncSortMenuActive();
      }
    });
  }

  // Sort menu — escolher criterio, alternar ordem
  if (sortMenu) {
    sortMenu.addEventListener("click", function(e) {
      var item = e.target.closest(".sort-menu-item");
      if (!item) return;
      e.stopPropagation();
      if (item.getAttribute("data-sort-order") === "toggle") {
        state.sortOrder = state.sortOrder === "asc" ? "desc" : "asc";
      } else {
        state.sortBy = item.getAttribute("data-sort");
      }
      saveState();
      syncSortMenuActive();
      renderGrid();
    });
  }

  // Click fora — fecha menus abertos
  document.addEventListener("click", function() {
    if (formatMenu && formatMenu.style.display !== "none") {
      formatMenu.style.display = "none";
      if (formatBtn) formatBtn.classList.remove("open");
    }
    if (sortMenu && sortMenu.style.display !== "none") {
      sortMenu.style.display = "none";
    }
  });

  // Breadcrumb — reseta todos os filtros ao clicar
  var breadcrumb = document.getElementById("breadcrumb");
  if (breadcrumb) breadcrumb.addEventListener("click", resetToHome);

  // Sidebar — add category
  document.getElementById("addCategoryBtn").addEventListener("click", showAddCategoryModal);

  // Sidebar — toggle (recolher / expandir) em rail mode
  var toggleBtn = document.getElementById("sidebarToggleBtn");
  if (toggleBtn) toggleBtn.addEventListener("click", function() {
    setSidebarCollapsed(!state.sidebarCollapsed);
  });

  // Sidebar — context menu on empty area
  document.getElementById("categoryList").addEventListener("contextmenu", showSidebarContextMenu);

  // Grid size slider
  document.getElementById("gridSize").addEventListener("input", updateGridSize);

  // Grid click — multi-select with Ctrl/Cmd/Shift
  document.getElementById("fileGrid").addEventListener("click", function(e) {
    if (e.target.closest(".import-btn")) return;
    var item = e.target.closest(".grid-item");
    if (!item) return;
    var fp = item.getAttribute("data-filepath");
    if (!fp) return;
    for (var i = 0; i < state.files.length; i++) {
      if (state.files[i].path === fp) {
        if (e.ctrlKey || e.metaKey || e.shiftKey) {
          e.preventDefault();
          toggleFileSelection(i, e);
        } else if (Object.keys(state.selectedFiles).length > 0) {
          clearSelection();
        }
        break;
      }
    }
  });

  // Version label — click to show version info
  var verLabel = document.getElementById("versionLabel");
  if (verLabel) verLabel.addEventListener("click", showLastUpdateModal);
}

// --- Init ---
// Boot em duas fases: paint inicial em <300ms, trabalho pesado em _bootDeferred.
// Operacoes sync minimas: bindStaticEvents, loadState, ensureStockFolder, init de
// modulos basicos. Tudo que faz I/O pesado (scan, thumbs, network) eh adiado.
function init() {
  try {
    bindStaticEvents();
    loadState();
    document.getElementById("gridSize").value = state.gridSize;
    ensureStockFolder();

    var vl = document.getElementById("versionLabel");
    if (vl) vl.textContent = "v" + APP_VERSION;

    // Modulos sao inicializados sincronamente — deps simples, custo minimo.
    FFmpegManager.init({
      getStockFolder: getStockFolder,
      toRelPath: toRelPath,
      toFileURL: toFileURL
    });
    ModalManager.init(state, { saveState: saveState, showToast: showToast });
    CategoryManager.init(state, {
      saveState: saveState, showToast: showToast, toRelPath: toRelPath,
      renderCategories: renderCategories, renderGrid: renderGrid, renderAll: renderAll
    });
    DragManager.init(state, {
      saveState: saveState, showToast: showToast, toRelPath: toRelPath, toFileURL: toFileURL,
      materializeFileForProjectAsync: materializeFileForProjectAsync,
      materializeFilesForProjectAsync: materializeFilesForProjectAsync,
      cs: cs, trackEvent: trackEvent,
      pumpThumbPool: pumpThumbPool, renderAll: renderAll
    });
    PreviewManager.init(state, { toFileURL: toFileURL });
    MetricsManager.init(state, {
      getStockFolder: getStockFolder, showToast: showToast, toggleSettings: toggleSettings, cs: cs
    });

    // Restaura layout + categorias (proma: nao depende de scan)
    if (state.sidebarWidth) {
      var sb = document.getElementById("sidebar");
      if (sb) sb.style.width = state.sidebarWidth + "px";
    }
    if (typeof applySidebarCollapsed === "function") applySidebarCollapsed();
    if (typeof syncSortMenuActive === "function") syncSortMenuActive();
    initSidebarResize();
    renderCategories();
    document.getElementById("statusText").textContent = "Carregando arquivos...";

    // Atalhos globais — registra mas nao bloqueia paint
    _bindKeyboardShortcuts();

    // Status row resize observer
    var statusEl = document.querySelector(".sidebar-status");
    if (statusEl && typeof ResizeObserver !== "undefined") {
      new ResizeObserver(function() {
        var w = statusEl.offsetWidth;
        statusEl.style.fontSize = Math.max(7.5, Math.min(9.5, w / 20)) + "px";
      }).observe(statusEl);
    }

    // Defer tudo que toca filesystem pesado / network / FFmpeg discovery
    setTimeout(_bootDeferred, 0);
  } catch (e) {
    alert("StockHub init error: " + e.toString());
  }
}

function _bootDeferred() {
  if (typeof cleanupLegacyStaging === "function") cleanupLegacyStaging();

  // FFmpeg discovery async — nao bloqueia UI nem mesmo na primeira rodada
  findFFmpegAsync(function(ff) {
    if (ff) {
      Logger.info("init", "FFmpeg found at " + ff);
      _hideFFmpegMissingBadge();
    } else {
      Logger.warn("init", "FFmpeg not found");
      _showFFmpegMissingBadge();
      if (!state.ffmpegNoticed) showFFmpegMissingModal();
    }

    // Pre-warm hash set (readdirSync .cache) so que ficou ate aqui pra nao
    // bloquear. Trim de chamada caso FFmpeg nao foi achado.
    // Try/catch: scanFolder pode lancar (permissao negada, path com char
    // invalido, disco desconectado mid-walk). Sem isso, uncaught em callback
    // async mata o renderer no CEF. Sem retry automatico — user clica
    // "Atualizar" pra tentar de novo.
    try {
      var bootFolder = getStockFolder();
      var cachedIndex = (typeof loadFolderIndex === "function") ? loadFolderIndex(bootFolder) : null;
      if (cachedIndex && cachedIndex.files) {
        state.files = cachedIndex.files;
        if (typeof bumpFilesVersion === "function") bumpFilesVersion();
        if (typeof prewarmSiblingThumbs === "function") prewarmSiblingThumbs(state.files);
        renderAll();
        var statusBoot = document.getElementById("statusText");
        if (statusBoot) statusBoot.textContent = "Carregado do cache local, atualizando...";
      }
      if (typeof prewarmThumbLookup === "function") prewarmThumbLookup();
      refreshFiles();
    } catch (e) {
      Logger.error("boot", "Falha no boot deferred (scan/refresh)", e.message);
      var statusEl = document.getElementById("statusText");
      if (statusEl) statusEl.textContent = "Erro ao carregar pasta — clique pra tentar novamente";
    }
  });

  // Idle work — modais de boas-vindas, update check (network)
  var idle = window.requestIdleCallback || function(cb) { return setTimeout(cb, 100); };
  idle(function() {
    UpdateManager.init(state, saveState);
    UpdateManager.check();
    UpdateManager.schedulePeriodicCheck();

    if (!state.userId) showUserIdModal();
    if (!state.welcomed) showWelcomeModal(0);

    if (state.lastSeenVersion && _compareSemver(APP_VERSION, state.lastSeenVersion) > 0) {
      showToast("Atualizado para v" + APP_VERSION + " com sucesso!");
      // Marca como visto ANTES do modal — antes ficava no closeWhatsNewModal
      // (que saiu junto com showWhatsNewModal). Sem isso, o modal apareceria
      // toda vez que o painel abre depois de um update.
      state.lastSeenVersion = APP_VERSION;
      saveState();
      showLastUpdateModal();
    } else if (!state.lastSeenVersion) {
      state.lastSeenVersion = APP_VERSION;
      saveState();
    }
  }, { timeout: 1500 });
}

function _showFFmpegMissingBadge() {
  var statusEl = document.getElementById("statusText");
  if (statusEl) statusEl.textContent = "FFmpeg ausente — previews indisponiveis";
}

function _hideFFmpegMissingBadge() { /* status sera atualizado pelo refreshFiles */ }

function _bindKeyboardShortcuts() {
    document.addEventListener("keydown", function(e) {
      var key = String(e.key || "").toLowerCase();

      // Dev hot reload: Ctrl+Shift+R no Windows, Cmd+Shift+R no macOS
      if (_hasPrimaryShortcutModifier(e) && e.shiftKey && key === "r") {
        e.preventDefault();
        location.reload();
        return;
      }

      // Ignora atalhos de char enquanto usuario digita em input/textarea
      var tag = (e.target && e.target.tagName) || "";
      var typing = tag === "INPUT" || tag === "TEXTAREA" || (e.target && e.target.isContentEditable);

      if (!typing) {
        // / foca a busca
        if (e.key === "/") {
          e.preventDefault();
          var inp = document.getElementById("searchInput");
          if (inp) { inp.focus(); inp.select(); }
          return;
        }
        // Ctrl+A / Cmd+A seleciona todos os arquivos visiveis
        if (_hasPrimaryShortcutModifier(e) && key === "a") {
          e.preventDefault();
          var files = (typeof getFilteredFiles === "function") ? getFilteredFiles() : [];
          var indexMap = (typeof getFileIndexMap === "function") ? getFileIndexMap() : {};
          state.selectedFiles = {};
          for (var f = 0; f < files.length; f++) {
            var idx = indexMap[files[f].path];
            if (idx !== undefined) state.selectedFiles[idx] = true;
          }
          renderGrid();
          return;
        }
      }

      // Esc — limpa selecao (modais ja tratam fechamento via overlay click)
      if (e.key === "Escape") {
        if (Object.keys(state.selectedFiles).length > 0) {
          clearSelection();
          return;
        }
      }
    });
}

init();
