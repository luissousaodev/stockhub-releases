// =============================================================================
// features/preview-manager.js — Preview de hover (frame-strip + audio)
//
// Video: usa um sprite Nx1 gerado pelo FFmpeg (zero codec runtime). Modo
// hibrido: auto-loop por padrao; se o cursor mover horizontalmente, vira
// scrubbing (cursor x → frame).
// Audio: <audio> + indicador animado (sem mudanca em relacao a versao antiga).
//
// Dependencias externas (recebidas via init):
//   - state, toFileURL
//   - FFmpegManager.{spriteCache, generateFrameStripFFmpeg, findFFmpeg}
// =============================================================================

if (typeof window !== "undefined") (function() {

  var _state             = null;
  var _toFileURL         = null;

  var activePreview = null;
  var hoverTimer = null;

  // -------------------------------------------------------------------------
  // Hover handlers
  // -------------------------------------------------------------------------

  function onMouseEnter(el, fileIndex) {
    if (_state.previewHoverEnabled === false) return;
    var file = _state.files[fileIndex];
    if (!file || (file.type !== "video" && file.type !== "audio")) return;

    // Cloud-only: gate de 800ms (intencao real). Preview pode baixar sob
    // demanda, mas nao copia para a pasta do projeto.
    if (file.cloudOnly) {
      clearTimeout(hoverTimer);
      hoverTimer = setTimeout(function() {
        if (!el.matches(":hover")) return;
        FFmpegManager.ensureFFmpegAsync(function(ff) {
          if (!ff || !el.matches(":hover")) return;
          if (!FFmpegManager.thumbCache.has(file.path)) {
            generateThumbFFmpeg(file.path, function(url) {
              if (url && typeof window._updateCardThumb === "function") window._updateCardThumb(file.path, url);
            });
          }
          if (!FFmpegManager.spriteCache.has(file.path)) {
            generateFrameStripFFmpeg(file.path, function(s) {
              if (s && el.matches(":hover")) createFrameStripPreview(el, s);
            });
          }
        });
      }, 800);
      return;
    }

    clearTimeout(hoverTimer);
    hoverTimer = setTimeout(function() {
      if (!el.matches(":hover")) return;

      if (file.type === "audio") {
        createPreviewAudio(el, _toFileURL(file.path));
        return;
      }

      // Video: tenta sprite ja cacheado; senao gera em background
      var sprite = FFmpegManager.spriteCache.get(file.path);
      if (sprite) {
        createFrameStripPreview(el, sprite);
      } else {
        FFmpegManager.ensureFFmpegAsync(function(ff) {
          if (!ff || !el.matches(":hover")) return;
          FFmpegManager.generateFrameStripFFmpeg(file.path, function(s) {
            if (!el.matches(":hover") || !s) return;
            createFrameStripPreview(el, s);
          });
        });
      }
      // Sem FFmpeg: hover deixa o thumb estatico mesmo (sem fallback de video)
    }, 150);
  }

  // Preview por sprite — auto-loop ate o cursor mover horizontal, ai vira scrub
  function createFrameStripPreview(el, sprite) {
    cleanupPreview();
    var thumb = el.querySelector(".grid-item-thumb") || el;

    var view = document.createElement("div");
    view.className = "frame-strip-preview";
    view.style.backgroundImage = "url('" + sprite.url + "')";
    // Sprite Nx1: largura total = N * frameW. background-size em % do container:
    // (frames * 100)% mostra frame-a-frame conforme background-position-x
    view.style.backgroundSize = (sprite.frames * 100) + "% 100%";
    view.style.backgroundPosition = "0% 0%";
    thumb.appendChild(view);

    var bar = document.createElement("div"); bar.className = "scrub-bar";
    var fill = document.createElement("div"); fill.className = "scrub-bar-fill";
    bar.appendChild(fill); thumb.appendChild(bar);

    var current = 0, scrubbing = false, lastX = -1;
    var FPS = 5;

    function showFrame(i) {
      current = i;
      var pct = (sprite.frames > 1) ? (i / (sprite.frames - 1)) * 100 : 0;
      view.style.backgroundPosition = pct + "% 0%";
      fill.style.width = ((i + 1) / sprite.frames * 100) + "%";
    }

    showFrame(Math.floor(sprite.frames / 2));

    var loopId = setInterval(function() {
      if (scrubbing) return;
      showFrame((current + 1) % sprite.frames);
    }, 1000 / FPS);

    function onMove(ev) {
      var rect = thumb.getBoundingClientRect();
      var dx = (lastX < 0) ? 0 : Math.abs(ev.clientX - lastX);
      lastX = ev.clientX;
      if (dx > 2) scrubbing = true;
      if (scrubbing) {
        var x = ev.clientX - rect.left;
        var ratio = Math.max(0, Math.min(1, x / rect.width));
        showFrame(Math.floor(ratio * (sprite.frames - 1)));
      }
    }
    thumb.addEventListener("mousemove", onMove);

    activePreview = { thumb: thumb, view: view, bar: bar, loopId: loopId, onMove: onMove };
  }

  function createPreviewAudio(el, src) {
    cleanupPreview();
    var thumb = el.querySelector(".grid-item-thumb") || el;
    var audio = document.createElement("audio");
    audio.preload = "auto";
    audio.loop = true;
    audio.onerror = function() { audio.remove(); activePreview = null; };

    var indicator = document.createElement("div");
    indicator.className = "audio-playing-indicator";
    indicator.innerHTML =
      '<div class="audio-bar"></div><div class="audio-bar"></div>' +
      '<div class="audio-bar"></div><div class="audio-bar"></div>';
    thumb.appendChild(indicator);

    activePreview = { thumb: thumb, audio: audio, indicator: indicator };

    audio.oncanplay = function() {
      audio.oncanplay = null;
      if (!el.matches(":hover")) { cleanupPreview(); return; }
      audio.play().catch(function() {});
    };
    audio.src = src;
  }

  function onMouseLeave() {
    clearTimeout(hoverTimer);
    cleanupPreview();
  }

  function cleanupPreview() {
    if (!activePreview) return;
    if (activePreview.loopId) clearInterval(activePreview.loopId);
    if (activePreview.onMove && activePreview.thumb) {
      activePreview.thumb.removeEventListener("mousemove", activePreview.onMove);
    }
    if (activePreview.audio) {
      try { activePreview.audio.pause(); activePreview.audio.removeAttribute("src"); activePreview.audio.load(); } catch (e) { /* ignore */ }
    }
    if (activePreview.view)      activePreview.view.remove();
    if (activePreview.bar)       activePreview.bar.remove();
    if (activePreview.indicator) activePreview.indicator.remove();
    activePreview = null;
  }

  // -------------------------------------------------------------------------
  // API publica
  // -------------------------------------------------------------------------

  window.PreviewManager = {
    init: function(stateRef, deps) {
      _state             = stateRef;
      _toFileURL         = deps.toFileURL;
    },
    onMouseEnter:   onMouseEnter,
    onMouseLeave:   onMouseLeave,
    cleanupPreview: cleanupPreview
  };

  // Aliases globais para inline event attrs no renderGrid
  window.onMouseEnter   = onMouseEnter;
  window.onMouseLeave   = onMouseLeave;
  window.cleanupPreview = cleanupPreview;

})();
