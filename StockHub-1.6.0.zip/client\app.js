// =============================================================================
// app.js — Init + wiring do StockHub (CEP Extension for Premiere Pro)
// =============================================================================
// Modulos carregados via script tags (ver index.html):
//   core/     — constants, platform, logger, storage, state
//   features/ — file-scanner, thumbnails, folder-manager, staging
//   ui/       — render, settings, toast, sidebar-resize
//   Managers  — ffmpeg, modal, preview, drag, category, metrics, update

var APP_VERSION = (function () {
  try {
    var vf = require("path").join(__dirname, "..", "version.json");
    return JSON.parse(require("fs").readFileSync(vf, "utf-8")).version || "0.0.0";
  } catch (e) { return "0.0.0"; }
})();
var cs = new CSInterface();

// Estado global de drag — usado para pausar trabalho pesado de ffmpeg
var isDragging = false;
// Sinalizador para pausar a fila de geracao de thumbs em background
var thumbQueuePaused = false;

// --- Bind static events (substitui onclick inline do HTML) ---
function bindStaticEvents() {
  // Sidebar bottom actions
  document.getElementById("refreshBtn").addEventListener("click", refreshFiles);
  document.getElementById("metricsBtn").addEventListener("click", toggleMetrics);
  document.getElementById("settingsBtn").addEventListener("click", toggleSettings);
  document.getElementById("helpBtn").addEventListener("click", function() { showWelcomeModal(0); });

  // Search input
  document.getElementById("searchInput").addEventListener("input", filterFiles);

  // Format dropdown — toggle e selecao
  var formatBtn = document.getElementById("formatDropdownBtn");
  var formatMenu = document.getElementById("formatDropdownMenu");
  var sortMenu = document.getElementById("sortMenu");

  if (formatBtn && formatMenu) {
    formatBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      var open = formatMenu.style.display !== "none";
      formatMenu.style.display = open ? "none" : "block";
      formatBtn.classList.toggle("open", !open);
      if (sortMenu) sortMenu.style.display = "none";
    });
    formatMenu.addEventListener("click", function(e) {
      var item = e.target.closest(".dropdown-item[data-format]");
      if (item) {
        e.stopPropagation();
        var format = item.getAttribute("data-format");
        setFormat(format, item);
        formatMenu.style.display = "none";
        formatBtn.classList.remove("open");
        return;
      }
      // "Ordenar..." dentro do dropdown
      var sortItem = e.target.closest("#sortBtn");
      if (sortItem && sortMenu) {
        e.stopPropagation();
        formatMenu.style.display = "none";
        formatBtn.classList.remove("open");
        sortMenu.style.display = "block";
        syncSortMenuActive();
      }
    });
  }

  // Sort menu — escolher criterio, alternar ordem
  if (sortMenu) {
    sortMenu.addEventListener("click", function(e) {
      var item = e.target.closest(".sort-menu-item");
      if (!item) return;
      e.stopPropagation();
      if (item.getAttribute("data-sort-order") === "toggle") {
        state.sortOrder = state.sortOrder === "asc" ? "desc" : "asc";
      } else {
        state.sortBy = item.getAttribute("data-sort");
      }
      saveState();
      syncSortMenuActive();
      renderGrid();
    });
  }

  // Click fora — fecha menus abertos
  document.addEventListener("click", function() {
    if (formatMenu && formatMenu.style.display !== "none") {
      formatMenu.style.display = "none";
      if (formatBtn) formatBtn.classList.remove("open");
    }
    if (sortMenu && sortMenu.style.display !== "none") {
      sortMenu.style.display = "none";
    }
  });

  // Breadcrumb — reseta todos os filtros ao clicar
  var breadcrumb = document.getElementById("breadcrumb");
  if (breadcrumb) breadcrumb.addEventListener("click", resetToHome);

  // Sidebar — add category
  document.getElementById("addCategoryBtn").addEventListener("click", showAddCategoryModal);

  // Sidebar — toggle (recolher / expandir) em rail mode
  var toggleBtn = document.getElementById("sidebarToggleBtn");
  if (toggleBtn) toggleBtn.addEventListener("click", function() {
    setSidebarCollapsed(!state.sidebarCollapsed);
  });

  // Sidebar — context menu on empty area
  document.getElementById("categoryList").addEventListener("contextmenu", showSidebarContextMenu);

  // Grid size slider
  document.getElementById("gridSize").addEventListener("input", updateGridSize);

  // Grid click — multi-select with Ctrl/Shift
  document.getElementById("fileGrid").addEventListener("click", function(e) {
    if (e.target.closest(".import-btn")) return;
    var item = e.target.closest(".grid-item");
    if (!item) return;
    var fp = item.getAttribute("data-filepath");
    if (!fp) return;
    for (var i = 0; i < state.files.length; i++) {
      if (state.files[i].path === fp) {
        if (e.ctrlKey || e.shiftKey) {
          e.preventDefault();
          toggleFileSelection(i, e);
        } else if (Object.keys(state.selectedFiles).length > 0) {
          clearSelection();
        }
        break;
      }
    }
  });

  // Version label — click to show version info
  var verLabel = document.getElementById("versionLabel");
  if (verLabel) verLabel.addEventListener("click", showVersionModal);
}

// --- Init ---
function init() {
  try {
    bindStaticEvents();
    loadState();
    document.getElementById("gridSize").value = state.gridSize;
    ensureStockFolder();

    // Version label no rodape da sidebar
    var vl = document.getElementById("versionLabel");
    if (vl) vl.textContent = "v" + APP_VERSION;

    // FFmpeg — inicializa modulo (antes de findFFmpeg)
    FFmpegManager.init({
      getStockFolder: getStockFolder,
      toRelPath: toRelPath,
      toFileURL: toFileURL
    });

    var ff = findFFmpeg();
    if (ff) {
      Logger.info("init", "FFmpeg found at " + ff);
    } else {
      Logger.warn("init", "FFmpeg not found. MOV previews disabled.");
    }
    // Aviso unico — usuario pode reabrir via Settings depois (Onda 2.2)
    if (!ff && !state.ffmpegNoticed) {
      setTimeout(function() { showFFmpegMissingModal(); }, 600);
    }

    // Modais — inicializa modulo
    ModalManager.init(state, {
      saveState: saveState,
      showToast: showToast
    });
    ModalManager.loadChangelog();

    // Restore sidebar width + collapsed state
    if (state.sidebarWidth) {
      var sb = document.getElementById("sidebar");
      if (sb) sb.style.width = state.sidebarWidth + "px";
    }
    if (typeof applySidebarCollapsed === "function") applySidebarCollapsed();
    if (typeof syncSortMenuActive === "function") syncSortMenuActive();
    initSidebarResize();

    refreshFiles();

    // Show userId modal if not set
    if (!state.userId) {
      showUserIdModal();
    }

    // Welcome modal (primeira execucao)
    if (!state.welcomed) {
      showWelcomeModal(0);
    }

    // What's new modal (apos update)
    if (state.lastSeenVersion && _compareSemver(APP_VERSION, state.lastSeenVersion) > 0) {
      showToast("Atualizado para v" + APP_VERSION + " com sucesso!");
      showWhatsNewModal();
    } else if (!state.lastSeenVersion) {
      state.lastSeenVersion = APP_VERSION;
      saveState();
    }

    // Categorias — inicializa modulo
    CategoryManager.init(state, {
      saveState: saveState,
      showToast: showToast,
      toRelPath: toRelPath,
      renderCategories: renderCategories,
      renderGrid: renderGrid,
      renderAll: renderAll
    });

    // Drag — inicializa modulo
    DragManager.init(state, {
      saveState: saveState,
      showToast: showToast,
      toRelPath: toRelPath,
      toFileURL: toFileURL,
      stageFileIfNeeded: stageFileIfNeeded,
      stageFileAsync: stageFileAsync,
      stageFilesAsync: stageFilesAsync,
      getStagedPathIfExists: getStagedPathIfExists,
      cs: cs,
      trackEvent: trackEvent,
      pumpThumbPool: pumpThumbPool,
      renderAll: renderAll
    });

    // Preview — inicializa modulo
    PreviewManager.init(state, {
      toFileURL: toFileURL,
      stageFileIfNeeded: stageFileIfNeeded
    });

    // Metricas — inicializa modulo
    MetricsManager.init(state, {
      getStockFolder: getStockFolder,
      showToast: showToast,
      toggleSettings: toggleSettings,
      cs: cs
    });

    // Auto-update — verificacao imediata + intervalo de 2h
    UpdateManager.init(state, saveState);
    UpdateManager.check();
    UpdateManager.schedulePeriodicCheck();

    // Status row: reduz font-size automaticamente se sidebar estreitar
    var statusEl = document.querySelector(".sidebar-status");
    if (statusEl && typeof ResizeObserver !== "undefined") {
      new ResizeObserver(function() {
        var w = statusEl.offsetWidth;
        statusEl.style.fontSize = Math.max(7.5, Math.min(9.5, w / 20)) + "px";
      }).observe(statusEl);
    }

    // Atalhos globais
    document.addEventListener("keydown", function(e) {
      // Dev hot reload: Ctrl+Shift+R recarrega o painel
      if (e.ctrlKey && e.shiftKey && e.key === "R") {
        e.preventDefault();
        location.reload();
        return;
      }

      // Ignora atalhos de char enquanto usuario digita em input/textarea
      var tag = (e.target && e.target.tagName) || "";
      var typing = tag === "INPUT" || tag === "TEXTAREA" || (e.target && e.target.isContentEditable);

      if (!typing) {
        // ? abre overlay de atalhos
        if (e.key === "?" || (e.shiftKey && e.key === "/")) {
          e.preventDefault();
          showShortcutsModal();
          return;
        }
        // / foca a busca
        if (e.key === "/") {
          e.preventDefault();
          var inp = document.getElementById("searchInput");
          if (inp) { inp.focus(); inp.select(); }
          return;
        }
        // Ctrl+A seleciona todos os arquivos visiveis
        if (e.ctrlKey && (e.key === "a" || e.key === "A")) {
          e.preventDefault();
          var files = (typeof getFilteredFiles === "function") ? getFilteredFiles() : [];
          var indexMap = {};
          for (var m = 0; m < state.files.length; m++) indexMap[state.files[m].path] = m;
          state.selectedFiles = {};
          for (var f = 0; f < files.length; f++) {
            var idx = indexMap[files[f].path];
            if (idx !== undefined) state.selectedFiles[idx] = true;
          }
          renderGrid();
          return;
        }
      }

      // Esc — limpa selecao (modais ja tratam fechamento via overlay click)
      if (e.key === "Escape") {
        if (Object.keys(state.selectedFiles).length > 0) {
          clearSelection();
          return;
        }
      }
    });
  } catch (e) {
    alert("StockHub init error: " + e.toString());
  }
}

init();
